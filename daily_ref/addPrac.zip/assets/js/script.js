function checkInvRes() {
    let inpEle = document.getElementById('decNum').value;
    document.getElementById("resultInv").innerHTML = `1's Complement of ${inpEle} is ${bin2dec(inpEle)}`;
}
function bin2dec(data) {
    let tempStr = parseInt(data, 10).toString(2);
    let bin = parseInt(data, 10).toString(2);
    var invRes = '';
    while (bin) {
        let temp = bin % 10;
        invRes += (temp === 0) ? 1 : 0;
        bin = parseInt(bin / 10);
    }
    let invStr = invRes.split("").reverse().join("");
    let invValue = parseInt(invStr, 2).toString();
    return invValue + "<br/> Input Binary String - " + tempStr + " <br/> Output Binary String- " + invStr;
}

async function getApiData() {
    const url = "https://gorest.co.in/public/v2/users";
    await fetch(url).then((success) => {
        success.text().then(
            (response) => {
                let data = JSON.parse(response);
                let resData = '';
                data.map(ele => {
                    resData += `<div class="col-sm-12 col-md-3 p-2"> <div class="card">
                    <div class="card-body position-relative">
                      <h6 class="card-title">${ele.name}</h6>
                      <small class="card-title text-muted">${ele.email}</small>
                      <span class="position-absolute top-0 start-100 translate-middle badge border border-light rounded-circle ${(ele.status == 'active') ? 'bg-success' : 'bg-danger'} p-2"><span class="visually-hidden">messages</span></span>
                    </div>
                    </div>
                  </div>`;
                });

                document.getElementById('resApiData').innerHTML = resData;
            },
            (reject) => { },
        );
    }, (error => {
        console.log(error);
    }));
}

const sumFunction = (num1, num2) => num1 + num2;

function sumWithExpression() {
    let number1 = parseInt(document.getElementById('inpNumber1').value);
    let number2 = parseInt(document.getElementById('inpNumber2').value);

    document.getElementById('resDataFunExp').innerHTML = "Sum is = " + sumFunction(number1, number2);
}

function objectHandle() {
    const employee = {
        name: "John Doe",
        email: "john.doe@gmail.com",
        job: "Developer",
        skills: ['PHP', '.NET', 'MySql'],
        hobbies: ['Dancing', 'Travaling', 'Swimming']
    };

    let details = detailsObjEmp`${employee.name}${employee.email}${employee.job}${employee.skills}${employee.hobbies}`;

    document.getElementById('resDataObj').innerHTML = details;

    function detailsObjEmp(text, ...data) {
        let detailsRes = '';
        detailsRes = `<div class="col-sm-12 col-md-5 p-2"> <div class="card">
            <div class="card-body position-relative">
              <h6 class="card-title">${data[0]}</h6>
              <p class="card-title text-muted">${data[1]}</p>
              <p class="card-title text-muted">${data[2]}</p>
                <div class="d-block">
                ${data[3].map(ele => {
            return `<small class="card-title text-muted">${ele}</small>, `;
        }).join("")}
                </div>

                <div class="d-block">
              ${data[4].map(ele => {
            return `<small class="card-title text-muted">${ele}</small>, `;
        }).join("")}
        </div>
            </div>
            </div>
          </div>`;
        return detailsRes;
    }
}


function checkData(inpArgStr1,inpArgStr2){
   return new Promise((success,failure)=>{
        setTimeout(()=>{
            if(inpArgStr1 == ""){
                failure("String 1 is Required");
            }
            if(inpArgStr2 == ""){
                failure("String 2 is Required");
            }
            if(inpArgStr1 == inpArgStr2)
                success("Same Strings Given");
            else
                failure("Different Strings Given");
        },1000);
});
}

function matchWithProm(){
    let inpStr1 = document.getElementById('inpString1Box').value;
    let inpStr2 = document.getElementById('inpString2Box').value;

    checkData(inpStr1,inpStr2).then(
        (success)=>{
            displayMsg('statusMsg',success);
        },
        (failure)=>{
            displayMsg('statusMsg',failure);
        },
    );
}

function displayMsg(eleId,msg){
    document.getElementById(eleId).innerHTML = msg;
    document.getElementById(eleId).innerHTML = msg;
}

function additionAll(num,...argsVal) {
    let sum = 0;
    sum += parseInt(num);
    for(let item of argsVal)
        sum += item;
    
        displayMsg('resDataSum',`Sum is ${sum}`);
}
function sumOfNNumer(){
    let inpNum = document.getElementById('inpStrNum').value;

    additionAll(inpNum,10,20,30,40);
}