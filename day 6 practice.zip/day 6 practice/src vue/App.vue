<template>
  <div>
    <ChildComp :parentData="myData" v-on:childToParent="onChildClick" v-on:increment="counter++"></ChildComp>
  </div>
</template>
<script>
import ChildComp from '@/components/ChildComp.vue'
export default {
  data () {
    return {
      counter: 0,
      fromChild: '', // This value is set to the value emitted by the child
    }
  },
  name: 'App',
  components: {
    ChildComp
  },
  methods: {
    // Triggered when `childToParent` event is emitted by the child.
    onChildClick (value) {
      this.fromChild = value
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
