import { Component, OnInit , Output, EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  @Output() childButtonEvent = new EventEmitter();
  @Output() onInitEvent = new EventEmitter();

  constructor() { }

  
  ngOnInit() {
    this.onInitEvent.emit('hello');
  }
  clickHandler() {
    this.childButtonEvent.emit('hello');
  }
  

}
