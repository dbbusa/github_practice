import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'components';
  name: any;  
  message: any;  
  sendToChild: any;  
  
  getResponse($event: any) {  
    this.message = $event;  
  }  
  submit() {  
    this.sendToChild = this.name;  
  }  
}
