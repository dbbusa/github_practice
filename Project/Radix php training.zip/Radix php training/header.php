<?php $url = 'http://localhost/Radix php training';?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="<?php echo $url.'/assets/css/font-awesome.min.css';?>">
  <link rel="stylesheet" href="<?php echo $url.'/assets/css/bootstarp.min.css';?>">
  <link rel="stylesheet" href="<?php echo $url.'/assets/css/custom.css';?>">
  <script src="<?php echo $url.'/assets/js/bootstrap.bundle.min.js';?>"></script>
  <script src="<?php echo $url.'/assets/js/jquery.min.js';?>"></script>
  <title>Index Page</title>
</head>

<body class='main_index'>
  <header>
    <nav>
      <button type="button" class="collapsible1"><strong class="fa_menu">HOME</strong><em
          class="fa icon_right text-white">&#xf0c9;</em></button>
      <div class="content1" id="content">
        <ul>
          <li><a href="<?php echo $url.'/HTML-training/index.php';?>">HTML</a></li>
          <li><a href="<?php echo $url.'/CSS-training/index.php';?>">CSS</a></li>
          <li><a href="<?php echo $url.'/Bootstrap-training/index.php';?>">BOOTSTRAP</a></li>
          <li><a href="<?php echo $url.'/JS-training/index.php';?>">JavaScript</a></li>
          <li><a href="<?php echo $url.'/JQuery-training/index.php';?>">jQuery</a></li>
        </ul>
      </div>
    </nav>
  </header>
  
  <section class="row">