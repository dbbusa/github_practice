var coll1 = document.getElementsByClassName("collapsible");
var i1;

for (i1 = 0; i1 < coll1.length; i1++) {
    coll1[i1].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
}

var coll2 = document.getElementsByClassName("collapsible1");
var i2;

for (i2 = 0; i2 < coll2.length; i2++) {
    coll2[i2].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
}

function hide_menu_content() {
    var x = window.matchMedia("(max-width: 768px)")
    if (x.matches) { // If media query matches
        document.getElementById("content1").style.display = "none";
    }
}

var coll3 = document.getElementsByClassName("collapsible2");
var i3;

for (i3 = 0; i3 < coll3.length; i3++) {
    coll3[i3].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "none") {
            content.style.setProperty("display", "block", "important");
        } else {
            content.style.setProperty("display", "none", "important");
        }
    });
}

// JS Module-1 Assignment

function js_mod1_asg_operations() {
    var num1 = Number(document.getElementById("num1").value);
    var num2 = Number(document.getElementById("num2").value);

    var operation = document.querySelector('input[name="operation"]:checked').value;

    var answer;

    switch (Number(operation)) {
        case 1:
            answer = num1 + num2;
            break;
        case 2:
            answer = num1 - num2;
            break;
        case 3:
            answer = num1 * num2;
            break;
        case 4:
            answer = num1 / num2;
            break;
        default:
            break;
    }
    document.getElementById("result").innerHTML = answer.toFixed(2);
}

function js_mod1_asg_resetAnswer() {
    document.getElementById("result").innerHTML = 0;
}

// JS Module-1 Practical

// Task 1

function JS_mod1_asg_task1() {
    var num1 = parseFloat(prompt("Enter 1st value :"));
    while (isNaN(num1)) {
        num1 = parseFloat(prompt("Please Enter Valid 1st value :"));
    }

    var num2 = parseFloat(prompt("Enter 2nd value :"));
    while (isNaN(num2)) {
        num2 = parseFloat(prompt("Please Enter Valid 2nd value :"));
    }

    var num3 = parseFloat(prompt("Enter 3rd value :"));
    while (isNaN(num3)) {
        num3 = parseFloat(prompt("Please Enter Valid 3rd value :"));
    }

    // Find the greater of these the number.

    if (num1 >= num2 && num1 >= num3) {
        alert("Greater of these the number : " + num1)
    }
    else if (num2 >= num3) {
        alert("Greater of these the number : " + num2)
    }
    else {
        alert("Greater of these the number : " + num3)
    }

    //Find the sum of that parseFloats which are greater than 40.

    var sum = 0;

    if (num1 > 40) {
        sum += num1;
    }
    if (num2 > 40) {
        sum += num2;
    }
    if (num3 > 40) {
        sum += num3;
    }

    alert("Sum of that parseFloats which are greater than 40 : " + sum);
}

// Task 2

function JS_mod1_asg_task2() {
    const arr = ['Botad', 'Bhavnagar', 'Rajkot', 'Amreli', 'Jamnagar'];
    arr.forEach(JS_mod1_asg_dispaly);
}

function JS_mod1_asg_dispaly(value) {
    alert(value);
}

// JS Module-2 Assignment

function JS_mod2_asg_action() {
    var dates = document.getElementById("mydate").value;
    var numbers = /^[0-9-+()]*$/;

    if (dates == "") {
        document.getElementById("error").innerHTML = "*Plese enter the date";
        document.getElementById("error").style.display = "block";
    }
    else if (!dates.match(numbers)) {
        document.getElementById("error").innerHTML = "*Date Must be in Digit Only";
        document.getElementById("error").style.display = "block";
    }
    else {
        document.getElementById("error").innerHTML = ""
        var mystring = String(dates);

        var splitdates = mystring.split("-");

        var month = splitdates[0];
        var date = splitdates[1];
        var year = splitdates[2];

        var temp_year = Number(year);
        var flag = Boolean((temp_year % 100 === 0) ? (temp_year % 400 === 0) : (temp_year % 4 === 0));


        if (!(dates.match(/^\d{2}\-\d{2}\-\d{4}$/)) || month > 12) {
            document.getElementById("error").innerHTML = "*Entered date should be in “”MM-DD-YYYY”” format";
            document.getElementById("error").style.display = "block";
        }
        else if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && date > 31) {
            document.getElementById("error").innerHTML = "Date Should be in 31";
        } else if (month == 4 || month == 6 || month == 9 || month == 11 && date > 31) {
            document.getElementById("error").innerHTML = "Date Should be in 30";
        } else if (flag === true && date > 29 && month == 2) {
            document.getElementById("error").innerHTML = "Date should be in 29";
        } else if (flag === false && date > 28 && month == 2) {
            document.getElementById("error").innerHTML = "Date should be in 28";
        }
    }
}

// JS Module-2 Prcatical

function JS_mod2_prc_task1() {
    var mystring1 = (prompt("Enter a String")).trim();
    while (mystring1.length === 0) {
        mystring1 = prompt("Your String is Empty please, enter again!!");
    }
}

function JS_mod2_prc_task2() {
    var mystring2 = (prompt("Enter a String")).trim();
    while (mystring2.length === 0) {
        mystring2 = prompt("Your String is Empty please, enter again!!");
    }
    var splitstring = mystring2.split("");
    alert("Split String in Array" + " " + splitstring);
}

function JS_mod2_prc_task3() {
    var mystring3 = (prompt("Enter a String")).trim();
    while (mystring3.length === 0) {
        mystring3 = prompt("Your String is Empty please, enter again!!");
    }
    var start_index = parseInt(prompt("Enter First Index"));
    var end_index = parseInt(prompt("Enter Last Index"));
    var new_string = mystring3.slice(start_index, end_index)
    alert("Your New Extract String From your string " + mystring3 + " " + "is : " + " " + new_string);
}

function JS_mod2_prc_task4() {
    var now = new Date();
    var todaydate = now.toDateString();
    document.getElementById("dates").innerHTML = "Today is " + todaydate;
    document.getElementById("dates").style.display = "block";
}

var my_array = new Array();
var temp_array = new Array();
function JS_mod2_prc_task5A() {
    var items = document.getElementById("items").value;
    my_array.push(items);
    console.log(my_array);
    temp_array = my_array
    document.getElementById("show").innerHTML = temp_array.toString().replace(/,/g, "<br>");
    document.getElementById("items").value = ""
}
function JS_mod2_prc_task5B() {
    my_array.pop();
    document.getElementById("show").innerHTML = temp_array.toString().replace(/,/g, "<br>");
}
function JS_mod2_prc_task5C() {
    my_array.shift();
    document.getElementById("show").innerHTML = temp_array.toString().replace(/,/g, "<br>");
}
function JS_mod2_prc_task5D() {
    var Uitems = document.getElementById("items").value;
    my_array.unshift(Uitems);
    document.getElementById("show").innerHTML = temp_array.toString().replace(/,/g, "<br>");
    document.getElementById("items").value = ""
}

//  JS Module-3 Assignment

function JS_mod3_asg_empId() {
    var id = document.getElementById("emp_id").value;

    if (id.length == 0) {
        document.getElementById("err_emp_id").innerHTML = "Please Enter EmployeeID";
    }
    else if (!id.match(/\w{5,}/g)) {
        document.getElementById("err_emp_id").innerHTML = "EmployeeID should be at least 5 character long.";
    }
    else if (!id.match(/([A-z]{1,}[0-9]{1,}|[0-9]{1,}[A-z]{1,})/g)) {
        document.getElementById("err_emp_id").innerHTML = "EmployeeID should have be at least 1 character and 1 digit.";
    }
    else {
        document.getElementById("err_emp_id").innerHTML = "";
    }
}

function JS_mod3_asg_empName() {
    var name = document.getElementById("emp_name").value;
    if (name.length == 0) {
        document.getElementById("err_emp_name").innerHTML = "Please Enter Employee Name";
    }
    else if (name.length < 2) {
        document.getElementById("err_emp_name").innerHTML = "Employee Name should be at least 2 character long.";
    }
    else if (!name.match(/^[A-z]+$/g)) {
        document.getElementById("err_emp_name").innerHTML = "Employee Name should be in character.";
    }
    else {
        document.getElementById("err_emp_name").innerHTML = "";
    }
}

function JS_mod3_asg_empAge() {
    var age = document.getElementById("emp_age").value;

    if (age.length == 0) {
        document.getElementById("err_emp_age").innerHTML = "Please Enter Employee Age";
    }
    else if (!age.match(/^[0-9]+$/g)) {
        document.getElementById("err_emp_age").innerHTML = "Employee Age  be in number.";
    }
    else if (!(age > 0 && age < 101)) {
        document.getElementById("err_emp_age").innerHTML = "Employee Age should be 0 to 100.";
    }
    else {
        document.getElementById("err_emp_age").innerHTML = "";
    }
}

function JS_mod3_asg_empDesignation() {
    var designation = document.getElementById("emp_designation").value;
    if (designation.length == 0) {
        document.getElementById("err_emp_designation").innerHTML = "Please Enter Employee Designation";
    }
    else if (designation.length < 2) {
        document.getElementById("err_emp_designation").innerHTML = "Employee Designation should be at least 2 character long.";
    }
    else if (!designation.match(/^[A-z]+$/g)) {
        document.getElementById("err_emp_designation").innerHTML = "Employee  Designation be in character.";
    }
    else {
        document.getElementById("err_emp_designation").innerHTML = "";
    }
}

function JS_mod3_asg_empSalary() {
    var salary = document.getElementById("emp_salary").value;

    if (salary.length == 0) {
        document.getElementById("err_emp_salary").innerHTML = "Please Enter Employee Age";
    }
    else if (!salary.match(/^[0-9]+$/g)) {
        document.getElementById("err_emp_salary").innerHTML = "Employee Salary be in number.";
    }
    else {
        document.getElementById("err_emp_salary").innerHTML = "";
    }
}

function JS_mod3_asg_empEmail() {
    var salary = document.getElementById("emp_email").value;

    if (salary.length == 0) {
        document.getElementById("err_emp_email").innerHTML = "Please Enter Employee Email Id.";
    }
    else if (!salary.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
        document.getElementById("err_emp_email").innerHTML = "Please Enter Valid Email Id.";
    }
    else {
        document.getElementById("err_emp_email").innerHTML = "";
    }
}

function JS_mod3_asg_empJoiningDate() {
    var dates = document.getElementById("emp_j_date").value;
    var numbers = /^[0-9-+()]*$/;

    if (dates == "") {
        document.getElementById("err_emp_joining_date").innerHTML = "*Plese enter the date";
    }
    else if (!dates.match(numbers)) {
        document.getElementById("err_emp_joining_date").innerHTML = "*Date Must be in Digit Only";
    }
    else {
        document.getElementById("err_emp_joining_date").innerHTML = "";
        var mystring = String(dates);

        var splitdates = mystring.split("-");

        var date = splitdates[0];
        var month = splitdates[1];
        var year = splitdates[2];

        var temp_year = Number(year);
        var flag = Boolean((temp_year % 100 === 0) ? (temp_year % 400 === 0) : (temp_year % 4 === 0));


        if (!(dates.match(/^\d{2}\-\d{2}\-\d{4}$/)) || month > 12) {
            document.getElementById("err_emp_joining_date").innerHTML = "*Entered date should be in “”DD-MM-YYYY”” format";
        }
        else if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && date > 31) {
            document.getElementById("err_emp_joining_date").innerHTML = "Date Should be in 31";
        } else if (month == 4 || month == 6 || month == 9 || month == 11 && date > 31) {
            document.getElementById("err_emp_joining_date").innerHTML = "Date Should be in 30";
        } else if (flag === true && date > 29 && month == 2) {
            document.getElementById("err_emp_joining_date").innerHTML = "Date should be in 29";
        } else if (flag === false && date > 28 && month == 2) {
            document.getElementById("err_emp_joining_date").innerHTML = "Date should be in 28";
        }
    }
}

function JS_mod3_asg_empContact() {
    var contact = document.getElementById("emp_contact").value;

    if (contact.length == 0) {
        document.getElementById("err_emp_Contact").innerHTML = "Please Enter Employee Contact Number";
    }
    else if (contact.match(/[A-z]/g)) {
        document.getElementById("err_emp_Contact").innerHTML = "Please Enter Employee Contact Number in digit.";
    }
    else if (!contact.match(/^[0-9]{10}$/g)) {
        document.getElementById("err_emp_Contact").innerHTML = "Please Enter valid Employee Contact Number.";
    }
    else {
        document.getElementById("err_emp_Contact").innerHTML = "";
    }
}

function JS_mod3_asg_sub_form() {

    JS_mod3_asg_empId();
    JS_mod3_asg_empName();
    JS_mod3_asg_empAge();
    JS_mod3_asg_empDesignation();
    JS_mod3_asg_empSalary();
    JS_mod3_asg_empEmail();
    JS_mod3_asg_empJoiningDate();
    JS_mod3_asg_empContact();


    // gender validation (Radio button)
    var gender = document.getElementsByName("emp_gender");
    var count = 0;
    for (const ans of gender) {

        if (ans.checked) {
            count += 1;
        }
    }
    if (count == 0) {
        document.getElementById("err_emp_gender").innerHTML = "Please Select Gender";
    }
    else {
        document.getElementById("err_emp_gender").innerHTML = "";
    }

    // locatio validation (Select Option)
    var location = document.getElementById("emp_location").value;
    if (location == 0) {
        document.getElementById("err_emp_location").innerHTML = "Please Select Location";
    }
    else {
        document.getElementById("err_emp_location").innerHTML = "";
    }

    return false;
}

function JS_mod3_asg_clearErr() {
    document.getElementById("err_emp_id").innerHTML = "";
    document.getElementById("err_emp_name").innerHTML = "";
    document.getElementById("err_emp_age").innerHTML = "";
    document.getElementById("err_emp_designation").innerHTML = "";
    document.getElementById("err_emp_salary").innerHTML = "";
    document.getElementById("err_emp_email").innerHTML = "";
    document.getElementById("err_emp_joining_date").innerHTML = "";
    document.getElementById("err_emp_Contact").innerHTML = "";
    document.getElementById("err_emp_gender").innerHTML = "";
    document.getElementById("err_emp_location").innerHTML = "";
}

// JS Module-3 Practical

//task-1
document.getElementById("demo1").innerHTML = "Hello";

//task-2
document.getElementsByTagName("p")[1].innerHTML = "Hello";

//task-3
document.getElementById("demo3").src = "img/nature.jpg";

//task-4
document.getElementById("demo4").value = "Have a nice day!";

//task-5
document.getElementById("demo5").style.color = "red";

//task-6
document.getElementById("demo6").style.display = "none";

//task-7
function JS_mod3_prc_task7() {
    document.location.assign("../Assignment/index.html");
}

//task-8
function JS_mod3_prc_task8() {
    window.history.back();
}

//task-9

let myWindow
function JS_mod3_prc_openWin() {
    myWindow = window.open("", "", "width=1080", "height=1080");
}

function JS_mod3_prc_resizedWin() {
    myWindow.resizeTo(300, 300);
}

// JS Module-4 Assignment

function JS_mod4_asg_disTime() {

    document.getElementById("exam_start").style.display = "none";
    document.getElementById("exam_runing").style.display = "block";

    var time = 59000;    //10800000(3 hour)

    var d_hour = time / (1000 * 60 * 60);
    var r_hour = parseInt(time / (1000 * 60 * 60));

    var d_mint = (d_hour - r_hour) * 60;
    var r_mint = parseInt((d_hour - r_hour) * 60);

    var r_sec = parseInt((d_mint - r_mint) * 60);

    var interval = setInterval(function () {
        document.getElementById("timer").innerHTML = "Coutdown " + r_hour.toString().padStart(2, 0) + ":" + r_mint.toString().padStart(2, 0) + ":" + r_sec.toString().padStart(2, 0);
        if (r_sec == 0 && r_mint == 0 && r_hour == 0) {
            alert("Your exam is auto submited and time out.");
            document.getElementById("exam_runing").style.display = "none";
            document.getElementById("exam_finish").style.display = "block";
            clearInterval(interval);
        }
        else if (r_sec == 10 && r_mint == 0 && r_hour == 0) {   // warning message 
            alert("you have only 10 second left.");
        }
        else if (r_sec == 0 && r_mint == 0) {
            r_hour -= 1;
            r_mint = 59;
            r_sec = 60;
        }
        else if (r_sec == 0) {
            r_mint -= 1;
            r_sec = 60;
        }
        r_sec -= 1;
    }, 1000);
}

function JS_mod4_asg_sbExam() {
    var val = confirm("Are you sure your exam submited ?");
    if (val) {
        document.getElementById("exam_runing").style.display = "none";
        document.getElementById("exam_finish").style.display = "block";
    }
}

function JS_mod4_asg_reExam() {
    document.getElementById("exam_start").style.display = "block";
    document.getElementById("exam_finish").style.display = "none";
}

// JS Module-4 Practical

// task-1
function JS_mod4_prc_task1() {
    var num = document.getElementById("task_1").value;
    if (!num.match(/^[0-9]+$/g)) {
        document.getElementById("dis_1").innerHTML = "Argument be in number.";
    }
    else {
        JS_mod4_prc_MyCalculater(num, JS_mod4_prc_MyDisplayer);
    }

}

function JS_mod4_prc_MyCalculater(num, myCallback) {
    var res = num * num;
    myCallback(res);
}

function JS_mod4_prc_MyDisplayer(res) {
    document.getElementById("dis_1").innerHTML = "Result : " + res;
}

//task-2
function JS_mod4_prc_task2_submit() {
    var x = "John Doe";
    var x = 0;
    document.getElementById("dis_2_1").innerHTML = "Output : x = " + x;

    let y = "John Doe";
    //let y = 0; 
    document.getElementById("dis_2_2").innerHTML = "Output : SyntaxError - 'x' has already been declared";

    var z = 10;
    {
        var z = 2;
    }
    document.getElementById("dis_2_3").innerHTML = "Output : x = " + z;

    let w = 10;
    {
        let w = 2;
    }
    document.getElementById("dis_2_4").innerHTML = "Output : x = " + w;
}

function JS_mod4_prc_task2_reset() {
    document.getElementById("dis_2_1").innerHTML = "";
    document.getElementById("dis_2_2").innerHTML = "";
    document.getElementById("dis_2_3").innerHTML = "";
    document.getElementById("dis_2_4").innerHTML = "";
}

//task-3
function JS_mod4_prc_task3() {
    let myPromise = new Promise(function (myResolve, myReject) {
        var str = document.getElementById("task_3").value;

        setTimeout(function () {
            if (str.match(/^[A-z]+$/g)) {
                myResolve([...str].reverse().join(""));
            }
            else {
                myReject("Wrong Input Please enter character.");
            }
        });
    });

    myPromise.then(
        function (value) { myDisplayer(value); },
        function (error) { myDisplayer(error); }
    );

    function myDisplayer(res) {
        document.getElementById("dis_3").innerHTML = res;
    }
}

// JS Module-5 Practical

//task-1


function JS_mod5_asg_task1() {

    let area1 = function (no) {
        return 3.14 * no * no;
    }

    var num = document.getElementById("tsk1").value;
    if (num == "") {
        document.getElementById("res1").innerHTML = "Please enter the number.";
    }
    else if (!num.match(/^\d+$/g)) {
        document.getElementById("res1").innerHTML = "Number must be in digit.";
    }
    else {
        document.getElementById("res1").innerHTML = "Result : " + area1(num).toFixed(2);
    }
}

//task-2



function JS_mod5_asg_task2() {

    let area2 = new Function("x", "y", "return x * y");

    var num1 = document.getElementById("tsk2_1").value;
    var num2 = document.getElementById("tsk2_2").value;

    if (num1 == "") {
        document.getElementById("err2_1").innerHTML = "Please enter the 1st number.";
    }
    else if (!num1.match(/^\d+$/g)) {
        document.getElementById("err2_1").innerHTML = "1st number must be in digit.";
    }
    else {
        document.getElementById("err2_1").innerHTML = "";
    }

    if (num2 == "") {
        document.getElementById("err2_2").innerHTML = "Please enter thu 2nd number.";
    }
    else if (!num2.match(/^\d+$/g)) {
        document.getElementById("err2_2").innerHTML = "2nd number must be in digit.";
    }
    else {
        document.getElementById("err2_2").innerHTML = "";
        document.getElementById("res2").innerHTML = "Result : " + area2(num1, num2).toFixed(2);
    }
}

//task-3

function JS_mod5_asg_task3() {

    var x = function () {
        document.getElementById("res3").innerHTML = "Hello Everyone.";
    }
    x();
}

//task-4

function JS_mod5_asg_display2(obj) {
    document.getElementById("res4").innerHTML = "Name : " + obj.name + "<br>Address : " + obj.adrress + "<br>Designation : " + obj.designation;
}

function JS_mod5_asg_task4() {

    var char1 = document.getElementById("tsk4_1").value;
    var char2 = document.getElementById("tsk4_2").value;
    var char3 = document.getElementById("tsk4_3").value;

    if (char1 == "") {
        document.getElementById("err4_1").innerHTML = "Please enter the name.";
    }
    else if (!char1.match(/^[A-z]+$/g)) {
        document.getElementById("err4_1").innerHTML = "Name must be in charcter.";
    }
    else {
        document.getElementById("err4_1").innerHTML = "";
    }

    if (char2 == "") {
        document.getElementById("err4_2").innerHTML = "Please enter the address.";
    }
    else if (!char2.match(/^[A-z]+$/g)) {
        document.getElementById("err4_2").innerHTML = "Address must be in charcter.";
    }
    else {
        document.getElementById("err4_2").innerHTML = "";
    }

    if (char3 == "") {
        document.getElementById("err4_3").innerHTML = "Please enter the Designation.";
    }
    else if (!char3.match(/^[A-z]+$/g)) {
        document.getElementById("err4_3").innerHTML = "Designation must be in charcter.";
    }
    else {
        document.getElementById("err4_3").innerHTML = "";
        var object = {
            name: char1,
            adrress: char2,
            designation: char3
        }
        JS_mod5_asg_display2(object);
    }
}

//task-5

function JS_mod5_asg_task5() {

    var person = {
        fullname: function () {
            return "Full Name : " + this.f_name + " " + this.l_name;
        }
    }

    var f_name = document.getElementById("tsk5_1").value;
    var l_name = document.getElementById("tsk5_2").value;


    if (f_name == "") {
        document.getElementById("err5_1").innerHTML = "Please enter the First Name.";
    }
    else if (!f_name.match(/^[A-z]+$/g)) {
        document.getElementById("err5_1").innerHTML = "First Name must be in charcter.";
    }
    else {
        document.getElementById("err5_1").innerHTML = "";
    }

    if (l_name == "") {
        document.getElementById("err5_2").innerHTML = "Please enter the Second Name.";
    }
    else if (!l_name.match(/^[A-z]+$/g)) {
        document.getElementById("err5_2").innerHTML = "Second Name must be in charcter.";
    }
    else {
        document.getElementById("err5_2").innerHTML = "";
        var person1 = {
            f_name: f_name,
            l_name: l_name
        }
        var name = person.fullname.apply(person1);
        document.getElementById("res5").innerHTML = name;
    }

}

//task-6


function JS_mod5_asg_task6() {

    let count123 = (function () {
        let counter = 0;
        return function () {
            counter += 1;
            return counter;
        };
    })();

    document.getElementById("res6").innerHTML = "Result : " + count123();
}


// JS Module-6 Assignment index page js

function JS_mod6_asg_fecthJson() {
    getJson("assets/index.json");
    async function getJson(file) {
        let data = await fetch(file);
        let myJson = await data.json();

        localStorage.setItem('myJsonData', JSON.stringify(myJson));
    }
}

// JS Module-6 Assignment product page js

async function JS_mod6_asg_productShow() {
    var getJson = localStorage.getItem('myJsonData');
    var myJson = JSON.parse(getJson);
    //console.log(myJson);

    var count = 1;

    let str = "<table><tr style='background-color: #FF8800 !important;'><th>Product Id</th><th>Name</th><th>Price</th><th>Quantity</th><th>Add to cart</th></tr>";

    for (let id in myJson.products) {
        var loc = myJson.products[id];
        str += "<tr><td class='id'>" + count + "</td><td class='name'>" + loc.Name + "</td><td class='price'>" + loc.Price + "</td><td class='quantity'>" + loc.Quantity + "</td><td><input type='button' class='btn btn-outline-success btn-sm' value='Add to cart' onclick='JS_mod6_asg_addCart(this)' class='btn'></td></tr>";
        count += 1;
    }
    str += "</tabel>";
    document.getElementById("showData").innerHTML = str;
}

function JS_mod6_asg_addCart(e) {
    var id = e.closest("tr").querySelector(".id").innerHTML;
    var name = e.closest("tr").querySelector(".name").innerHTML;
    var price = e.closest("tr").querySelector(".price").innerHTML;
    var quantity = e.closest("tr").querySelector(".quantity").innerHTML;
    var cartJson = {};

    //localStorage.removeItem('cart');

    if (localStorage.getItem("cart") == null) {
        cartJson[id] = { "Name": name, "Price": price, "Quantity": quantity };
        localStorage.setItem("cart", JSON.stringify(cartJson));
    }
    else {
        var str = localStorage.getItem("cart");
        var str1 = JSON.parse(str);
        str1[id] = { "Name": name, "Price": price, "Quantity": quantity };
        localStorage.setItem("cart", JSON.stringify(str1));
    }
    alert("Your iteam '" + name + "' is added to cart in successfully");
}



// JS Module-6 Assignment product page js


async function JS_mod6_asg_cartShow() {
    var getJson = localStorage.getItem('cart');
    var myJson = JSON.parse(getJson);
    console.log(myJson);

    var count = 1;

    let str = "<table><tr style='background-color: #FF8800 !important;'><th>Product Id</th><th>Name</th><th>Price</th><th>Quantity</th><th>Remove to cart</th></tr>";

    for (let id in myJson) {
        var loc = myJson[id];
        str += "<tr><td class='id' style='display:none'>" + id + "</td><td>" + count + "</td><td class='name'>" + loc.Name + "</td><td class='price'>" + loc.Price + "</td><td class='quantity'>" + loc.Quantity + "</td><td><input type='button' value='Remove to cart' class='btn btn-outline-danger btn-sm' onclick='JS_mod6_asg_removeCart(this)' class='btn'></td></tr>";
        count += 1;
    }
    str += "</tabel>";
    document.getElementById("showData").innerHTML = str;
}

function JS_mod6_asg_removeCart(e) {
    var id = e.closest("tr").querySelector(".id").innerHTML;
    var name = e.closest("tr").querySelector(".name").innerHTML;
    var str = localStorage.getItem("cart");
    var str1 = JSON.parse(str);
    delete str1[id];
    localStorage.setItem("cart", JSON.stringify(str1));
    alert("Your iteam '" + name + "' is removed to cart in successfully");
    location.reload();
}

// JS Module-7 Practical

function JS_mod7_prc_varLetExample() {
    var numVar = 100; // Function level
    let numLet = 100; // Function level
    const numConst = 10; // Function level

    document.getElementById('dispResult').innerHTML = "";

    // Block of Var Variable
    {
        var numVar = 200 // Block level declaration
        document.getElementById('dispResult').innerHTML += "numVar inside block - " + numVar;
    }
    document.getElementById('dispResult').innerHTML += "<br>numVar inside function - " + numVar;

    // Block of Let Variable
    {
        let numLet = 2000 // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>numLet  inside block - " + numLet;
    }
    document.getElementById('dispResult').innerHTML += "<br>numLet inside function - " + numLet;

    // Block of const Variable
    {
        const numConst = 200; // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>numConst inside function - " + numConst;
    }

    document.getElementById('dispResult').innerHTML += "<br>numConst inside function - " + numConst;
}

function JS_mod7_prc_stringTemplate() {
    const employee = {
        name: "John Doe",
        city: "Mumbai",
        skills: ["Backend", "Frontend", "Cloud"],
    };
    let details = `
     <p style='padding:0px !important'> Name : ${employee.name} </p>
     <p style='padding:0px !important'> City : ${employee.city} </p>
     <p style='padding:5px !important'> Skills : </p>
     <ul>
         ${employee.skills.map(skill => {
        return `<li> ${skill} </li>`;
    }).join("")
        }
     </ul>`;
    document.getElementById('disStringTemp').innerHTML = details;
}


function JS_mod7_prc_taggedTemplate() {
    const author = "Some Author";
    const statement = "Some Statement";
    const resTemp = highlight`Here is the ${statement} by ${author} and it could not be more true.`;

    console.log(resTemp);
    document.getElementById('disTaggedStringTemp').innerHTML = resTemp;

    function highlight(text, ...extras) {
        let res = text.map((item, index) => {
            return `${item} <strong style='color:blue'>${extras[index] || ''}</strong>`
        });
        return res.join("")
    }
}

function JS_mod7_prc_swapValue() {
    let f_name = "Ankit", l_name = "Chauhan";
    var data = "Before Swap : f_name = " + f_name + ", l_name = " + l_name;

    [l_name, f_name] = [f_name, l_name];

    data += "<br> After Swap : f_name = " + f_name + ", l_name = " + l_name;

    document.getElementById('disSwapTemp').innerHTML = data;
}

function JS_mod7_prc_forOfFunction() {
    const arryaObj = ['item 1', 'item 2', 'item 3', 'item 4', 'item 5'];
    let disForData = "";
    for (let val of arryaObj) {
        disForData += val + "<br>";
    }

    document.getElementById('disForData').innerHTML = disForData;
}

// JS Practice

function JS_Practice() {
    let colours = ["Red", "Green", "Blue"]
    console.log(colours)
    let shades = ["Orange", "lightGreen", "indigo", "pink", "purple"]
    console.log(shades)

    /*Concate()*/
    let add = colours.concat(shades)
    console.log(add)

    /*copyWithin()*/
    console.log(colours.copyWithin(1, 2))
    console.log(colours.copyWithin(2, 0, 3))

    /*entries()*/
    const c = colours.entries();
    console.log(c);
    for (let x of c) {
        console.log(x)
        console.log(x[0])
    }

    /*every()*/
    const ages = [12, 3, 39, 40];
    const result = ages.every(checkAge);
    console.log(result)
    function checkAge(age) {
        return age > 18;
    }

    /*fill()*/
    console.log(colours)
    console.log(colours.fill("white"))
    console.log(colours)
    console.log(shades.fill("black", 1, 3))
    console.log(shades.fill("black", 1))

    /*filter()*/
    const new_age = ages.filter(checkall)
    console.log(new_age)
    function checkall(age) {
        return age > 18
    }

    /*find()*/
    const find_first = ages.find(findone);
    console.log(find_first)
    function findone(age) {
        return age > 18
    }

    const find_index = ages.findIndex(findone)
    console.log(find_index)

    /*forEach()*/
    const fruits = ["apple", "orange", "cherry", "pineapple", "apple", "grapes", "apple"]
    fruits.forEach(myfruit)
    function myfruit(item, index) {
        console.log(` ${index} ${item}`)
    }

    /*from()*/
    const myname = "ARAZU KANERIYA"
    console.log(Array.from(myname))

    /*includes()*/
    console.log(fruits.includes("apple"))
    console.log(fruits.includes("cherry", 2))

    /*indexOf()*/
    console.log(fruits.indexOf("apple"))
    console.log(fruits.indexOf("apple", 3))

    /*isArray()*/
    console.log(Array.isArray(fruits))
    console.log(Array.isArray(myname))

    /*join()*/
    console.log(fruits.join(" "))

    /*keys()*/
    let keys = fruits.keys()
    let temp = "";
    for (let y of keys) {
        temp += y + "\n"
    }
    console.log(temp)
    keys = Object.keys(fruits)
    console.log(temp)

    /*lastIndexOf()*/
    console.log(fruits.lastIndexOf("apple"))

    /*Map()*/
    const numbers = [4, 9, 16, 25];
    console.log(numbers.map(new_num))
    function new_num(num) {
        return num * 10
    }

    /*pop()*/
    console.log(fruits)
    fruits.pop()
    console.log(fruits)

    /*push()*/
    console.log(fruits)
    fruits.push("kiwi")
    console.log(fruits)
    fruits.push("Kiwi", "Lemon");
    console.log(fruits)

    /*reduce()*/
    let digit = [175, 50, 25]
    const result1 = digit.reduce(getsum);
    console.log(result1)
    function getsum(total, num) {
        return total - num
    }

    /*reduceRight()*/
    const result2 = digit.reduceRight(getsub)
    console.log(result2)
    function getsub(total, num) {
        return total - num
    }

    /*reverse()*/
    console.log(digit.reverse())

    /*shift()*/
    console.log(fruits)
    console.log(fruits.shift())
    console.log(fruits)

    /*Slice()*/
    console.log(fruits.slice(1, 3))
    console.log(fruits)
    console.log(fruits.slice(-3, -1))

    /*some()*/
    const value = digit.some((age) => { return age > 200 })
    console.log(value)

    /*sort()*/
    console.log(fruits)
    console.log(fruits.sort())

    /*splice()*/
    console.log(digit)
    digit.splice(2, 0, 22, 28)
    console.log(digit)
    digit.splice(1, 2)
    console.log(digit)

    /*toString()*/
    console.log(fruits.toString())

    /*unshift()*/
    console.log(fruits)
    console.log(fruits.unshift("Chikko", "watermelon"))
    console.log(fruits)

    /*valueOf()*/
    console.log(fruits.valueOf())

    /*constructor*/
    console.log(fruits.constructor)

    /*length*/
    console.log(fruits.length)
    fruits.length = 5
    console.log(fruits)
}


// JQuery Module-1 Assignment

function JQuery_mod1_asg_Show() {

    var country = ['India', 'Russia', 'Spain', 'America', 'Zimbabwe'];
    var str = "Country : ";
    for (let arr of country) {
        $("#country").append("<option value='" + arr + "'>" + arr + "</option>");
        str += arr + ", ";
    }

    var dis_country = str.substring(0, str.length - 2);
    $("#display").html(dis_country);

    $("#country").change(function () {
        var res = $(this).val();
        if (res != 'default') {
            $("#display").html("Your Selected Country : " + res);
        }
        else {
            $("#display").html(dis_country);
        }
    });
}

// JQuery Module-1 Practice


function JQuery_mod1_prc_Show() {

    $(".task-1").css("background-color", "blue");

    $(".task-2").hover(function () {
        $(this).hide();
    },
        function () {
            $(this).show();
        })

    $('input[name="technology"]').change(function () {
        var res = $(this).val();
        $("#sel_technology").html("You have selected : " + res);
    });
}

// JQuery Module-2 Assignment

function JQuery_mod2_asg_Show() {

    $.getJSON("https://gorest.co.in/public-api/users", function (data) {
        let str = "<table><tr style='background-color: #FF8800 !important;'><th>Product Id</th><th>Name</th><th>Price</th><th>Quantity</th><th>Add to cart</th></tr>";
        $.each(data.data, function (index, result) {
            str += `<tr><td>${result.id}</td><td>${result.name}</td><td>${result.email}</td><td>${result.gender}</td><td>${result.status}</td></tr>`;
        });
        str += "</tabel>";
        $("#showData").html(str);
    });
}

// JQuery Module-2 Practical

function JQuery_mod2_prc_Show() {
    $(".small1").parent().css("color", "red");
    $(".small2").parents('.div2').css("color", "red");
    $(".small3").parentsUntil('.div3').css("color", "red");
    $(".span4").children().css("color", "red");
    $(".div5").find('span').css("color", "red");
    $(".p6").first().css("color", "red");
    $(".p7").last().css("color", "red");
    $(".p8").eq(1).css("color", "red");
    $(".p9").filter('.intro').css("color", "red");
    $(".p10").not('.intro').css("color", "red");

    $.post("https://reqres.in/api/users",
        {
            name: "Donald Duck",
            job: "Full Stack Devloper"
        },
        function (data) {
            $(".div13").html("Name : " + data.name + "<br> Job : " + data.job);
        });

}

