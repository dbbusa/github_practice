<aside aria-label="" class="column_left">
    <ul id="show3">
        <li class="module">
            <button type="button" class="collapsible">Module-1</button>
            <div class="content">
                <ul class="task">
                    <li><a href="./Module 1/Practical/index.html" targte="_blank">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-2</button>
            <div class="content">
                <ul class="task">
                    <li><a href="./Module 2/Assignment/index.html">Assignment</a></li>
                    <li><a href="">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-3</button>
            <div class="content">
                <ul class="task">
                    <li><a href="" target="_blank">Assignment</a>
                        <ol style="list-style-type:none">
                            <li> <a href="./Module 3/Assignment/index.html" target="_blank">LoopLAB Project</a></li>
                        </ol>
                    </li>

                    <li><a href="" target="_blank">Practical</a>
                        <ol style="list-style-type:none">
                            <li> <a href="./Module 3/Practical/index.html" target="_blank">Album Page</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-5</button>
            <div class="content">
                <ul class="task">
                    <li><a href="">Assignment</a>
                        <ol style="list-style-type:none">
                            <li> <a href="./Module 5/Assignment/Blogen Project/index.html" target="_blank">Blogen Project</a></li>
                            <li> <a href="./Module 5/Assignment/Mizuxe Project/index.html" target="_blank">Mizuxe Project</a></li>
                            <li> <a href="./Module 5/Assignment/Protfolio Project/index.html" target="_blank">Protfolio Project</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Project</button>
            <div class="content">
                <ul class="task">
                    <li> <a href="./CarWale Project/Assignment/index.html" target="_blank">CarWale Project</a></li>
                </ul>
            </div>
        </li>
    </ul>
</aside>