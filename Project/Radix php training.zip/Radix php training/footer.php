                <footer>
                    <p>@copyright ankitchauhan0891@gmail.com</p>
                </footer>
            </aside>
        </section>
    <script src="<?php echo $url.'/assets/js/custom.js';?>"></script>
</body>

</html>