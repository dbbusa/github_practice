<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod3_prc">
    <h1 class="path">CSS / Module-3 / Practical</h1>
    <div class="right_content">
        <div class="body">
            <section class="task1">
                <h1>Task-1 : Set the width of the div tag element to "200px".</h1>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>

            <section class="task2">
                <h1>Task-2 : Set the width of the div tag element to "200px".</h1>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>

            <section class="task3">
                <h1>Task-3 : Add 25 pixels space between the div tag element's border and it's content..</h1>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>

            <section class="task4">
                <h1>Task-4 : Add a 25 pixels space outside, to the left of the div tag element.</h1>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>

            <section class="task5">
                <h1>Task-5 : Create a flexbox with four flex items.</h1>
                <div class="flex-container">
                    <div class="box">1</div>
                    <div class="box">2</div>
                    <div class="box">3</div>
                    <div class="box">4</div>
                </div>
            </section>

            <section class="task6">
                <h1>Task-6 : Flexbox with three flex items - right to left direction</h1>
                <div class="flex-container">
                    <div class="box">1</div>
                    <div class="box">2</div>
                    <div class="box">3</div>
                </div>
            </section>

            <section class="task7">
                <h1>Task-7 : Flexbox image gallery</h1>
                <div class="flex-container">
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/falls2.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/nature.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mist.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/ocean.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mountainskies.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/falls2.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/nature.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mist.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/ocean.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mountainskies.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php include '../footer.php'; ?>