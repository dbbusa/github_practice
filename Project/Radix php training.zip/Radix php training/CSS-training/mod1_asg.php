<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right HTML_mod2_asg">
    <h1 class="path">HTML / Module-2 / Assignment</h1>
    <div class="right_content">
        <section class="flex-container">
            <aside aria-label="" class="left">
                <div class="name">
                    <h1>ANKIT CHAUHAN</h1>
                    <p>COMPUTER ENGINEER</p>
                </div>
                <div class="info">
                    <h1 class="title_left">P E R S O N A L &nbsp; &nbsp; I N F O R M A T I O N</h1>
                    <div class="details_info_left">
                        <p><strong>Name</strong> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            &nbsp;
                            &nbsp;
                            &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Ankit
                            Chauhan
                        </p>
                        <p><strong>DOB</strong> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            &nbsp;
                            &nbsp;
                            &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;8th
                            September
                            2001
                        </p>
                        <p><strong>Known Language </strong> &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp; &nbsp;
                            &nbsp;
                            &nbsp;
                            &nbsp; &nbsp; &nbsp;&nbsp;English, Hindi, Gujarati.</p>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">A C A D E M I C &nbsp; &nbsp; P R O F I L E</h1>
                    <div>
                        <ul style="list-style-type: none;">
                            <li><strong>RK University, Rajkot.</strong></li>
                            <ul class="pb" style="list-style-type: disc;">
                                <li><strong>Pursuing - B. Tech. Computer Engineering, 2018-22.</strong></li>
                                <ul style="list-style-type: none;">
                                    <li>SCORE : CGPA - 8.60 (till 6th sem.)</li>
                                </ul>
                            </ul>
                            <li><strong>Shree Daxinamurti Vidhyalay, Botad.</strong></li>
                            <ul style="list-style-type: disc;">
                                <li><strong>Higher Secondary School Certified, 2018</strong></li>
                                <ul style="list-style-type: none;">
                                    <li>SCORE : 65.85%</li>
                                </ul>
                            </ul>
                            <ul style="list-style-type: disc;">
                                <li><strong>Senior Secondary School Certified, 2016</strong></li>
                                <ul style="list-style-type: none;">
                                    <li>SCORE : 80.33%</li>
                                </ul>
                            </ul>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">P R O J E C T S</h1>
                    <div>
                        <ul>
                            <li><strong>Java Projects :</strong> Grocery Web Application using Servlet,JSP & JDBC.</li>
                            <li><strong>Android Projects :</strong> Tic-Tac-Toe & Binary Calculator applications.</li>
                            <li><strong>PHP Projects :</strong> procodefree.tech, Mini Proj. Using CodeIgniter Framework.</li>
                            <li><strong>Python Projects :</strong> Countdown Timer, SnakeGame using Tinkercad or GUI.</li>
                            <li><strong>Personal Portfolio :</strong> ankitchauhan.epizy.com</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">C E R T I F I C A T I O N</h1>
                    <div>
                        <ul>
                            <li>IIT Bombay, Coursera, Cisco, SoloLearn Certified in Various
                                Programming Language courses.</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">A C H I E V E M E N T S</h1>
                    <div>
                        <ul>
                            <li>Pass out the exam taken by IIT Bombay of Completion of CPP Training.</li>
                            <li>Coursera certifies their successful completion of the University of
                                Michigan Python for Everybody Specialization.
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">C O - C U R R I C U L A R &nbsp; &nbsp; A C T I V I T I E S</h1>
                    <div>
                        <ul>
                            <li>Participated in SSIP Smart City Hackathon, Rajkot.</li>
                            <li>Participated in Envision'20 and various workshops.</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_left">R E F E R E N C E S</h1>
                    <div>
                        <ul>
                            <li class="pb">
                                <strong>Dr. Paresh Tanna</strong><br>
                                Associate Professor of RK University, Rajkot.<br>
                                +91 972-434-7177
                            </li>
                            <li>
                                <strong>Kapildev Naina</strong><br>
                                Associate Professor of RK University, Rajkot.<br>
                                +91 90330 97040
                            </li>
                        </ul>
                    </div>
                </div>
            </aside>
            <aside aria-label="" class="right">
                <div>
                    <img src="../assets/images/avtar.jpg" alt="profile image" />
                </div>
                <div>
                    <h1 class="title_right">CAREER OBJECTIVE</h1>
                    <div class="details_info_right">
                        <p>To work as a (job role being offered) in
                            your progressive organization that allows
                            me the scope to update my knowledge to
                            the latest trends and be part of a diverse
                            and dynamic team that adds to both my
                            personal and professional growth.
                        </p>
                    </div>
                    <div>
                        <h1 class="title_right">AREA OF INTEREST</h1>
                        <div>
                            <ul>
                                <li> Web Development</li>
                                <li> Coding & Practice</li>
                                <li> Learning</li>
                                <li> Sports Activity</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div>
                    <h1 class="title_right">TECHNICAL SKILLS</h1>
                    <div>
                        <ul>
                            <li> Java</li>
                            <li> Python</li>
                            <li> PHP</li>
                            <li> HTML5 / CSS3</li>
                            <li> C</li>
                            <li> C++</li>
                            <li> Android</li>
                            <li> Data Structure / Algorithm</li>
                            <li> JavaScript</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_right">INTERPERSONAL SKILLS</h1>
                    <div>
                        <ul>
                            <li> Creative Thinking</li>
                            <li> Teamwork</li>
                            <li> Leadership</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <h1 class="title_right">CONTACT ME AT</h1>
                    <div>
                        <ul style="list-style-type: none !important; margin-left: 0px !important;">
                            <li><em class="fa fa-phone" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;+91
                                    906-711-7191</strong></li>
                            <li><em class="fa fa-envelope-open" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;achauhan645@rku.ac.in</strong></li>
                            <li><em class="fa fa-skype" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;live:.cid.a39e2600fcbd0f42</strong></li>
                            <li><em class="fa fa-linkedin-square" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;ankitchauhan0809</strong></li>
                            <li><em class="fa fa-desktop" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;ankitchauhan.epizy.com</strong>
                            </li>
                            <li><em class="fa fa-map-marker" style="font-size:14px"></em><strong>&nbsp;&nbsp;&nbsp;Patel Society,
                                    Hifali,
                                    Botad -<br>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 364710. Ta - Botad, Dist. - Botad,<br>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gujatat, India</strong></li>
                        </ul>
                    </div>
                </div>
            </aside>
        </section>
        <section>
            <video id="video" width="100%" style="padding-top: 50px;" controls preload="metadata">
                <source src="../assets/videos/resume.mp4" type="video/mp4" />
                <track label="English" kind="captions" srclang="en" src="./videos/project" default>
            </video>
        </section>
    </div>

    <?php include '../footer.php'; ?>