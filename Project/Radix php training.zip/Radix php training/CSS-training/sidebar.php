<aside aria-label="" class="column_left">
    <ul id="show2">
        <li class="module">
            <button type="button" class="collapsible">Module-1</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod1_asg.php">Assignment</a></li>
                    <li><a href="mod1_prc.php">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-2</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod2_asg_index.php">Assignment</a></li>
                    <li><a href="mod2_prc.php">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-3</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod3_asg.php">Assignment</a></li>
                    <li><a href="mod3_prc.php">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-4</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod4_asg.php">Assignment</a></li>
                    <li><a href="mod4_prc.php">Practical</a></li>
                    <li><a href="mod4_res.php">Resume</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-5</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod5_asg.php">Assignment</a></li>
                </ul>
            </div>
        </li>
    </ul>
</aside>