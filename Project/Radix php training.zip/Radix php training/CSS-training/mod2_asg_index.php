<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod2_asg">
    <h1 class="path">CSS / Module-2 / Assignment</h1>
    <div class="right_content">
        <header>
            <nav aria-label="">
                <ul>
                    <li><img src="../assets/images/bootstrap-solid.svg" class="brand_logo" height="40px" width="40px" alt="logo" /></li>
                    <li><a href="mod2_asg_home.php">Home</a></li>
                    <li><a href="mod2_asg_about_us.php">About Us</a></li>
                    <li><a href="mod2_asg_contact_us.php">Contact US</a></li>
                </ul>
            </nav>
        </header>

        <section>
            <aside aria-label="" class="left">
                <a href="">Module 1</a>
                <a href="">Module 2</a>
                <a href="">Module 3</a>
                <a href="">Module 4</a>
                <a href="">Module 5</a>
                <a href="">Module 6</a>
                <a href="">Module 7</a>
            </aside>

            <aside aria-label="" class="right">
                <h1 style="font-size:50px;">Welcome Everyone !!</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sit amet eleifend tellus.
                    Nullam tincidunt
                    suscipit nunc scelerisque suscipit. Donec eu justo cursus, porttitor elit quis, cursus eros.
                    Sed
                    ultricies lacus id turpis congue, sit amet condimentum neque tristique. Integer vel ex
                    pharetra, rhoncus
                    eros maximus, eleifend felis. Donec non ligula nec purus cursus vulputate. Pellentesque sed
                    risus sed
                    magna luctus commodo.</p>

                <p>Phasellus scelerisque ac diam a condimentum. Suspendisse sit amet scelerisque augue. Aenean
                    molestie
                    condimentum est eu sollicitudin. Suspendisse et convallis sapien, et commodo ipsum. Morbi
                    hendrerit,
                    ipsum nec egestas pretium, sem tortor volutpat erat, sed egestas eros urna et tellus. Nunc
                    ultrices
                    augue ligula, rutrum feugiat ipsum ultricies ut. Duis lobortis magna eu cursus euismod.
                    Integer sit amet
                    enim laoreet, rutrum sapien sit amet, venenatis neque. Aenean placerat rutrum nibh, quis
                    faucibus nibh
                    mattis in. Aliquam fermentum viverra mauris, sit amet lacinia arcu lobortis sit amet. In a
                    est eget
                    tellus tincidunt eleifend vehicula id justo. Etiam vestibulum tincidunt nulla, in tristique
                    nisl mollis
                    sed.</p>
            </aside>
        </section>

        <footer class="sub_footer">
            <h1>@copyright ankitchauhan0891@gmail.com</h1>
        </footer>
    </div>

    <?php include '../footer.php'; ?>