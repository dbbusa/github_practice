<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod4_prc">
    <h1 class="path" style="margin: 0px !important;">CSS / Module-4 / Practical</h1>
    <div class="right_content">
        <div class="body">
            <section>
                <h1> Task-1 : You have one h1 and one paragraph in your page with blue color border. For all the
                    media screen
                    and query selector (maximum width 768px) it should be change to red color border.</h1>
                <div class="task-1">
                    <h1 class="center-text">Lorem Ipsum</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mattis accumsan mollis.
                        Cras eros odio, lobortis vitae fringilla vel, tincidunt a dolor. Etiam erat ipsum,
                        convallis vitae laoreet mollis, aliquet nec dolor. Pellentesque scelerisque nibh eget
                        euismod eleifend. Nulla nec mi nisl. Sed convallis, nulla ac placerat sollicitudin, sem
                        leo luctus diam, quis placerat libero augue sit amet enim. Etiam et tempor eros.
                        Suspendisse convallis eget ex vel viverra. Nullam vel arcu quis orci malesuada ultricies
                        eu at ante. Maecenas purus erat, interdum in gravida in, consectetur sit amet ante. Nunc
                        eget pellentesque dolor.
                    </p>
                </div>
            </section>

            <section>
                <h1> Task-2 : Media queries with breakpoint</h1>
                <div class="task-2">
                    <h1 class="center-text">Lorem Ipsum</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mattis accumsan mollis.
                        Cras eros odio, lobortis vitae fringilla vel, tincidunt a dolor. Etiam erat ipsum,
                        convallis vitae laoreet mollis, aliquet nec dolor. Pellentesque scelerisque nibh eget
                        euismod eleifend. Nulla nec mi nisl. Sed convallis, nulla ac placerat sollicitudin, sem
                        leo luctus diam, quis placerat libero augue sit amet enim. Etiam et tempor eros.
                        Suspendisse convallis eget ex vel viverra. Nullam vel arcu quis orci malesuada ultricies
                        eu at ante. Maecenas purus erat, interdum in gravida in, consectetur sit amet ante. Nunc
                        eget pellentesque dolor.
                    </p>
                </div>
            </section>

            <section>
                <h1> Task-3 : Hide elements with Media queries</h1>
                <div class="task-3">
                    <h1 class="center-text">Lorem Ipsum</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mattis accumsan mollis.
                        Cras eros odio, lobortis vitae fringilla vel, tincidunt a dolor. Etiam erat ipsum,
                        convallis vitae laoreet mollis, aliquet nec dolor. Pellentesque scelerisque nibh eget
                        euismod eleifend. Nulla nec mi nisl. Sed convallis, nulla ac placerat sollicitudin, sem
                        leo luctus diam, quis placerat libero augue sit amet enim. Etiam et tempor eros.
                        Suspendisse convallis eget ex vel viverra. Nullam vel arcu quis orci malesuada ultricies
                        eu at ante. Maecenas purus erat, interdum in gravida in, consectetur sit amet ante. Nunc
                        eget pellentesque dolor.
                    </p>
                </div>
            </section>

            <section>
                <h1> Task-4 : Change Font size with Media Queries</h1>
                <div class="task-4">
                    <h1 class="center-text">Lorem Ipsum</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mattis accumsan mollis.
                        Cras eros odio, lobortis vitae fringilla vel, tincidunt a dolor. Etiam erat ipsum,
                        convallis vitae laoreet mollis, aliquet nec dolor. Pellentesque scelerisque nibh eget
                        euismod eleifend. Nulla nec mi nisl. Sed convallis, nulla ac placerat sollicitudin, sem
                        leo luctus diam, quis placerat libero augue sit amet enim. Etiam et tempor eros.
                        Suspendisse convallis eget ex vel viverra. Nullam vel arcu quis orci malesuada ultricies
                        eu at ante. Maecenas purus erat, interdum in gravida in, consectetur sit amet ante. Nunc
                        eget pellentesque dolor.
                    </p>
                </div>
            </section>
        </div>
    </div>

    <?php include '../footer.php'; ?>