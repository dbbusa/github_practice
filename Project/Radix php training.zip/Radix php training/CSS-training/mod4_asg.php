<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod4_asg">
    <h1 class="path" style="margin: 0px !important;">CSS / Module-4 / Assignment</h1>
    <div class="right_content">
        <div class="body">
            <section class="task-1">
                <h1>Task-1 : Create Photo Album Gallery, which must be responsive. Using Media Queries Implement this task.</h1>
                <div class="flex-container">
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/falls2.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/nature.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mist.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/ocean.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mountainskies.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/falls2.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/nature.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mist.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/paris.jpg" style="width:100%">
                    </div>
                    <div class="img_row">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/ocean.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/wedding.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/mountainskies.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/rocks.jpg" style="width:100%">
                        <img alt="demo image" src="../assets/images/CSS/Album Gallery/underwater.jpg" style="width:100%">
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php include '../footer.php'; ?>