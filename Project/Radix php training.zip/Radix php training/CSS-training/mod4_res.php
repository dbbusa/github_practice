<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod4_res">
    <h1 class="path">CSS / Module-4 / Resume</h1>
    <div class="right_content CSS_mod4_res">
        <div class="body">
            <div class="left">
                <button type="button" class="collapsible2"><strong class="fa_menu">HOME</strong><em class="fa icon_right">&#xf0c9;</em></button>
                <div class="content1" id="content1">
                    <img src="../assets/images/avtar.jpg" alt="profile image" />
                    <ul class="menu_list">
                        <li><a href="#about" onclick="hide_menu_content()">ABOUT</a></li>
                        <li><a href="#education" onclick="hide_menu_content()">EDUCATIONS</a></li>
                        <li><a href="#project" onclick="hide_menu_content()">PROJECTS</a></li>
                        <li><a href="#skill" onclick="hide_menu_content()">SKILLS</a></li>
                        <li><a href="#interest" onclick="hide_menu_content()">INTERESTS</a></li>
                        <li><a href="#award" onclick="hide_menu_content()">AWARDS</a></li>
                        <li><a href="#video" onclick="hide_menu_content()">VIDEOS</a></li>
                    </ul>
                </div>
            </div>
            <div class="right">
                <div class="section" id="about">
                    <div class="info">
                        <h1 class="title">P E R S O N A L &nbsp; &nbsp; I N F O R M A T I O N</h1>
                        <div class="details_info">
                            <p><strong> Name</strong> &nbsp;&nbsp; : &nbsp;&nbsp; AnkitChauhan</p>
                            <p class="" style="margin: 10px 0px !important;"><strong> DOB</strong> &nbsp;&nbsp; : &nbsp;&nbsp; 8th September 2001</p>
                            <p class=""><strong> Known Language</strong> &nbsp;&nbsp; : &nbsp;&nbsp; English, Hindi, Gujarati.
                            </p>
                        </div>
                    </div>
                    <div class="career_objectiv">
                        <h1 class="title">C A R E E R &nbsp; &nbsp; O B J E C T I V E</h1>
                        <div class="details_info">
                            <p>To work as a (job role being offered) in
                                your progressive organization that allows
                                me the scope to update my knowledge to
                                the latest trends and be part of a diverse
                                and dynamic team that adds to both my
                                personal and professional growth.
                            </p>
                        </div>
                    </div>
                    <div class="contact_us">
                        <h1 class="title">C O N T A C T &nbsp; &nbsp; M E &nbsp; &nbsp; A T</h1>
                        <div>
                            <ul style="list-style-type: none !important; margin-left: 0px !important;">
                                <li><em class="fa fa-phone" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;+91
                                    906-711-7191
                                </li>
                                <li><em class="fa fa-envelope-open" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;achauhan645@rku.ac.in
                                </li>
                                <li><em class="fa fa-skype" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;live:.cid.a39e2600fcbd0f42
                                </li>
                                <li><em class="fa fa-linkedin-square" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;ankitchauhan0809</li>
                                <li><em class="fa fa-desktop" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;ankitchauhan.epizy.com
                                </li>
                                <li><em class="fa fa-map-marker" style="font-size:14px"></em>&nbsp;&nbsp;&nbsp;Patel
                                    Society,
                                    Hifali, Botad -<br>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 364710. Ta - Botad, Dist. - Botad,<br>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gujatat, India</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="section" id="education">
                    <h1 class="title">A C A D E M I C &nbsp; &nbsp; P R O F I L E</h1>
                    <div>
                        <ul style="list-style-type: none !important;">
                            <li><strong> RK University, Rajkot.</strong></li>
                            <ul class="pb" style="list-style-type: disc  !important;">
                                <li><strong> Pursuing - B. Tech. Computer Engineering, 2018-22.</strong></li>
                                <ul style="list-style-type: none !important;">
                                    <li>SCORE : CGPA - 8.60 (till 6th sem.)</li>
                                </ul>
                            </ul>
                            <li><strong> Shree Daxinamurti Vidhyalay, Botad.</strong></li>
                            <ul style="list-style-type: disc !important;">
                                <li><strong> Higher Secondary School Certified, 2018</strong></li>
                                <ul style="list-style-type: none !important;">
                                    <li>SCORE : 65.85%</li>
                                </ul>
                            </ul>
                            <ul style="list-style-type: disc !important;">
                                <li><strong> Senior Secondary School Certified, 2016</strong></li>
                                <ul style="list-style-type: none !important;">
                                    <li>SCORE : 80.33%</li>
                                </ul>
                            </ul>
                        </ul>
                    </div>
                </div>

                <div class="section" id="project">
                    <h1 class="title">P R O J E C T S</h1>
                    <div>
                        <ul>
                            <li><strong> Java Projects :</strong> Grocery Web Application using Servlet,JSP & JDBC.
                            </li>
                            <li><strong> Android Projects :</strong> Tic-Tac-Toe & Binary Calculator applications.</li>
                            <li><strong> PHP Projects :</strong> procodefree.tech, Mini Proj. Using CodeIgniter
                                Framework.</li>
                            <li><strong> Python Projects :</strong> Countdown Timer, SnakeGame using Tinkercad or GUI.
                            </li>
                            <li><strong> Personal Portfolio :</strong> ankitchauhan.epizy.com</li>
                        </ul>
                    </div>
                </div>

                <div class="section" id="skill">
                    <div>
                        <h1 class="title">T E C H N I C A L &nbsp; &nbsp; S K I L L S</h1>
                        <div>
                            <ul>
                                <li> Java</li>
                                <li> Python</li>
                                <li> PHP</li>
                                <li> HTML5 / CSS3</li>
                                <li> C</li>
                                <li> C++</li>
                                <li> Android</li>
                                <li> Data Structure / Algorithm</li>
                                <li> JavaScript</li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <h1 class="title">I N T E R P E R S O N A L &nbsp; &nbsp; S K I L L S</h1>
                        <div>
                            <ul>
                                <li> Creative Thinking</li>
                                <li> Teamwork</li>
                                <li> Leadership</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="section" id="interest">
                    <div>
                        <h1 class="title">A R E A &nbsp; &nbsp; O F &nbsp; &nbsp; I N T E R E S T</h1>
                        <div>
                            <ul>
                                <li> Web Development</li>
                                <li> Coding & Practice</li>
                                <li> Learning</li>
                                <li> Sports Activity</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="section" id="award">
                    <div>
                        <h1 class="title">C E R T I F I C A T I O N</h1>
                        <div>
                            <ul>
                                <li>IIT Bombay, Coursera, Cisco, SoloLearn Certified in Various
                                    Programming Language courses.</li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <h1 class="title">A C H I E V E M E N T S</h1>
                        <div>
                            <ul>
                                <li>Pass out the exam taken by IIT Bombay of Completion of CPP Training.
                                </li>
                                <li>Coursera certifies their successful completion of the University of
                                    Michigan Python for Everybody Specialization.
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <h1 class="title">C O - C U R R I C U L A R &nbsp; &nbsp; A C T I V I T I E S</h1>
                        <div>
                            <ul>
                                <li>Participated in SSIP Smart City Hackathon, Rajkot.</li>
                                <li>Participated in Envision'20 and various workshops.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="section" id="video">
                    <h1 class="title">V I D E O S</h1>
                    <div class="video">
                        <video controls>
                            <source src="../assets/videos/resume.mp4">
                            <track label="English" kind="captions" srclang="en" src="./videos/project-en.vtt" default>
                        </video>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../footer.php'; ?>