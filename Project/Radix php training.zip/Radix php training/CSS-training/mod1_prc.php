<?php include '../header.php';?>
<?php include 'sidebar.php';?>

<aside  aria-label="" class="column_right CSS_mod1_prc">
      <h1 class="path" style="text-align: left !important;padding: 10px !important;">CSS / Module-1 / Practical</h1>
      <div class="right_content">
          <section>
            <h1 class="title">Provide text alignment to center to student Report Card which is created in Day1 assignment</h1>
            <table class="center">
              <caption></caption>
              <tr>
                <th>Roll no</th>
                <th>Name</th>
                <th>Year OF Passing</th>
                <th>Maths</th>
                <th>Physics</th>
                <th>Chemistry</th>
                <th>Grade</th>
              </tr>
              <tr>
                <td>1</td>
                <td>Ankit</td>
                <td>2018</td>
                <td>89</td>
                <td>92</td>
                <td>76</td>
                <td>A+</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Kuldip</td>
                <td>2020</td>
                <td>58</td>
                <td>67</td>
                <td>89</td>
                <td>B+</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Darshit</td>
                <td>2022</td>
                <td>99</td>
                <td>79</td>
                <td>88</td>
                <td>A+</td>
              </tr>
              <tr>
                <td>4</td>
                <td>Ruturaj</td>
                <td>2016</td>
                <td>89</td>
                <td>76</td>
                <td>55</td>
                <td>B</td>
              </tr>
              <tr>
                <td>5</td>
                <td>Arazu</td>
                <td>55</td>
                <td>59</td>
                <td>45</td>
                <td>67</td>
                <td>C+</td>
              </tr>
            </table>
          </section>

          <section>
            <h1 class="title">Provide Border to one paragraph and write some dummy text into it</h1>
            <p class="border">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Maecenas mollis porta dignissim.
              Morbi rutrum, tellus eu vehicula condimentum, purus diam eleifend velit, ut imperdiet nisl nisl nec
              turpis.
              Donec lacus odio, lobortis at mauris vitae, aliquet laoreet nulla.
              Vestibulum malesuada risus sed auctor vestibulum.
              Ut condimentum nisl sit amet finibus cursus. Sed sit amet enim sem.
              Vestibulum ultricies rutrum est at lobortis.
            </p>
          </section>

          <section>
            <h1 class="title">Create city list in horizontal order(using display properties)</h1>
            <ul>
              <li>Botad</li>
              <li>Rajkot</li>
              <li>Bhavnagar</li>
              <li>Surat</li>
              <li>Amreli</li>
              <li>Ahemdabad</li>
              <li>Mumbai</li>
              <li>Bombay</li>
              <li>Patan</li>
            </ul>
          </section>

          <section>
            <h1 class="title">Provide universal selector and apply blue color to a page</h1>
            <div class="universal">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Maecenas mollis porta dignissim.
                Morbi rutrum, tellus eu vehicula condimentum, purus diam eleifend velit, ut imperdiet nisl nisl nec
                turpis.
                Donec lacus odio, lobortis at mauris vitae, aliquet laoreet nulla.
                Vestibulum malesuada risus sed auctor vestibulum.
                Ut condimentum nisl sit amet finibus cursus. Sed sit amet enim sem.
                Vestibulum ultricies rutrum est at lobortis.
              </p>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Maecenas mollis porta dignissim.
                Morbi rutrum, tellus eu vehicula condimentum, purus diam eleifend velit, ut imperdiet nisl nisl nec
                turpis.
                Donec lacus odio, lobortis at mauris vitae, aliquet laoreet nulla.
                Vestibulum malesuada risus sed auctor vestibulum.
                Ut condimentum nisl sit amet finibus cursus. Sed sit amet enim sem.
                Vestibulum ultricies rutrum est at lobortis.
              </p>
            </div>
          </section>

          <section>
            <h1 class="title">Suppose html markup below, apply all h1 and h2 blue color.</h1>
            <div>
              <h1>Heading1</h1>

              <h2>Sub Heading</h2>

              <h1>Heading2</h1>

              <h2>Sub heading</h2>
            </div>
          </section>
      </div>

<?php include '../footer.php';?>