<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right">
    <div class="right_content">
        <div id="show_content1">
            <h1 class="show_content">About CSS Course</h1>
            <p style="padding: 20px 0px ;line-height: 30px;">CSS (Cascading Style Sheets) is a stylesheet language used to design the webpage to make it
                attractive. The reason of using CSS is to simplify the process of making web pages presentable.
                CSS allows you to apply styles to web pages. More importantly, CSS enables you to do this
                independent of the HTML that makes up each web page. Styling has been an essential property for
                any website since many decades. It increases the standards and overall look of the website which
                makes it easier for the user to interact with it. A website cannot be made without CSS, as
                styling is MUST since no user would want to interact with a dull and shabby website. So for
                knowing Web Development, learning CSS is must.
            </p>
        </div>
    </div>

    <?php include '../footer.php'; ?>