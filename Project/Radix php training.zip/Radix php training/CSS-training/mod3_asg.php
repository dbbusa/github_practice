<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod3_asg">
    <h1 class="path">CSS / Module-3 / Assignment</h1>
    <div class="right_content CSS_mod3_asg">
        <header>
            <nav aria-label="">
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">News</a></li>
                    <li><a href="">Blog posts</a></li>
                    <li><a href="">About Us</a></li>
                    <li><a href="">Contact Us</a></li>
                </ul>
            </nav>
        </header>
        <div class="body">
            <h1 style="font-size:50px;">Welcome Everyone !!</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sit amet eleifend tellus.
                Nullam tincidunt
                suscipit nunc scelerisque suscipit. Donec eu justo cursus, porttitor elit quis, cursus eros.
                Sed
                ultricies lacus id turpis congue, sit amet condimentum neque tristique. Integer vel ex
                pharetra, rhoncus
                eros maximus, eleifend felis. Donec non ligula nec purus cursus vulputate. Pellentesque sed
                risus sed
                magna luctus commodo.</p>
        </div>
    </div>

    <?php include '../footer.php'; ?>