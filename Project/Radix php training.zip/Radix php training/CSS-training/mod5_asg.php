<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod5_asg">
    <h1 class="path">CSS / Module-5 / Assignment</h1>
    <div class="right_content">
        <div class="grid-container">
            <div class="grid-iteam">
                <h1>Gaming accessories</h1>
                <div class="sub-grid-container1">
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Quad_Headset.jpg">
                        <p>Headsets</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Quad_Keyboard.jpg">
                        <p>Keyboards</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Quad_Mouse.jpg">
                        <p>Computer mice</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Quad_Chair.jpg">
                        <p>Chairs</p>
                    </div>
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam">
                <h1>Shop by Category</h1>
                <div class="sub-grid-container2">
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/computer.jpg">
                        <p>Computer & Accessories</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/gaming accessories.jpg">
                        <p>Video Games</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Baby Products.jpg">
                        <p>Baby</p>
                    </div>
                    <div class="sub-grid-iteam">
                        <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Toys.jpg">
                        <p>Toys & Games</p>
                    </div>
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam">
                <h1>Easy returns</h1>
                <div class="sub-grid-container3">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Dash_Returns.jpg">
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam-sub">
                <div class="sub-iteam1">
                    <h1 class="sign_h1">Sign in for the best experience</h1>
                    <a>Sign in securely</a>
                </div>
                <div class="sub-iteam2">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_D2.jpg">
                </div>
            </div>
            <div class="grid-iteam">
                <h1>AmazonBasics</h1>
                <div class="sub-grid-container4">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/amazonbasics.jpg">
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam">
                <h1>Electronics</h1>
                <div class="sub-grid-container3">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Dash_Electronics.jpg">
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam">
                <h1>Computers & Accessories</h1>
                <div class="sub-grid-container3">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Dash_PC.jpg">
                </div>
                <p>See more</p>
            </div>
            <div class="grid-iteam">
                <h1>Find your ideal TV</h1>
                <div class="sub-grid-container3">
                    <img alt="amzone produvt images" src="../assets/images/CSS/Amazone Images/Fuji_Dash_TV.jpg">
                </div>
                <p>See more</p>
            </div>
        </div>
    </div>

    <?php include '../footer.php'; ?>