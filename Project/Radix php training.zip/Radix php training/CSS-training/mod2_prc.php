<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right CSS_mod2_prc">
    <h1 class="path" style="text-align: left !important; padding: 10px !important;">CSS / Module-2 / Practical</h1>
    <div class="right_content">
        <section>
            <div class="new_topic">
                <h2>Parent div should contain 3 div inside. Div should be arranged in following manner.</h2>
                <div class="clearfix">
                    <div class="box1"></div>
                    <div class="box1"></div>
                    <div class="box1"></div>
                </div>
            </div>
            <div class="new_topic">
                <h2>Practice position properties static, relative, fixed and absolute.</h2>
                <div>
                    <div class="static_box box2">
                        <h3>Static</h3>
                    </div>
                    <div class="relative_box box2">
                        <h3>Relative</h3>
                    </div>
                    <div class="fixed_box box2">
                        <h3>Fixed</h3>
                    </div>
                    <div class="absolute_box box2">
                        <h3>Absolute</h3>
                    </div>
                </div>

            </div>
            <div class="scroll new_topic">
                <h2>Suppose we have a div with specific height and width and we need to arrange more text into
                    it.
                    Use overflow properties.</h2>
                <div class="scroll_content">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Morbi a faucibus enim. Pellentesque eu massa nec lorem facilisis malesuada. Curabitur
                        vitae nunc
                        dolor.
                        Sed luctus finibus nibh eget tempus. Fusce non placerat tellus. Donec in mauris non
                        augue viverra
                        mattis.
                        Vivamus ut elit lorem. Donec scelerisque ultricies nisi sed viverra. Proin euismod,
                        purus vel
                        fermentum cursus, mauris mi pharetra lacus, eu tristique mauris urna et felis.
                    </p>
                    <p>
                        Donec nec ante ut tellus volutpat hendrerit vitae id mauris. Sed lobortis pharetra
                        lacus, quis
                        posuere ipsum semper et. Quisque non nulla pretium, porta urna at, vestibulum risus. Ut
                        rhoncus nisi
                        et mauris fermentum mollis. Mauris finibus a nibh sed rutrum. Quisque auctor et turpis
                        ac
                        vestibulum. Duis in ligula et est rutrum cursus vitae non nisi. Pellentesque nisl est,
                        semper ac
                        enim quis, eleifend lacinia mi.
                    </p>

                    <p>Praesent vulputate tellus ut velit posuere, vehicula pulvinar quam ullamcorper. Donec
                        malesuada eros
                        euismod ligula cursus, et consectetur ipsum consectetur. Maecenas a velit lacinia,
                        tincidunt dui
                        hendrerit, sodales nunc. Maecenas porttitor non nisi eget euismod. Proin lacus mi,
                        semper nec quam
                        id, consequat rhoncus mauris. Cras eu sodales diam. Nunc nec rhoncus dui. Maecenas
                        pulvinar euismod
                        pulvinar. Mauris porttitor, diam semper mattis commodo, lectus mauris congue ligula, non
                        dapibus
                        erat libero ac urna. Vestibulum vitae velit sit amet sem bibendum porta. Etiam at velit
                        odio.
                        Integer quis orci in elit fermentum rhoncus.
                    </p>
                </div>
            </div>
        </section>
    </div>

    <?php include '../footer.php'; ?>