<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right">
    <div class="right_content">
        <div id="show_content1">
            <h1 class="show_content">About jQuery Course</h1>
            <p style="padding: 20px 0px ;line-height: 30px;">jQuery is an open-source JavaScript library that
                simplifies the interactions between an HTML/CSS document, or more precisely the Document Object
                Model (DOM), and JavaScript. Elaborating the terms, jQuery simplifies HTML document traversing
                and manipulation, browser event handling, DOM animations, Ajax interactions, and cross-browser
                JavaScript development.
            </p>
        </div>
    </div>
    
<?php include 'footer.php'; ?>