<?php include '../header.php'; ?>

<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right html_mod1_asg">
    <h1 class="path">HTML / Module-1 / Assignment</h1>
    <div class="right_content">
        <form>
            <div class="detail">
                <h1 style="text-align: center !important;margin-bottom: 30px !important;">Employee Details</h1>
                <div class="label">
                    <label for="name">Name</label>
                    <label for="age">Age</label>
                    <label for="gander">Gender</label>
                    <label for="designation">Designation</label>
                    <label for="salary">Salary</label>
                    <label for="location">Location</label>
                    <label for="email">Email</label>
                    <label for="joing_date">Joining Date</label>
                    <label for="contact ">Contact</label>
                </div>
                <div class="input">
                    <input type="text" name="name" placeholder=" Name" required />
                    <input type="number" name="age" max="100" placeholder=" Age" required />
                    <div class="radio">
                        <input type="radio" name="gander" />Male
                        <input type="radio" name="gander" />Female
                    </div>
                    <input type="text" name="designation" placeholder="Designation" required />
                    <input type="number" name="salary" placeholder="Salary" required />
                    <select name="location">
                        <option value="botad">Botad</option>
                        <option value="rajkot">Rajkot</option>
                        <option value="bhavnagar">Bhavnagar</option>
                        <option value="surat">surat</option>
                    </select>
                    <input type="email" name="email" placeholder="Email" required />
                    <input type="date" name="joing_date" placeholder="Joining  Date" required />
                    <input type="contact" name="name" max="10" placeholder="Contact Number" required />
                </div>
                <input type="submit" value="submit" />
            </div>
        </form>
    </div>

<?php include '../footer.php'; ?>