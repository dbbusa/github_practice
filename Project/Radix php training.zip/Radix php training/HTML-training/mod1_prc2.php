<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right html_mod1_prc2">
    <h1 class="path">HTML / Module-1 / Practical</h1>
    <div class="right_content">
        <header>
            <nav aria-label="">
                <ul>
                    <li><a class="active">Home</a></li>
                    <li><a>News</a></li>
                    <li><a>About Us</a></li>
                    <li><a>Contact US</a></li>
                    <li><a class="logout" href="login.html">Logout</a></li>
                </ul>
            </nav>
        </header>
        <hr>

        <section>
            <table class="center">
                <caption><strong>Student Report Card</strong></caption>
                <br>
                <tr>
                    <th>Roll no</th>
                    <th>Name</th>
                    <th>Year OF Passing</th>
                    <th>Maths</th>
                    <th>Physics</th>
                    <th>Chemistry</th>
                    <th>Grade</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Ankit</td>
                    <td>2018</td>
                    <td>89</td>
                    <td>92</td>
                    <td>76</td>
                    <td>A+</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Kuldip</td>
                    <td>2020</td>
                    <td>58</td>
                    <td>67</td>
                    <td>89</td>
                    <td>B+</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Darshit</td>
                    <td>2022</td>
                    <td>99</td>
                    <td>79</td>
                    <td>88</td>
                    <td>A+</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Ruturaj</td>
                    <td>2016</td>
                    <td>89</td>
                    <td>76</td>
                    <td>55</td>
                    <td>B</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Arazu</td>
                    <td>55</td>
                    <td>59</td>
                    <td>45</td>
                    <td>67</td>
                    <td>C+</td>
                </tr>
            </table>
        </section>

        <section class="news">
            <h3><strong>Latest News</strong></h3>
            <article>
                <h4>The Evolution of National Security in the UAE</h4>
                <p>The United Arab Emirates, a small and ambitious country in the Persian Gulf, faces a
                    variety
                    of security
                    threats.
                    Its geographic location puts it at the center of instability, sectarianism and
                    regional
                    rivalries in the
                    Middle East, which has led the country to pay particular attention to its security.
                </p>
            </article>

            <article>
                <h4>What Would Helsinki 2.0 Look Like Today?</h4>
                <p>The European security order has broken down. You might think that’s an overstatement.
                    NATO is alive and well. The Organization for Security and Cooperation (OSCE) in
                    Europe
                    is
                    still
                    functioning at a high level.
                    Of course, there’s the possibility of a major war breaking out between Russia and
                    Ukraine
                </p>
            </article>

            <article>
                <h4>Former Austrian President Heinz Fischer Talks to Fair Observer</h4>
                <p>Austria is known as a stable Central European country that is the capital of
                    classical
                    music.
                    It is also the home of prominent figures in the world of science and philosophy,
                    including
                    Sigmund Freud
                    and Ludwig Wittgenstein.
                    In 2014, Austria had the lowest unemployment rate in the European Union. </p>
            </article>
        </section>

        <section>
            <h3><strong>Department Hierarchy</strong></h3>
            <div class="block">
                <div class="left">
                    <ul style="list-style-type:square;">
                        <li>Project 1</li>
                        <ul style="list-style-type:disc;">
                            <li>Mangment 1</li>
                            <ul style="list-style-type:circle;">
                                <li>Devlopers</li>
                                <ul>
                                    <li>Denloper 1</li>
                                    <li>Denloper 2</li>
                                    <li>Denloper 3</li>
                                </ul>
                                <li>Testers</li>
                                <ul>
                                    <li>Tester 1</li>
                                    <li>Tester 2</li>
                                    <li>Tester 3</li>
                                </ul>
                            </ul>
                        </ul>
                    </ul>
                </div>

                <div class="right">
                    <ol type="I">
                        <li>Project 1</li>
                        <ol type="i">
                            <li>Mangment 1</li>
                            <ol type="1">
                                <li>Devlopers</li>
                                <ol start="11">
                                    <li>Denloper 1</li>
                                    <li>Denloper 2</li>
                                    <li>Denloper 3</li>
                                </ol>
                                <li>Testers</li>
                                <ol start="51">
                                    <li>Tester 1</li>
                                    <li>Tester 2</li>
                                    <li>Tester 3</li>
                                </ol>
                            </ol>
                        </ol>
                    </ol>
                </div>
            </div>
        </section>
    </div>

    <?php include '../footer.php'; ?>