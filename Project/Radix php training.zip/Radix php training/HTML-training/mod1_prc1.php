<?php include '../header.php'; ?>
<?php include 'sidebar.php'; ?>

<aside aria-label="" class="column_right html_mod1_prc1">
    <h1 class="path">HTML / Module-1 / Practical</h1>
    <div class="right_content">
        <table>
            <caption></caption>
            <th></th>
            <tr>
                <td class="center"><img src="../assets/images/HTML/avtar.jpg" alt="profile image"></td>
            </tr>
            <tr>
                <td><label for="username"><strong>User Name :</strong></label></td>
            </tr>
            <tr>
                <td><input type="text" name="sername" placeholder="User Name" required class="width" /></td>
            </tr>
            <tr>
                <td><label for="Password"><strong>Password :</strong></label></td>
            </tr>
            <tr>
                <td><input type="password" name="password" placeholder="Password" maxlength="8" required class="width" /></td>
            </tr>
            <tr>
                <td class="center"><a href="mod1_prc2.php" class="ab" style="padding-top:3px;">Login</a></td>
            </tr>
        </table>
    </div>

    <?php include '../footer.php'; ?>