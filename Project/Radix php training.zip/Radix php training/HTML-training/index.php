<?php include '../header.php' ?>
<?php include 'sidebar.php' ?>
<aside aria-label="" class="column_right">

    <!--course content-->
    <div class="right_content">
        <div id="show_content1">
            <h1 class="show_content">About HTML Course</h1>
            <p style="padding: 20px 0px ;line-height: 30px;">HTML stands for HyperText Markup Language. It is used to design web pages using a markup language. HTML is
                the
                combination of Hypertext and Markup language. Hypertext defines the link between the web pages. A markup
                language is used to define the text document within tag which defines the structure of web pages. This
                language
                is used to annotate text so that a machine can understand it and manipulate text accordingly. Most markup
                languages are human-readable. The language uses tags to define what manipulation has to be done on the text.
            </p>
        </div>
    </div>
<?php include '../footer.php' ?>