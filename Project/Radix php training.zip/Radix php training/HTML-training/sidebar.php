<aside aria-label="" class="column_left">
    <ul id="show1">
        <li class="module">
            <button type="button" class="collapsible" style="cursor: pointer;">Module-1</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod1_asg.php">Assignment</a></li>
                    <li><a href="mod1_prc1.php">Practical</a></li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Module-2</button>
            <div class="content">
                <ul class="task">
                    <li><a href="mod2_asg.php">Assignment</a></li>
                </ul>
            </div>
        </li>
    </ul>
</aside>