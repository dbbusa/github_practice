<footer class="footer">
        <ul>
            <li>Darshit Busa</li>
        </ul>
    </footer>

    <script src="assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>