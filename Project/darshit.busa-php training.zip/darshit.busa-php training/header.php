<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo 'assets/css/custom.css' ?>">
    <link rel="stylesheet" href="<?php echo 'assets/css/bootstrap.min.css' ?>">
    <title>HTML - Dashboard</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" title="Darshit Busa">DB</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link text-bold" aria-current="page" href="index.html" title="HTML">HTML</a>
                    </li>
                    <li class="nav-item" id="link-css">
                        <a class="nav-link text-bold" aria-current="page" href="css.html" title="CSS">CSS</a>
                    </li>
                    <li class="nav-item" id="link-css">
                        <a class="nav-link text-bold" aria-current="page" href="bootstrap.html" title="Bootstrap">Bootstrap</a>
                    </li>
                    <li class="nav-item" id="link-tailwind">
                        <a class="nav-link text-bold" aria-current="page" href="tailwind.html" title="Tailwind">Tailwind</a>
                    </li>
                    <li class="nav-item" id="link-javascript">
                        <a class="nav-link text-bold" aria-current="page" href="javascript.html" title="JavaScript">JavaScript</a>
                    </li>
                    <li class="nav-item" id="link-jquery">
                        <a class="nav-link text-bold" aria-current="page" href="jquery.html" title="JQuery">JQuery</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>