<?php include '../header.php' ?>
<section id="mainSection">
        <div class="row">
            <?php include 'sidebar.php' ?>
            <div class="main" id="content">
                <div class="row">
                    <h4><strong>HTML</strong> </h4>
                    <hr/>
                    <div class="image-container" id="addContent">
                      <img src="../assets/image/html.png" class="mainimg" alt="Html5 Logo">
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include '../footer.php' ?>