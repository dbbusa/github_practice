function exercise1(){
   document.getElementById('demo').innerHTML = "exercise1";
}
function exercise2(){
    document.getElementsByTagName('p')[0].innerHTML = "exercise2";
}
function exercise3(){
    document.getElementById("image").src = "https://www.w3schools.com/js/pic_bulbon.gif";
}
function exercise4(){
    document.getElementById("myText").value = "Have a nice day!";
}
function exercise5(){
    document.getElementById("demo").style.color = "#ff0000";
}
function exercise6(){
    document.getElementById("demo").style.display = "none";
}

function indexPage(){
    window.location.href = 'index.html'
}
function page1(){
    window.location.href = 'page1.html'
}
function page2(){
    window.location.href = 'page2.html'
}
function moveBack(){
    window.history.back();
}
let windowObj;
function openWindow() {
    windowObj = window.open("","","width=300, height=300");
}
function resizeWindow() {
    windowObj.resizeTo(200,200);   
}