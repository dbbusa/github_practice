$(document).ready(function () {
    $.getJSON("https://gorest.co.in/public-api/users", function (data) {
        let str = "<table><tr style='background-color: #FF8800 !important;'><th>Product Id</th><th>Name</th><th>Price</th><th>Quantity</th><th>Add to cart</th></tr>";
        $.each(data.data, function (index, result) {
            str += `<tr><td>${result.id}</td><td>${result.name}</td><td>${result.email}</td><td>${result.gender}</td><td>${result.status}</td></tr>`;
        });
        str += "</tabel>";
        $("#showData").html(str);
    });
});