$(document).ready(function () {
    $(".small1").parent().css("color", "red");
});

$(document).ready(function () {
    $(".small2").parents('.div2').css("color", "red");
});

$(document).ready(function () {
    $(".small3").parentsUntil('.div3').css("color", "red");
});

$(document).ready(function () {
    $(".span4").children().css("color", "red");
});

$(document).ready(function () {
    $(".div5").find('span').css("color", "red");
});

$(document).ready(function () {
    $(".p6").first().css("color", "red");
});

$(document).ready(function () {
    $(".p7").last().css("color", "red");
});

$(document).ready(function () {
    $(".p8").eq(1).css("color", "red");
});

$(document).ready(function () {
    $(".p9").filter('.intro').css("color", "red");
});

$(document).ready(function () {
    $(".p10").not('.intro').css("color", "red");
});

$(document).ready(function () {
    $(".div11").load("demo.txt #p1");
});

$(document).ready(function () {
    $.get("demo.txt",function (data) {
            $(".div12").html(data);
    });
});

$(document).ready(function () {
    $.post("https://reqres.in/api/users",
    {
        name: "Donald Duck",
        job: "Full Stack Devloper"
      },
      function (data) {
            $(".div13").html("Name : "+data.name+"<br> Job : "+data.job);
    });
});

$(document).ready(function () {
    $.getJSON('demo.json',function(result){
        $.each(result,function(i,data){
            $(".div14").append("Name : "+data.name+" City : "+data.city+"<br>");
        });
    });
});