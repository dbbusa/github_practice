function displayTimerClock() {
    document.getElementById('beforeTime').classList.add('d-none');
    document.getElementById('beforeTime').classList.remove('d-block');
    document.getElementById('mcqSection').classList.add('d-block');
    document.getElementById('mcqSection').classList.remove('d-none');
    document.getElementById('afterTime').classList.add('d-none');
    document.getElementById('afterTime').classList.remove('d-block');
    let secound = 59, minute = 59, hour = 2;
    let x = setInterval(function () {
        document.getElementById('timer').innerHTML = hour + ":" + minute + ":" + secound;
        secound--;
        if (hour == 0 && secound == 0 && minute == 0) {

            document.getElementById('beforeTime').classList.add('d-block');
            document.getElementById('beforeTime').classList.remove('d-block');
            document.getElementById('mcqSection').classList.add('d-none');
            document.getElementById('mcqSection').classList.remove('d-block');
            document.getElementById('afterTime').classList.add('d-block');
            document.getElementById('afterTime').classList.remove('d-none');

            document.getElementById('timer').classList.add('d-none');

            document.getElementById('showMsg').classList.remove('d-none');
            document.getElementById('exampleModal').style.display = 'none';
            document.getElementById('exampleModal').classList.add('hide');
            document.getElementById('exampleModal').classList.remove('show');
        }
        if (minute == 5) {
            document.getElementById('exampleModal').style.display = 'block';
            document.getElementById('exampleModal').classList.add('show');
            document.getElementById('exampleModal').classList.remove('hide');
        } if (minute == 0 && hour != 0) {
            hour--;
            minute = 59;
        } else if (secound == 0) {
            minute--;
            secound = 59;
        }
    }, 1000);
}

function dismissModal() {
    document.getElementById('exampleModal').style.display = 'none';
    document.getElementById('exampleModal').classList.add('hide');
    document.getElementById('exampleModal').classList.remove('show');
}
function finishExam() {
    window.location.href = "status.html";
}