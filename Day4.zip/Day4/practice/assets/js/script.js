function findSquare(num,displayResult){
    let res = num**2;
    displayResult(res);
}

function displayData(data){
    document.getElementById('resultT3').innerHTML = data;
}

function taskOne(){
    const inpEle = document.getElementById('inpT1');
    var inputNum = parseInt(inpEle.value.trim());
    if(!(isNaN(inputNum) || inpEle.value.trim() == "")){
        findSquare(inputNum,(result)=>{
            document.getElementById('resultT1').innerHTML = "Square is = " + result;
        });
    }else{
        document.getElementById('resultT1').innerHTML = "Please Enter Number";
    }
}
function checkGlobVar(){
    var numGlob = "Default Value";
    if(true){
        var numGlob = document.getElementById('inpT2').value;
        document.getElementById('resultT2block').innerHTML = numGlob;
    }
    document.getElementById('resultT2').innerHTML = numGlob;
}
function checkGlobLet(){
    var numGlob = "Default Value";
    if(true){
        let numGlob = document.getElementById('inpT2').value;
        document.getElementById('resultT2block').innerHTML = numGlob;
    }
    document.getElementById('resultT2').innerHTML = numGlob;
}

function checkStr(){
    var inpStr = document.getElementById('inpT3').value.trim();
    let resultStr = new Promise(function(success,failure){
        let defStr = "Hello World";
        setTimeout(function(){
            if(defStr == inpStr){
                res = inpStr.split("").reverse().join("");
                success(res);
            }else{
                failure(inpStr + " - " + "Wrong Input");
            }
        },500);
        
    }).then(
        function (value){
            displayData(value);
        },
        function (error){
            displayData(error);
        }
    );
}