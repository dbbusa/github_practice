import { Component } from '@angular/core';
import { FormGroup, FormControl, FormArray } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  studentForm: FormGroup;
  title = 'form';
  constructor(){
    this.studentForm = new FormGroup({
      firstName:new FormControl(),
      address:new FormGroup({
        flatno:new FormControl(),
        city:new FormControl()
      }),
      hobbies:new FormArray([new FormControl]),
      Branch:new FormControl('IT')

    });
  }
  submitForm(){
    console.log(this.studentForm.value);
  }
  get getHobbies(){
    return this.studentForm.get('hobbies') as FormArray;
  }
  addHobbies(){
    this.getHobbies.push(new FormControl());
  }
  changeval(){
      this.studentForm.patchValue({
        Branch: 'CE',
      })
  }
}
