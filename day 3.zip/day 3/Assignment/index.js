function check1(){

    var eid = (document.getElementById("empid").value);
    var eid_formate = /(?=(\d+(?=[a-zA-Z])|[a-zA-Z]+(?=\d))).{5}/;
    if(eid.length == 0){
        document.getElementById("error").innerHTML = "Enter Employee Id!!"
    }
    else if(!eid.match(eid_formate)){
        document.getElementById("error").innerHTML = "EmployeeID should be at least 5 character long and It should be character and number"
    }
    else{
        document.getElementById("error").innerHTML = ""
    }
}
function check2(){

    var ename = (document.getElementById("name").value);
    var ename_formate = /^[A-Za-z]+$/;
    if(ename.length == 0){
        document.getElementById("error1").innerHTML = "Enter Emplyee Name!!"
    }
    else if(!ename.match(ename_formate)){
        document.getElementById("error1").innerHTML = "Name shold be in character only!!"
    }
    else{
        document.getElementById("error1").innerHTML = ""
    }
}
function check3(){

    var eage = (document.getElementById("age").value);
    if(eage.length == 0){
        document.getElementById("error2").innerHTML = "Enter Age!!"
    }
    else if(eage.length == 4){
        document.getElementById("error2").innerHTML = "Age should not be greter than 1000!!"
    }
    else{
        document.getElementById("error2").innerHTML = ""
    }
}
function check4(){

    
    var edgn = (document.getElementById("dgn").value);
    var edgn_formate = /^[A-Za-z]+$/;
    if(edgn.length == 0){
        document.getElementById("error3").innerHTML = "Enter Designation!!"
    }
    else if(!edgn.match(edgn_formate)){
        document.getElementById("error3").innerHTML = "Designation shold be in character only!!"
    }
    else{
        document.getElementById("error3").innerHTML = ""
    }

}
function check5(){

    
    var esalary = (document.getElementById("salary").value);
    if(esalary.length == 0){
        document.getElementById("error4").innerHTML = "Enter Salary!!"
    }
    else{
        document.getElementById("error4").innerHTML = ""
    }

}
function check6(){

    
    var eemail = (document.getElementById("email").value);
    var email_formate = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(eemail.length == 0){
        document.getElementById("error5").innerHTML = "Enter Email!!"
    }
    else if(!eemail.match(email_formate)){
        document.getElementById("error5").innerHTML = "Email ID shold be in example11@email.com formate!!"
    }
    else{
        document.getElementById("error5").innerHTML = ""
    }

}
function check7(){

    var eloc = (document.getElementById("dd").value);
    if(eloc == value("n"))
    {
        document.getElementById("error6").innerHTML = "Select Location"
    }
    else{
        document.getElementById("error6").innerHTML = ""
    }
}
function check8(){

    var ecn = (document.getElementById("cn").value);
    if(ecn.length == 0)
    {
        document.getElementById("error7").innerHTML = "Enter Contact Number"
    }
    else if(ecn.length == 11){
        document.getElementById("error7").innerHTML = "Enter 10 Digits!!!"
    }
    else{
        document.getElementById("error7").innerHTML = ""
    }
}
function check(){

    var eid = (document.getElementById("empid").value);
    var ename = (document.getElementById("name").value);
    var eage = (document.getElementById("age").value);
    var edgn = (document.getElementById("dgn").value);
    var esalary = (document.getElementById("salary").value);
    var eemail = (document.getElementById("email").value);
    var ecn = (document.getElementById("cn").value);
    
   
    if(document.getElementById('inlineRadio1').checked) { 
        document.getElementById("error8").innerHTML 
            = document.getElementById("null").value 
            + " "; 
    } 
    else if(document.getElementById('inlineRadio2').checked) { 
        document.getElementById("error8").innerHTML 
            = document.getElementById("null1").value 
            + " ";   
    } 
    else if(document.getElementById('inlineRadio3').checked) { 
        document.getElementById("error8").innerHTML 
            = document.getElementById("null2").value 
            + " ";   
    }
    else { 
        document.getElementById("error8").innerHTML 
            = "You have not selected any Gender"; 
    }

    if(eid.length == 0){
        document.getElementById("error").innerHTML = "Enter Employee Id!!"
    }
    if(ename.length == 0){
        document.getElementById("error1").innerHTML = "Enter Emplyee Name!!"
    }
    if(eage.length == 0){
        document.getElementById("error2").innerHTML = "Enter Age!!"
    }
    if(edgn.length == 0){
        document.getElementById("error3").innerHTML = "Enter Designation!!"
    }
    if(esalary.length == 0){
        document.getElementById("error4").innerHTML = "Enter Salary!!"
    }
    if(eemail.length == 0){
        document.getElementById("error5").innerHTML = "Enter Email!!"
    }
    if(ecn.length == 0)
    {
        document.getElementById("error7").innerHTML = "Enter Contact Number"
    } 
}