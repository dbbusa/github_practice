<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP / currency</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1">
            <li>Implement simple currency calculator utility-program, which can be used to calculate currency conversions from dollars to euros. Exchange rates can be found for example on http://www.x-rates.com/d/EUR/table.html. Implement simple HTML-form where user can input amount of dollars (currency.html) and PHP-script (calculate.php) to calculate currency conversion. PHP-script will read the input values from HTML-form and perform conversion by multiplying dollars with current exchange rate.</li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="currency.php" method="post">
                <h3 class="text-center mb-3">Currency Conversions</h3>
                <div class="mb-3">
                    <label for="dollar" class="form-label">Please enter dollars</label>
                    <input type="number" step='0.001' name="dollar" placeholder="dollar" class="form-control" autocomplete="off" id="dollar">
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $dollar = $_POST['dollar'];
                            echo "Euro : " . (float)$dollar * 0.909;
                        }
                        else{
                            echo "Result :";
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>