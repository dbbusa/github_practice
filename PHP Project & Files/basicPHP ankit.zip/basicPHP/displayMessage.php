<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP / displayMessage</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1">
            <li>Create a php function that accepts an integer value and other information like name and outputs a message based on the number selected by user from drop down. Use a ‘switch’ statement for integer and display values.</li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="displayMessage.php" method="post">
                <h3 class="text-center mb-3">Display Message</h3>
                <div class="mb-3">
                    <label for="name" class="form-label">Please enter name</label>
                    <input type="text" name="name" placeholder="Name" class="form-control" autocomplete="off" id="name">
                </div>
                <div class="mb-4">
                    <label for="number" class="form-label">Choose number</label>
                    <select name="number" id="number" class="form-control">
                        <option value="" selected>Select number...</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php

                        if (isset($_POST['submit']) ) {
                            display($_POST['name'],$_POST['number']);
                        } else {
                            echo 'Result : ';
                        }

                        function display($name, $number)
                        {
                            switch ($number) {
                                case '0':
                                    echo "Result : Welcome, $name";
                                    break;

                                case '1':
                                    echo "Result : How are you, $name";
                                    break;

                                case '2':
                                    echo "Result : I’m doing well, Thank you";
                                    break;

                                case '3':
                                    echo "Result : Have a nice day";
                                    break;

                                case '4':
                                    echo "Result : Good bye";
                                    break;

                                default:
                                    echo 'Result : Please select number';
                                    break;
                            }
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>