<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP / validationBmi</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1">
            <li>Implement simple web-application (see picture below) that asks question from user and evaluates if the answer is correct. Use conditional statement to determine, if answer is correct or not.</li>
        </ol>
        <div class="mx-auto w-75 p-4 m-5">
            <form action="captchaValidate.php" method="post">
                <h3 class="text-center mb-5">What is this animal ?</h3>
                <div class="mb-5 d-flex flex-row">
                    <div class="border border-3 border-primary w-75">
                        <img src="../../assets/images/PHP/captchaImg.png" style="width: 100%;" alt="">
                        <input type="hidden" value="reindeer" name="image">
                    </div>
                    <div class="border border-3 border-primary w-25 d-flex flex-column justify-content-center">
                        <div class="">
                            <div class="d-flex flex-column">
                                <div class="form-check ms-5 mb-1">
                                    <label class="form-check-label" for="reindeer"> Reindeer</label>
                                    <input class="form-check-input" type="radio" name="captchaResponse" value="reindeer" id="reindeer">
                                </div>
                                <div class="form-check ms-5 mb-1">
                                    <label class="form-check-label" for="fallowdeer"> Fallow deer</label>
                                    <input class="form-check-input" type="radio" name="captchaResponse" value="fallowdeer" id="fallowdeer">
                                </div>
                                <div class="form-check ms-5 mb-1">
                                    <label class="form-check-label" for="moose"> Moose</label>
                                    <input class="form-check-input" type="radio" name="captchaResponse" value="moose" id="moose">
                                </div>
                                <div class="form-check ms-5">
                                    <label class="form-check-label" for="horse"> Horse</label>
                                    <input class="form-check-input" type="radio" name="captchaResponse" value="horse" id="horse">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div class="mt-5">
                    <strong class="text-danger">
                        <?php
                            if(isset($_POST['submit'])){
                                $response = $_POST['captchaResponse'];
                                $image = $_POST['image'];
                                if($response == $image)
                                {
                                    echo "Result : Answer is correct";
                                }
                                else{
                                    echo "Result : Answer is not correct";
                                }
                            }
                            else{
                                echo 'Result :';
                            }
                            
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>