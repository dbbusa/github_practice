<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP / basicCalculater</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1">
            <li>Write a PHP script using a ‘Switch case’ that accept value from two input box and perform addition, subtraction, multiplication, division, modulus, square-root, square, Factorial operation on two value then display total as the output.</li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="basicCalculater.php" method="post">
                <h3 class="text-center mb-3">Basic Calculater</h3>
                <div class="mb-3">
                    <label for="num1" class="form-label">Please enter first number</label>
                    <input type="number" step='0.001' name="num1" placeholder="First number" class="form-control" autocomplete="off" id="num1">
                </div>
                <div class="mb-3">
                    <label for="num2" class="form-label">Please enter second number</label>
                    <input type="number" step='0.001' name="num2" placeholder="Second number" class="form-control" autocomplete="off" id="num2">
                </div>
                <div class="mb-4">
                    <label for="operation" class="form-label">Operation</label>
                    <select name="operation" id="operation" class="form-control">
                        <option value="" selected>Select operation...</option>
                        <option value="addition">Addition</option>
                        <option value="subtraction">Subtraction</option>
                        <option value="multiplication">Multiplication</option>
                        <option value="division">Division</option>
                        <option value="modulus">Modulus</option>
                        <option value="square-root">Square Root</option>
                        <option value="square">square</option>
                        <option value="factorial">Factorial</option>
                    </select>
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $num1 = $_POST['num1'];
                            $num2 = $_POST['num2'];
                            $operation = $_POST['operation'];

                            switch($operation){
                                case 'addition':
                                    echo 'Result : '.$num1 + $num2;
                                    break;

                                case 'subtraction':
                                    echo 'Result : '.$num1 - $num2;
                                    break;

                                case 'multiplication':
                                    echo 'Result : '.$num1 * $num2;
                                    break;

                                case 'division':
                                    echo 'Result : '.$num1 / $num2;
                                    break;

                                case 'modulus':
                                    echo 'Result : '.$num1 % $num2;
                                    break;

                                case 'square-root':
                                    echo 'Result : num1 = '.sqrt($num1).' num2 = '. sqrt($num2);
                                    break;

                                case 'square':
                                    echo 'Result : num1 = '.$num1*$num1.' num2 = '.$num2*$num2;
                                    break;

                                case 'factorial':
                                    $fac1 = 1;
                                    for($i = 1; $i <= $num1; $i++){
                                        $fac1 = $fac1 * $i;
                                    }

                                    $fac2 = 1;
                                    for($i = 1; $i <= $num2; $i++){
                                        $fac2 = $fac2 * $i;
                                    }

                                    echo 'Result : num1 = '.$fac1.' num2 = '.$fac2;
                                    break;

                                default :
                                    echo 'Please Select operation';
                                    break;
                                
                            }
                        }
                        else{
                            echo 'Result : ';
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>