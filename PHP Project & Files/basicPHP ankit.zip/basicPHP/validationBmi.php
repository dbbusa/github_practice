<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP / validationBmi</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1">
            <li>Modify BMI-application (exercise 4) so that user input is validated. Maximum length for height is 4 characters and value must be float value. Maximum length for weight is 3 characters and value must be an integer. If user gives incorrect input, notification is displayed.</li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="validationBmi.php" method="post">
                <h3 class="text-center mb-3">Validation BMI</h3>
                <div class="mb-3">
                    <label for="weight" class="form-label">Please enter weight (in kilogramms)</label>
                    <input type="number" step='0.001' name="weight" placeholder="First number" class="form-control" autocomplete="off" id="weight">
                </div>
                <div class="mb-3">
                    <label for="num2" class="form-label">Please enter height (in meters, floating point is punctuation mark)</label>
                    <input type="number" step='0.001' name="height" placeholder="Second number" class="form-control" autocomplete="off" id="height">
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {

                            $weight = $_POST['weight'];
                            $height = $_POST['height'];

                            if(strlen($weight) == 0 || strlen($height) == 0){
                                echo 'Please enter filed.';
                            }
                            else if((strlen($weight) > 3 || is_decimal($weight) != "") && (strlen($height) > 4 || !is_decimal($height))){
                                 echo 'Maximum length for weigth is 3 characters and value must be integer value.<br>';
                                 echo 'Maximum length for height is 4 characters and value must be float value.';
                            }
                            else if (strlen($weight) > 3 || is_decimal($weight) != "") {
                                echo 'Maximum length for weigth is 3 characters and value must be integer value.';
                            }
                            else if(strlen($height) > 4 || !is_decimal($height)){
                                echo 'Maximum length for height is 4 characters and value must be float value.';
                            } 
                            else {
                                $result = $weight / ($height * $height);
                                echo "Result : $result";
                            }
                        } else {
                            echo 'Result : ';
                        }

                        function is_decimal($n)
                        {
                            return is_numeric($n) && floor($n) != $n;
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>