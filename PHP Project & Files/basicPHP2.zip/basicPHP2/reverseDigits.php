<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card border-dark">
                    <div class="card-header bg-dark"></div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-5 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Reverse Number</div>
                                    <div class="card-body text-center">
                                        <form action="reverseDigits.php" method="POST">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="inpNumber">Enter Number</label>
                                                        <input type="number" name="inpNumber" id="inpNumber" class="form-control" value="<?php echo (isset($_POST['inpNumber'])) ? $_POST['inpNumber'] : ''; ?>" placeholder="Number">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="reverse">Reverse</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                        if (isset($_POST['reverse'])) {
                                            $result = "";
                                            $inpNumber =  ($_POST['inpNumber']) ? $_POST['inpNumber'] : "";

                                            if (strlen($inpNumber) < 3)
                                                $result = "Enter Number at Least 3 Digits Long";
                                            else {
                                                while ($inpNumber > 1) {
                                                    $resDigit = $inpNumber % 10;
                                                    $result .= $resDigit;
                                                    $inpNumber = ($inpNumber / 10);
                                                }
                                            }
                                            echo "<p class='text-center'> Reverse Digits are " . (int) $result . " </p>";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>