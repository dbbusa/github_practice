<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card border-dark">
                    <div class="card-header bg-dark"></div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-5 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Check the Number is Power of 2</div>
                                    <div class="card-body text-center">
                                        <form action="calculateSqRoot.php" method="POST">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="inpNum">Enter Number</label>
                                                        <input type="number" name="inpNum" id="inpNum" class="form-control" value="<?php echo (isset($_POST['inpNum'])) ? $_POST['inpNum'] : ''; ?>" placeholder="Number">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="calculate">Calculate</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                        if (isset($_POST['calculate'])) {
                                            $inpNumber =  $_POST['inpNum'];

                                            if ($inpNumber == "")
                                                $result = "Please Enter Number";
                                            else if ($inpNumber < 0)
                                                $result = "Please Enter Number Greater than 0 Number";

                                            else
                                                $result = "Square Root of $inpNumber is " . sqrt($inpNumber);

                                            echo "<p class='text-center'> $result </p>";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>