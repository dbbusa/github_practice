<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">Date Functions</div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-4 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Compare Dates</div>
                                    <div class="card-body text-center">
                                        <form action="compareDate.php" method="POST">
                                            <div class="row mt-2">
                                                <div class="form-group">
                                                    <label for="">Base Date</label>
                                                    <input type="date" name="baseDate" class="form-control" id="baseDate">
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="form-group">
                                                    <label for="">Date To Compare</label>
                                                    <input type="date" name="compareDate" class="form-control" id="compareDate">
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="calculate">Calculate</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                            if(isset($_POST['calculate'])){
                                                $baseDate = date_create($_POST['baseDate']);
                                                $dateToCompare = date_create($_POST['compareDate']);
                                                
                                                $dateDiff = date_diff($baseDate,$dateToCompare)->format('%R%a Days');
                                                
                                                echo "<p> Difference between Two Date is $dateDiff </p>";

                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>