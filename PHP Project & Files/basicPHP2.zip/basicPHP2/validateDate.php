<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card border-dark">
                    <div class="card-header bg-dark"></div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-5 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Validate Date</div>
                                    <div class="card-body text-center">
                                        <form action="validateDate.php" method="POST">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="row">
                                                        <div class="col-4 p-1">
                                                            <div class="form-group">
                                                                <label for="inpDate">Enter Date</label>
                                                                <input type="number" name="inpDate" id="inpDate" max='31' class="form-control" value="<?php echo (isset($_POST['inpDate'])) ? $_POST['inpDate'] : ''; ?>" placeholder="Date">
                                                            </div>
                                                        </div>
                                                        <div class="col-4 p-1">
                                                            <div class="form-group">
                                                                <label for="inpMonth">Enter Month</label>
                                                                <input type="number" name="inpMonth" id="inpMonth" max='12' class="form-control" value="<?php echo (isset($_POST['inpMonth'])) ? $_POST['inpMonth'] : ''; ?>" placeholder="Month">
                                                            </div>
                                                        </div>
                                                        <div class="col-4 p-1">
                                                            <div class="form-group">
                                                                <label for="inpYear">Enter Year</label>
                                                                <input type="number" name="inpYear" id="inpYear" class="form-control" value="<?php echo (isset($_POST['inpYear'])) ? $_POST['inpYear'] : ''; ?>" placeholder="Year">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="validate">Verify Date</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                        if (isset($_POST['validate'])) {
                                            $date =  ($_POST['inpDate']) ? $_POST['inpDate'] : "";
                                            $month = ($_POST['inpMonth']) ? $_POST['inpMonth'] : "";
                                            $year = ($_POST['inpYear']) ? $_POST['inpYear'] : "";


                                            if ($date == "" || $month == "" || $year == "")
                                                $result = "Please Enter Date, Month, and Year";
                                            else {
                                                $response = checkdate($month, $date, $year);
                                                if ($response)
                                                    $result = "Given Date is Valid";
                                                else
                                                    $result = "Given Date is Invalid";
                                            }
                                            echo "<p class='text-center'> $result </p>";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>