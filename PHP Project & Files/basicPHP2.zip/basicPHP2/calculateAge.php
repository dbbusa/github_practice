<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">Date Functions</div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-4 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Select Born Year</div>
                                    <div class="card-body text-center">
                                        <form action="calculateAge.php" method="POST">
                                            <div class="row">
                                                <div class="form-group">
                                                    <label for="">Select Born Year</label>
                                                    <select name="bornYear" id="bornYear" class="form-control">
                                                        <option value="" selected disabled>Select Year .... </option>
                                                        <?php
                                                        for ($i = 1955; $i < 2022; $i++) {  ?>
                                                            <option value="<?php echo $i ?>"><?php echo $i ?> </option>
                                                        <?php }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="calculate">Calculate</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                            if(isset($_POST['calculate'])){
                                                $bornYear = $_POST['bornYear'];
                                                $currentYear = date('Y');
                                                
                                                $currentAge = $currentYear - $bornYear;
                                                
                                                echo "<p> Your Current Age is $currentAge </p>";

                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>