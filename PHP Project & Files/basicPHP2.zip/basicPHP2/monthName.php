<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card border-dark">
                    <div class="card-header bg-dark"></div>
                    <div class="card-body">
                        <div class="row justify-content-center">

                            <div class="col-12 col-md-5 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Validate Date</div>
                                    <div class="card-body text-center">
                                        <form action="monthName.php" method="POST">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="inpMonth">Enter Month</label>
                                                        <input type="number" name="inpMonth" id="inpMonth" min='1' max='12' class="form-control" value="<?php echo (isset($_POST['inpMonth'])) ? $_POST['inpMonth'] : ''; ?>" placeholder="Month">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2 justify-content-center">
                                                <button class="btn btn-primary w-auto" type="submit" name="monthName">Get Month Name</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                        if (isset($_POST['monthName'])) {
                                            $monthIndx =  ($_POST['inpMonth']) ? $_POST['inpMonth'] : "";
                                            $months = array(1 => "January",2 => "February",3 => "March",4 => "April",5 => "May",6 => "June",7 => "July",8 => "August",9 => "September",10 => "October",11 => "November",12 => "December");

                                            if ($monthIndx == "")
                                                $result = "Please Enter Month";
                                            else
                                                $result = "Name of the Month is $months[$monthIndx]";
                                            
                                            echo "<p class='text-center'> $result </p>";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>