<?php include '../../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php' ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">Date Functions</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Date Formate</div>
                                    <div class="card-body text-center">
                                        <?php
                                        echo date('d-M-Y'); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Date and Time Formate</div>
                                    <div class="card-body text-center">
                                        <?php
                                        echo date('m d Y H:i a'); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Date and Time Formate</div>
                                    <div class="card-body text-center">
                                        <?php
                                        echo date('dS F Y h:i:s'); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Today's Date</div>
                                    <div class="card-body text-center">
                                        <?php
                                        $dateToday = strtotime("today");
                                        echo date("d-m-Y",$dateToday); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Tomorrow's Date</div>
                                    <div class="card-body text-center">
                                        <?php
                                        $dateTomorrow = strtotime("Tomorrow");
                                        echo date("d-m-Y",$dateTomorrow); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Next Week Today's Date</div>
                                    <div class="card-body text-center">
                                        <?php
                                        $dateWeek = strtotime("+1 Week");
                                        echo date("d-m-Y",$dateWeek); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-3 p-1">
                                <div class="card">
                                    <div class="card-header text-center">Next Monday's Date</div>
                                    <div class="card-body text-center">
                                        <?php
                                        $dateNextMonday = strtotime("+1 Monday");
                                        echo date("d-m-Y",$dateNextMonday); ?>
                                    </div>
                                    <div class="card-footer"></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php' ?>