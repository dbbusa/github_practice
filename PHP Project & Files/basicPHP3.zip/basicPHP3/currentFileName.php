<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main">
            <div class="row mt-3 justify-content-center">
                <div class="col-sm-12 col-md-6">
                    <div class="card">
                        <div class="card-header text-center"></div>
                        <div class="card-img text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" style="width: 150px; height: 150px; opacity: .5;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                        </div>
                        <hr class="w-50 mx-auto">
                        <div class="card-body p-0">
                            <div class="row justify-content-center">
                                <div class="col-12 px-1">
                                    <h6 class="text-center">
                                        <strong>File Name : </strong>
                                        <?php 
                                            preg_match("/[a-zA-Z0-9]+\.php/",$_SERVER['SCRIPT_NAME'],$matchFile);
                                            echo  $matchFile[0] // This Line Will Display Filename  
                                        ?>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer mt-2">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>