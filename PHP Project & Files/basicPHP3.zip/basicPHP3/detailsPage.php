<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">

                <?php
                if (isset($_POST['submitDetails'])) {
                    $email = ($_POST['email']) ? $_POST['email'] : "";
                    $hostname = ($_POST['hostname']) ? $_POST['hostname'] : "";
                    $telephoneNum = ($_POST['telephoneNum']) ? $_POST['telephoneNum'] : "";
                    $ipAdd = ($_POST['ipAdd']) ? $_POST['ipAdd'] : "";

                    $patternEmail = "/([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+/";
                    $patternIp = "/\d{1,3}\.\d{1,3}\.\d{1,3}$/";
                    $patternTele = "/([+]91) \d{10}/";
                    $patternHostName = "/(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/";


                    if ($email == "")
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Email </div>";
                    else if (!preg_match($patternEmail, $email))
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Valid Email </div>";

                    if ($ipAdd == "")
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter IP Address </div>";
                    else if (!preg_match($patternIp, $ipAdd)) {
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Valid IP Address </div>";
                    } else if ($telephoneNum == "")
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Telephone Number </div>";
                    else if (!preg_match($patternTele, $telephoneNum)) {
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Valid Telephone Number </div>";
                    } else if ($hostname == "")
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Hostname </div>";
                    else if (!preg_match($patternHostName, $hostname)) {
                        echo "<div class='alert alert-danger' role='alert'> <strong>Error !</strong> Please Enter Valid Hostname </div>";
                    } else { ?>

                        <div class="col-sm-12 col-md-6">
                            <div class="card">
                                <div class="card-header text-center"><?php echo $hostname; ?></div>
                                <div class="card-img text-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" style="width: 200px; height: 200px; opacity: .5;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                    </svg>
                                </div>
                                <hr class="w-50 mx-auto">
                                <div class="card-body p-0">
                                    <div class="row justify-content-center">
                                        <div class="col-11 text-center px-1">
                                            <h6><strong>Email : </strong> <?php echo $email; ?></h6>
                                        </div>
                                        <div class="col-11 text-center px-1">
                                            <h6><strong>IP Address : </strong> <?php echo $ipAdd; ?></h6>
                                        </div>
                                        <div class="col-11 text-center px-1">
                                            <h6><strong>Telephone Number : </strong> <?php echo $telephoneNum; ?></h6>
                                        </div>

                                    </div>
                                </div>
                                <div class="card-footer mt-2">
                                </div>
                            </div>
                        </div>
                <?php }
                }
                ?>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>