<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main">
            <div class="row mt-3 justify-content-center">
                <?php if (isset($_POST['submitDetails'])) { ?>

                    <div class="col-sm-12 col-md-6">
                        <div class="card">
                            <div class="card-header text-center"><?php echo $_POST['fullname'] ?></div>
                            <div class="card-img text-center">
                                <svg xmlns="http://www.w3.org/2000/svg" style="width: 200px; height: 200px; opacity: .5;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                            <hr class="w-50 mx-auto">
                            <div class="card-body p-0">
                                <div class="row justify-content-center">
                                    <div class="col-11 col-md-5 px-1">
                                        <h6><strong>Username : </strong><?php echo $_POST['username'] ?></h6>
                                    </div>
                                    <div class="col-11 col-md-6 px-1">
                                        <h6><strong>Email : </strong> <?php echo $_POST['email'] ?></h6>
                                    </div>
                                    <div class="col-11 col-md-5 px-1">
                                        <h6><strong>Gender : </strong> <?php echo $_POST['gender'];  ?></h6>
                                    </div>
                                    <div class="col-11 col-md-6 px-1">
                                        <h6><strong>Date Of Birth : </strong>  <small><?php echo $_POST['date'] . ', ' . $_POST['month'] . ' ' . $_POST['year'];  ?></small></h6>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="card-footer mt-2">
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>