<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main">
            <div class="row mt-3 justify-content-center">
                <div class="col-sm-12 col-md-6">
                    <div class="card">
                        <div class="card-header text-center"> Check Substring</div>
                        <div class="card-img text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" style="width: 100px; height: 100px; opacity: .5;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M10 21h7a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v11m0 5l4.879-4.879m0 0a3 3 0 104.243-4.242 3 3 0 00-4.243 4.242z" />
                            </svg>
                        </div>
                        <hr class="w-50 mx-auto">
                        <div class="card-body p-0">
                            <form action="checkSubString.php" method="POST">
                                <div class="row justify-content-center">
                                    <div class="col-11 px-1">
                                        <div class="form-group">
                                            <label for="mainString">Main String </label>
                                            <div class="input-group mb-3">
                                                <input type="text" name="mainString" id="mainString" class="form-control" value="<?php echo (isset($_POST['mainString'])) ? $_POST['mainString'] : '' ?>" placeholder="Enter mainString" required />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-11 px-1">
                                        <div class="form-group">
                                            <label for="findString">Find String </label>
                                            <div class="input-group mb-3">
                                                <input type="text" name="findString" id="findString" class="form-control" value="<?php echo (isset($_POST['findString'])) ? $_POST['findString'] : '' ?>" placeholder="Enter findString" required />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <button class="btn btn-primary w-auto" name="check">check</button>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer mt-2 text-center">
                            <?php
                            if (isset($_POST['check'])) {
                                $mainString = $_POST['mainString'];
                                $findString = $_POST['findString'];
                                $regex = "/" . $findString . "/i";
                                if (preg_match($regex, $mainString)) {
                                    echo "<p>String Contains the Substring</p>";
                                } else {
                                    echo "<p>String Not Contains the Substring</p>";
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>