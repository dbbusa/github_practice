<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Basic Form</h6>
                    </div>
                    <div class="card-body">
                        <form action="basicFormAction.php" method="POST">

                            <div class="row">
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="fullname">Full Name </label>
                                        <div class="input-group mb-3">
                                            <input type="text" name="fullname" id="fullname" class="form-control" value="<?php echo (isset($_POST['fullname'])) ? $_POST['fullname'] : '' ?>" placeholder="Enter Fullname" required />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="username">Username </label>
                                        <div class="input-group mb-3">
                                            <input type="text" name="username" id="username" class="form-control" value="<?php echo (isset($_POST['username'])) ? $_POST['username'] : '' ?>" placeholder="Enter Username" required />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="email">Email </label>
                                        <div class="input-group mb-3">
                                            <input type="text" name="email" id="email" class="form-control" value="<?php echo (isset($_POST['email'])) ? $_POST['email'] : '' ?>" placeholder="Enter Email" required />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="gender">Gender </label>
                                        <div class="input-group mb-3">

                                            <div class="form-check mx-1">
                                                <label class="form-check-label">
                                                    <input type="radio" class="form-check-input" name="gender" id="btnMale" value="Male" required>
                                                    Male
                                                </label>
                                            </div>

                                            <div class="form-check mx-1">
                                                <label class="form-check-label">
                                                    <input type="radio" class="form-check-input" name="gender" id="btnFemale" value="Female" required>
                                                    Female
                                                </label>
                                            </div>

                                            <div class="form-check mx-1">
                                                <label class="form-check-label">
                                                    <input type="radio" class="form-check-input" name="gender" id="btnOther" value="other" required>
                                                    Other
                                                </label>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="dob">Birth Date </label>
                                        <div class="row">
                                            <div class="col-4 px-1">
                                                <select class="form-control" name="date" id="date" required>
                                                    <option value="" disabled selected>Date...</option>
                                                    <?php
                                                    for ($i = 1; $i <= 31; $i++) { ?>
                                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                                    <?php }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-4 px-1">
                                                <select class="form-control" name="month" id="month" required>
                                                    <option value="" disabled selected>Month...</option>
                                                    <?php
                                                    $months = array(1 => "January",2 => "February",3 => "March",4 => "April",5 => "May",6 => "June",7 => "July",8 => "August",9 => "September",10 => "October",11 => "November",12 => "December");
                                                    foreach($months as $month) { ?>
                                                        <option value="<?php echo $month; ?>"><?php echo $month; ?></option>
                                                    <?php }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-4 px-1">
                                                <select class="form-control" name="year" id="year" required>
                                                    <option value="" disabled selected>Year...</option>
                                                    <?php
                                                    for ($i = 1950; $i <= 2022; $i++) { ?>
                                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                                    <?php }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row justify-content-center mt-3">
                                <div class="btn-group w-auto" role="group" aria-label="Basic example">
                                    <button type="submit" name="submitDetails" class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>