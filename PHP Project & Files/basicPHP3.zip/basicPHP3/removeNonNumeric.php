<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main">
            <div class="row mt-3 justify-content-center">
                <div class="col-sm-12 col-md-5">
                    <div class="card">
                        <div class="card-header text-center">Remove Non Numeric Characters</div>

                        <div class="card-body p-0">
                            <form action="removeNonNumeric.php" method="POST">
                                <div class="row justify-content-center">
                                    <div class="col-11 px-1">
                                        <div class="form-group">
                                            <label for="inpString">Enter String </label>
                                            <div class="input-group mb-3">
                                                <input type="text" name="inpString" id="inpString" class="form-control" value="<?php echo (isset($_POST['inpString'])) ? $_POST['inpString'] : '' ?>" placeholder="Enter String" required />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <button class="btn btn-primary w-auto" name="check">Check</button>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer mt-2 text-center">
                            <?php
                            if (isset($_POST['check'])) {
                                $inpString = $_POST['inpString'];

                                $regex = "/[^.,\d]/";
                                $resString = preg_replace($regex,"", $inpString);
                                    echo "<p>$resString</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>