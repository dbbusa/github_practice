<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main">
            <div class="row mt-3 justify-content-center">
                <div class="col-sm-12 col-md-5">
                    <div class="card">
                        <div class="card-header text-center">Remove New Line(character)</div>

                        <div class="card-body p-0">
                            <form action="removeNewLine.php" method="POST">
                                <div class="row justify-content-center">
                                    <div class="col-11 px-1">
                                        <div class="form-group">
                                            <label for="inpString">Enter String </label>
                                            <div class="input-group mb-3">
                                                <textarea name="inpString" id="inpString" class="form-control" placeholder="Enter String" required><?php echo (isset($_POST['inpString'])) ? $_POST['inpString'] : '' ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <button class="btn btn-primary w-auto" name="check">Check</button>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer mt-2">
                            <?php
                            if (isset($_POST['check'])) {
                                $inpString = $_POST['inpString'];
                                echo "<h6 class='fw-bold'>Input String</h6>";
                                echo "<p style='white-space: pre-line;'>$inpString</p>";
                                $regex = "/[\n\r]+/";
                                
                                
                                $resString = preg_replace($regex, "", $inpString);
                                echo "<h6 class='mt-2 fw-bold'>Output String</h6>";
                                echo "<p style='white-space: pre-line;'>$resString</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>