<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Currency Calculator</h6>
                    </div>
                    <div class="card-body">

                        <form action="calculateCurrency.php" method="POST">
                            <div class="row">
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="inpDollars">Enter Dollars </label>
                                        <input type="text" name="inpDollars" id="inpDollars" class="form-control" value="<?php echo (isset($_POST['inpDollars'])) ? $_POST['inpDollars'] : '' ?>" placeholder="Enter Dollar Amount" required />
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12 p-2">
                                    <button type="submit" name="calculate" class="btn btn-success w-auto"> Convert</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>