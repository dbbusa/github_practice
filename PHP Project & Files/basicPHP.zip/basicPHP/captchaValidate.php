<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Captcha Validation</h6>
                    </div>
                    <div class="card-body">

                        <form action="captchaValidate.php" method="POST">

                            <h5 class="text-center">What is this animal?</h5>
                            <div class="row justify-content-center">
                                <div class="col-12 col-md-6 border border-3 p-2">
                                    <div class="row">
                                        <div class="col-6">
                                            <img src="<?php echo $path . 'assets/image/captchaImg.png' ?>" alt="Captcha Image" class="img-fluid">
                                            <input type="hidden" name="captcha" value="raindeer">
                                        </div>
                                        <div class="col-6 p-2">
                                            <div class="form-check">
                                                <input type="radio" name="userAnswer" class="form-check-input" id="rainDeer" value="raindeer" required>
                                                <label class="form-check-label" for="rainDeer">
                                                    Raindeer
                                                </label>
                                            </div>
                                            
                                            <div class="form-check">
                                            <input type="radio" name="userAnswer" class="form-check-input" id="fallowDeer" value="fallowdeer" required>
                                                <label class="form-check-label" for="fallowDeer">
                                                Fallow Deer
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input type="radio" name="userAnswer" class="form-check-input" id="moose" value="moose" required>
                                                <label class="form-check-label" for="moose">
                                                    Moose
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input type="radio" name="userAnswer" class="form-check-input" id="horse" value="horse" required> 
                                                <label class="form-check-label" for="horse">
                                                Horse
                                                </label>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="row justify-content-center mt-3">
                                <div class="col-12 text-center p-2">
                                    <button type="submit" name="check" class="btn btn-success w-auto"> Answer</button>
                                </div>
                            </div>

                            <div class="row justify-content-center">
                                <?php 
                                    if(isset($_POST['check'])){
                                        $captchaAnswer = $_POST['captcha'];
                                        $userAnswer = $_POST['userAnswer'];

                                        if($captchaAnswer == $userAnswer){
                                            echo "<h5 class='text-center'>Valid Captcha Answer</h5>";
                                        }else{
                                            echo "<h5 class='text-center'>Invalid Captcha Answer</h5>";
                                        }

                                    }
                                ?>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>