<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Result</h6>
                    </div>
                    <div class="card-body">
                     <?php 
                        if(isset($_POST['calculate'])){
                            $personWeight = $_POST['inpWeight'];
                            $personHeight = $_POST['inpHeight'];

                            $splitHeight = explode('.',$personHeight);

                            if(strlen($personWeight) > 3 || is_int($personWeight)){
                                echo "<div class='alert alert-danger' role='alert'> <strong>Error ! </strong> Weight Should be lesser than 3 characters and must be an integer value</div>";
                            }else if (strlen($splitHeight[0].$splitHeight[1]) > 4  || is_float($personHeight)){
                                echo "<div class='alert alert-danger' role='alert'> <strong>Error ! </strong> Height Should be lesser than 4 characters and must be an floating point value</div>";
                            }
                            else{   
                                $bodyMassIndex = (double) $personWeight/($personHeight*$personHeight);
                                
                                echo "<h5 class='text-center'>Person Weight : ".$personWeight."</h5>";
                                echo "<h5 class='text-center'>Person Height : ".$personHeight."</h5>";
                                echo "<h5 class='text-center'>Body Mass Index : ".$bodyMassIndex."</h5>";
                            }
                        }

                     ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>