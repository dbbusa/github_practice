<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Display Message</h6>
                    </div>
                    <div class="card-body">

                        <form action="displayMessage.php" method="POST">
                            <div class="row">
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="inpName">Enter Name</label>
                                        <input type="text" name="inpName" id="inpName" class="form-control" value="<?php echo (isset($_POST['inpName'])) ? $_POST['inpName'] : '' ?>" placeholder="Enter Name" required />
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="inpChoice">Select Message Format</label>
                                        <select name="inpChoice" id="inpChoice" class="form-control">
                                            <option value="" disabled selected> Select Message Format...</option>
                                            <option value="0">Welcome, [name]</option>
                                            <option value="1">How are you, [name]?</option>
                                            <option value="2">I'm doing well, Thank you</option>
                                            <option value="3">Have a nice day</option>
                                            <option value="4">Good-bye</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12 p-2">
                                    <button type="submit" name="check" class="btn btn-success w-auto"> Submit</button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="card-footer">
                        <?php
                        if (isset($_POST['check'])) {
                            $inpName = $_POST['inpName'];
                            $inpChoice = $_POST['inpChoice'];
                        
                            switch ($inpChoice) {
                                case 0:
                                    echo "<p>" . "Welcome ". $inpName . "</p>";
                                    break;
                                case 1:
                                    echo "<p>" . "How are you, ".$inpName."?" . "</p>";
                                    break;
                                case 2:
                                    echo "<p>" . "I'm doing well, Thank you" . "</p>";
                                    break;
                                case 3:
                                    echo "<p>" . "Have a nice day" . "</p>";
                                    break;
                                case 4:
                                    echo "<p>" . "Good-bye" . "</p>";
                                    break;
                                default:
                                    echo "<p>" . "Please Select Valid Choice Number" . "</p>";
                                    break;
                            }
                        } else {
                            echo "<p>" . "Result Display Here" . "</p>";
                        } ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>