<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Result</h6>
                    </div>
                    <div class="card-body">
                     <?php 
                        if(isset($_POST['calculate'])){
                            $dollarAmt = $_POST['inpDollars'];
                            $eurosRate = 0.908492;
                            
                            $eurosAmt = (double) $dollarAmt*$eurosRate;

                            echo "<h5 class='text-center'>Dollar Amount : ".$dollarAmt."</h5>";
                            echo "<h5 class='text-center'>Rate of 1 Euro : ".$eurosRate."</h5>";
                            echo "<h5 class='text-center'>Dollar to Euros : ".$eurosAmt."</h5>";
                        }

                     ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>