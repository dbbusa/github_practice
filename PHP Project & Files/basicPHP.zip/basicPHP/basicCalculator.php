<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Basic Calculator</h6>
                    </div>
                    <div class="card-body">

                        <form action="basicCalculator.php" method="POST">
                            <div class="row">

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="value1">Value 1</label>
                                        <input type="number" name="value1" id="value1" class="form-control" value="<?php echo (isset($_POST['value1'])) ? $_POST['value1'] : '' ?>" placeholder="Value 1" required />
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="value2">Value 2</label>
                                        <input type="number" name="value2" id="value2" class="form-control" value="<?php echo (isset($_POST['value2'])) ? $_POST['value2'] : '' ?>" placeholder="Value 2" required />
                                    </div>
                                </div>
                            </div>
                            <div class="row p-1">
                                <label for="operation">Select Operation</label>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="addition" value="addition" required />
                                            <label class="form-check-label" for="addition">Addition</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="subtraction" value="subtraction" required />
                                            <label class="form-check-label" for="subtraction">Subtraction</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="multiplication" value="multiplication" required />
                                            <label class="form-check-label" for="multiplication">Multiplication</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="division" value="division" required />
                                            <label class="form-check-label" for="division">Division </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="modulus" value="modulus" required />
                                            <label class="form-check-label" for="modulus">Modulus</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="square-root" value="square-root" required />
                                            <label class="form-check-label" for="square-root">Square Root</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="square" value="square" required />
                                            <label class="form-check-label" for="square">Square</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-3 col-md-2 p-1 w-auto">
                                    <div class="border border-dark p-1 rounded-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="operation" id="factorial" value="factorial" required />
                                            <label class="form-check-label" for="factorial">Factorial</label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 p-2">
                                    <button type="submit" name="calculate" class="btn btn-success w-auto"> Calculate</button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="card-footer">
                        <?php
                        if (isset($_POST['calculate'])) {
                            function getFactorials($val)
                            {
                                $res = 1;
                                for ($i = 1; $i <= $val; $i++) {
                                    $res *= $i;
                                }
                                return $res;
                            }
                            $inpNum1 = $_POST['value1'];
                            $inpNum2 = $_POST['value2'];
                            $operation = $_POST['operation'];

                            switch ($operation) {
                                case 'addition':
                                    echo "<p>" . "Addition of " . $inpNum1 . " and " . $inpNum2 . " is " . ($inpNum1 + $inpNum2) . "</p>";
                                    break;
                                case 'subtraction':
                                    echo "<p>" . "Subtraction of " . $inpNum1 . " and " . $inpNum2 . " is " . ($inpNum1 - $inpNum2) . "</p>";
                                    break;
                                case 'multiplication':
                                    echo "<p>" . "Multiplication of " . $inpNum1 . " and " . $inpNum2 . " is " . ($inpNum1 * $inpNum2) . "</p>";
                                    break;
                                case 'division':
                                    echo "<p>" . "Division of " . $inpNum1 . " and " . $inpNum2 . " is " . (float)($inpNum1 / $inpNum2) . "</p>";
                                    break;
                                case 'modulus':
                                    echo "<p>" . "Modulus of " . $inpNum1 . " and " . $inpNum2 . " is " . ($inpNum1 % $inpNum2) . "</p>";
                                    break;
                                case 'square-root':
                                    echo "<p>" . "Square Root of " . $inpNum1 . " and " . $inpNum2 . " is " . sqrt($inpNum1) . " and " . sqrt($inpNum2) . "</p>";
                                    break;
                                case 'square':
                                    echo "<p>" . "Square of " . $inpNum1 . " and " . $inpNum2 . " is " . ($inpNum1 * $inpNum1) . " and " . ($inpNum2 * $inpNum2) . "</p>";
                                    break;
                                case 'factorial':
                                    echo "<p>" . "Factorial of " . $inpNum1 . " and " . $inpNum2 . " is " . getFactorials($inpNum1) . " and " . getFactorials($inpNum2) . "</p>";
                                    break;
                                default:
                                    echo "<p>" . "Please Select Valid Operation" . "</p>";
                                    break;
                            }
                        } else {
                            echo "<p>" . "Result Display Here" . "</p>";
                        } ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>