<?php include '../../header.php'; ?>

<section id="mainSection">
    <div class="row">
        <?php include '../sidebar.php'; ?>
        <div class="main phpinfo">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-header">
                        <h6>Body Mass Index</h6>
                    </div>
                    <div class="card-body">

                        <form action="bodyMassCalculate.php" method="POST">
                            <div class="row">
                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="inpWeight">Enter Weight </label>
                                        <div class="input-group mb-3">
                                            <input type="number" name="inpWeight" id="inpWeight" class="form-control" value="<?php echo (isset($_POST['inpWeight'])) ? $_POST['inpWeight'] : '' ?>" placeholder="Enter Weight" aria-label="Weight" required />
                                            <div class="input-group-append">
                                                <span class="input-group-text">kg.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 px-1">
                                    <div class="form-group">
                                        <label for="inpHeight">Enter Height </label>
                                        <div class="input-group mb-3">
                                            <input type="text" name="inpHeight" id="inpHeight" class="form-control" value="<?php echo (isset($_POST['inpHeight'])) ? $_POST['inpHeight'] : '' ?>" placeholder="Enter Height" aria-label="Height" required />
                                            <div class="input-group-append">
                                                <span class="input-group-text">m.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12 p-2">
                                    <button type="submit" name="calculate" class="btn btn-success w-auto"> Check</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../../footer.php'; ?>