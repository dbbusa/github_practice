<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="icon" type="image/svg+xml" href="favicon.svg" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/css/css-mod5-style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Lyle Apparel</title>
</head>

<body>
  <div id="app">
    <!-- Social media Section -->
    <section id="socialmedia-bar">
      <div class="socialmedia-bar">
        <div class="bg-gray text-right font-2x p-2 mr-1">
          <span class="fa fa-facebook text-darkgray"></span>
        </div>
        <div class="bg-gray text-left font-2x  p-2 ml-1">
          <span class="fa fa-twitter text-darkgray"></span>
        </div>
      </div>
    </section>
    <!-- Brand Section -->
    <section id="brand-section">
      <div class="container">
        <div class="grid-2">
          <div class="grid-2-item-img">
            <img src="../assets/image/logo.png" alt="Lyle Apparel" class="brand-logo">
          </div>
          <div class="grid-2-item">
            <div class="form-group">
              <input type="text" class="search-box text-right" placeholder="Search...">
              <button type="button" class="btn-search mr-2"><i class="fa fa-search" aria-hidden="true"></i></button>
              <div class="border-left fullwidth">
                <em class="box arrow-right fa fa-shopping-cart bg-yellow p-3 ml-2"></em>
                <div class="ml-2 description-cart">
                  <small>My Cart : 0 items - $0.00</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <header id="header">
      <div class="bg-yellow py-2">
        <div class="border-dashed-top border-dashed-bottom">
          <div class="container desktop-menu">
            <ul class="nav-item">
              <li><i class="fa fa-home" aria-hidden="true"></i></li>
              <li class="links">
                <a href="#" class="text-upper"> About us</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> Our Products</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> News</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> Faqs</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> New Arrival</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> Stockists</a>
              </li>
              <li class="links active">
                <a href="#" class="text-upper"> Shop Now</a>
              </li>
              <li class="links">
                <a href="#" class="text-upper"> Contact Us</a>
              </li>
            </ul>
          </div>

          <div class="container mobile-menu">
            <button class="btn-menu" id="btn-menu" onclick="toggle()"><span class="fa fa-bars"></span></button>
            <ul class="nav-item nav-item-mobile hide-show" id="show-menu">
              <li><i class="fa fa-home" aria-hidden="true"></i></li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> About us</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> Our Products</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> News</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> Faqs</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> New Arrival</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> Stockists</a>
              </li>
              <li class="links active">
                <a href="#" onclick="hideHeader()" class="text-upper"> Shop Now</a>
              </li>
              <li class="links">
                <a href="#" onclick="hideHeader()" class="text-upper"> Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </header>
    <section id="slider-section">
      <div class="background-slider">
        <div class="container">
          <div class="row">
            <div class="col-2">
              <h1 class="jumbotron text-primary">Heritage Belts</h1>
              <p class="text-primary">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis asperiores
                ipsa doloribus dolorum consectetur sed laborum magnam esse sit fugiat?</p>
              <button class="bg-yellow btn-getinfo text-upper text-bold"><span class="size-btn-text">get more
                  info</span> <i class="fa fa-angle-right text-bold size-btn-icon" aria-hidden="true"></i></button>
            </div>
            <div class="col-2 hide-mobile">
              <img src="../assets/image/banner_img.png" alt="Heritage Belts" class="banner-img" />
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="description">
      <div class="container">
        <div class="row mt-2">
          <div class="col-2 card-desc mr-2 p-relative">
            <h1>Lyle Apparel</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae velit voluptatum iusto quam, sint expedita
              cumque porro repellat nisi dicta</p>
            <div class="p-absolute">
              <button class="bg-yellow btn-desc"><i class="text-center fa fa-angle-right text-bold size-btn-icon1"
                  aria-hidden="true"></i></button>
            </div>
          </div>
          <div class="col-2 card-desc ml-2 p-relative">
            <h1>Nexbelt</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae velit voluptatum iusto quam, sint expedita
              cumque porro repellat nisi dicta</p>
            <div class="p-absolute">
              <button class="bg-yellow btn-desc"><i class="text-center fa fa-angle-right text-bold size-btn-icon1"
                  aria-hidden="true"></i></button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="category-section">
      <div class="bg-category">
        <div class="container">
          <div class="row row-mobile">
            <button class="btn-category text-upper bg-yellow active-category box arrow-bottom">Golf Series</button>
            <button class="btn-category text-upper">Classic series</button>
            <button class="btn-category text-upper">Custom series</button>
          </div>
          <div class="grid-4">
            <div class="item">
              <h4 class="text-bold">Go-In Carbon Black</h4>
              <div class="img-container">
                <img src="../assets/image/img1.jpg" alt="Carbon Black" class="img-cat">
              </div>
              <div class="grid2-basket">
                <div class="text-price verical-middle">
                  $ 90.00
                </div>
                <div class="item2">
                  <button class="text-upper btn-add-basket bg-yellow">add to basket</button>
                </div>
              </div>
            </div>
            <div class="item">
              <h4 class="text-bold">Go-In Carbon White</h4>
              <div class="img-container">
                <img src="../assets/image/img2.jpg" alt="Carbon White" class="img-cat">
              </div>
              <div class="grid2-basket">
                <div class="text-price verical-middle">
                  $ 90.00
                </div>
                <div class="item2">
                  <button class="text-upper btn-add-basket bg-yellow">add to basket</button>
                </div>
              </div>
            </div>
            <div class="item">
              <h4 class="text-bold">Go-In - Tex</h4>
              <div class="img-container">
                <img src="../assets/image/img3.jpg" alt="Cobra Tex" class="img-cat">
              </div>
              <div class="grid2-basket">
                <div class="text-price verical-middle">
                  $ 90.00
                </div>
                <div class="item2">
                  <button class="text-upper btn-add-basket bg-yellow">add to basket</button>
                </div>
              </div>
            </div>
            <div class="item">
              <h4 class="text-bold">Go-In Shield Black</h4>
              <div class="img-container">
                <img src="../assets/image/img4.jpg" alt="Shield Black" class="img-cat">
              </div>
              <div class="grid2-basket">
                <div class="text-price verical-middle">
                  $ 90.00
                </div>
                <div class="item2">
                  <button class="text-upper btn-add-basket bg-yellow">add to basket</button>
                </div>
              </div>
            </div>
          </div>
          <div class="fullwidth text-right cat-last-btn">
            <button class="text-uppper bg-yellow btn-more">&amp; More</button>
          </div>
        </div>
      </div>
    </section>

    <section id="news" class="news">
      <div class="container">
        <div class="row">
          <div class="col-2 mr-2">
            <h2 class="text-upper title-news">on sale</h2>
            <div class="bg-onsale text-center fullwidth p-relative">
              <img src="../assets/image/on_sale_img_23.jpg" alt="On Sale">
              <div class="over-img jumbotron"><span class="text-upper">Sale off</span> <span
                  class="text-bold text-yellow">60%</span></div>
            </div>

          </div>
          <div class="col-2 ml-2">
            <h2 class="text-upper title-news">Latest News</h2>
            <div class="bg-gray fullwidth">
              <div class="row row-mobile p-15">
                <div class="col-70 verical-middle">
                  <h4 class="text-upper text-space no-margin">Nexbelt caddy comp</h4>
                  <span class="no-margin">28 Sep 2015</span>
                </div>
                <div class="col-30">
                  <img src="../assets/image/img7.jpg" alt="news image" class="news-img">
                </div>
              </div>
              <div class="row px-15 text-space text-gray">
                <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. laboriosam non, ullam nostrum consequatur
                  quisquam vel accusantium facilis repudiandae quam aliquam cupiditate voluptate, ab cum iure... </p>
              </div>
              <div class="p-15 text-right">
                <button class="btn-readmore-news">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                </button>
              </div>
            </div>
          </div>
        </div>


        <div class="grid-3 mt-3">
          <div class="col-33">
            <div class="row fullwidth">
              <div class="col-20 font-35 mr-2">
                <div class="bg-services">
                  <i class="fa fa-truck reflect " aria-hidden="true"></i>
                </div>
              </div>
              <div class="col-80 ml-2">
                <h4 class="text-upper no-margin">free Shipping</h4>
                <small class="text-gray no-margin">Free delivery on all orders over $200</small>
              </div>
            </div>
          </div>

          <div class="col-33">
            <div class="row fullwidth">
              <div class="col-20 font-35 mr-2">
                <div class="bg-services">
                  <i class="fa fa fa-phone" aria-hidden="true"></i>
                </div>
              </div>
              <div class="col-80 ml-2">
                <h4 class="text-upper no-margin">call us : 01234 567890</h4>
                <small class="text-gray no-margin">Lorem ipsum dolor sit amet consectetur adipisicing elit...</small>
              </div>
            </div>
          </div>

          <div class="col-33">
            <div class="row fullwidth">
              <div class="col-20 font-35 mr-2">
                <div class="bg-services">
                  <i class="fa fa-credit-card" aria-hidden="true"></i>
                </div>
              </div>
              <div class="col-80 ml-2">
                <h4 class="text-upper no-margin">Gift Cards</h4>
                <small class="text-gray no-margin">Lorem ipsum dolor sit amet consectetur adipisicing elit...</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="contact-section">
      <div class="bg-footercontact">
        <div class="container">
          <div class="row">
            <div class="col-50">
              <div class="grid-3 grid-3-mobile">
                <div class="">
                  <h4 class="text-yellow">Products</h4>
                  <ul class="footer-list">
                    <li>Golf Series</li>
                    <li>Classic Series</li>
                    <li>Custom Series</li>
                  </ul>
                </div>
                <div class="">
                  <h4 class="text-yellow">Pages</h4>
                  <ul class="footer-list">
                    <li>Home</li>
                    <li>Stockists</li>
                    <li>Shop</li>
                    <li>News</li>
                    <li>Terms & Conditions</li>
                    <li>Privacy Policy</li>
                    <li>Contact Us</li>
                  </ul>
                </div>
                <div class="">
                  <h4 class="text-yellow">Account</h4>
                  <ul class="footer-list">
                    <li>Cart</li>
                    <li> My Account </li>
                    <li> Change Password </li>
                    <li> Edit My Address </li>
                    <li> View Order </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-25">
              <div class="card-contact">
                <h3 class="no-margin">Join our Mailing List</h3>
                <small class="no-margin">* indicates required</small>
                <form action="#">
                  <div class="fullwidth mt-1">
                    <input type="text" placeholder="First Name" class="input-contact" />
                  </div>
                  <div class="fullwidth mt-1">
                    <input type="text" placeholder="Last Name" class="input-contact" />
                  </div>
                  <div class="fullwidth mt-1">
                    <input type="text" placeholder="Email Address *" class="input-contact" />
                  </div>
                  <div class="fullwidth text-right mt-1">
                    <button type="submit" class="bg-yellow btn-readmore-news text-upper">subscribe <i
                        class="fa fa-angle-double-right" aria-hidden="true"></i></button>
                  </div>
                </form>
              </div>
            </div>
            <div class="col-25">
              <div class="row-column">
                <div class="fullwidth text-right hide-mobile">
                  <img src="../assets/image/footer_logo.png" alt="Footer Logo" class="img-footer" />
                </div>
                <div class="fullwidth text-right justify-content-space-between">
                  <ul class="social-media">
                    <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="#" class="active-socialmedia"><span class="fa fa-twitter"></span></a></li>
                  </ul>
                </div>
                <div class="fullwidth mt-1 hide-mobile">
                  <div class="row row-mobile justify-content-right">
                    <img src="../assets/image/payment/paypal.png" class="img-payment" alt="PayPal">
                    <img src="../assets/image/payment/master.png" class="img-payment" alt="Master card">
                  </div>
                  <div class="row row-mobile justify-content-right">
                    <img src="../assets/image/payment/visa.png" class="img-payment" alt="Visa">
                    <img src="../assets/image/payment/ap.png" class="img-payment" alt="Australia Post">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer class="footer py-2 bg-yellow">
      <div class="container ">
        <div class="row justify-content-space-between">
          <div class="">
            <a href="#" class="footer-links">Privacy Policy</a> |
            <a href="#" class="footer-links">Terms of Usey</a> |
            <a href="#" class="footer-links">Site Mapy</a>
          </div>
            <span class="text-right">&copy; 2016 Lyle Apparel | Website by : Terry Wilcher Designs</span>
        </div>

      </div>
    </footer>

  </div>
  <script>
    // Header Toggle Script
    function toggle() {
        var element = document.getElementById("show-menu");
        element.classList.toggle("hide-show"); // Toggle the class hide-show which contains the code for hidding the content
    }
    function hideHeader() {
        var element = document.getElementById("show-menu"); 
        element.classList.toggle("hide-show"); // Toggle the class hide-show which contains the code for hidding the content
    }
</script>
</body>

</html>