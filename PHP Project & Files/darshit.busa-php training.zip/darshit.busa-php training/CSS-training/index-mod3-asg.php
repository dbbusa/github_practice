<?php
include '../header.php'
?>
<section id="mainSection">
    <div class="row">
        <?php include 'sidebar.php' ?>
        <div class="main css-mod3-asg" id="content">
            <header>
                <div class="navbar-my">
                    <a href="#">Home</a>
                    <a href="#">AboutUs</a>
                    <a href="#">ContackUs</a>
                    <a href="#">Login</a>
                </div>
            </header>

            <section id="mainSection">
                <h3>Title</h3>
                <div>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta quae ad sint vel iste tempore voluptatem debitis. Ea tempora neque libero natus, perspiciatis laborum voluptatibus aut eligendi reprehenderit ducimus velit pariatur, cum minima corporis fugiat. Quis a quas earum! Officiis fugiat quidem natus fugit placeat architecto illo illum labore aut! Nam distinctio quaerat quos sequi quae nesciunt! Ducimus, quis omnis reiciendis blanditiis assumenda ad dolorum tenetur eum doloribus illum at soluta dicta natus aspernatur consequatur modi alias voluptatum quae aut porro architecto ab. Maxime rem laudantium tempore, mollitia corrupti in voluptatibus velit, nisi ipsum magnam voluptatem culpa deserunt eius minima esse iure necessitatibus! Voluptatum ab adipisci temporibus autem nisi atque dolores. Debitis alias veritatis esse doloremque eligendi repudiandae iste, animi voluptate! Voluptates quae fuga, consequuntur sequi eum dolor autem harum, aperiam nostrum, ut ipsa vitae illo alias. Sed nesciunt voluptatum, velit vel placeat et perferendis voluptates eveniet sunt neque non animi. Optio odit nisi quis distinctio, quam facere rerum possimus rem deleniti doloribus cumque quaerat eum, pariatur tempore at hic nulla, ipsum maxime. Iure commodi voluptatibus odio placeat? Quibusdam repellat laborum delectus ut voluptate nam molestiae fuga exercitationem quo ab! Iste quo deserunt natus distinctio eos beatae, reprehenderit nemo officiis.
                </div>
            </section>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>