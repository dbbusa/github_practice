<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="icon" type="image/svg+xml" href="favicon.svg" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/css/mod2-style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Resume - Darshit Busa</title>
</head>

<body>
  <div id="app">
    <section id="NavigationBar">
      <header>
        <ul>
          <li>
            <nav aria-label="HomeLink"><a href="#">Home</a></nav>
          </li>
          <li>
            <nav aria-label="VideoLink"><a href="#videoResume">Video</a></nav>
          </li>
        </ul>
      </header>
    </section>
    <section id="MainSection">
      <div class="container">
        <div class="header">
          <!-- first Row contains name and avtar image -->
          <div class="row">
            <div class="form-part">
              <div class="row">
                <img src="../assets/image/avtar.jpg" class="avtar" alt="Avtar">
              </div>
              <div class="row">
                <div class="form-part">
                  <div class="row">
                    <h1 class="ml-2">Darshit Busa</h1>
                    <span class="ml-2 text-gray font-bold">Developer</span>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <!-- Second Row Discription -->
          <div class="row">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non eum modi cumque cupiditate tempore dolore
              alias, et corporis optio pariatur repellat porro explicabo culpa possimus consequuntur, esse minus,
              officia fugit.
            </p>
          </div>

          <!-- Third Row Education -->
          <section class="row" id="EducationDetails">
            <div class="row mt-3">
              <h3>Education Details</h3>
            </div>
            <div class="form-part">
              <!-- SSC Details -->
              <div class="row border-left border-color-lightblue">
                <h4>SSC <span class="text-gray text-right text-small">2011-2016</span></h4>
                <h5>Maruti Motherland School, Rajkot</h5>
                <ul>
                  <li>Achived Grade : 69.50%</li>
                </ul>
              </div>

              <!-- Diploma Details -->
              <div class="row border-left border-color-lightcyan ml-2">
                <h4>Diploma Details <span class="text-gray text-right text-small">2016-2019</span></h4>
                <h5>RK University, Rajkot</h5>
                <ul>
                  <li>Computer Engineering</li>
                  <li>Achived Grade : 8.84 CGPA</li>
                </ul>
              </div>

              <!-- Bachelor Degree Details -->
              <div class="row border-left border-color-lightpurple ml-2">
                <h4>Bachelor Technology <span class="text-gray text-right text-small">2019-Present</span></h4>
                <h5>RK University, Rajkot</h5>
                <ul>
                  <li>Computer Engineering</li>
                  <li>Achived Grade : 8.77 CGPA</li>
                </ul>
              </div>

            </div>
          </section>
          <hr />

          <section id="projectDetails">
            <div class="row mt-3">
              <h3>Project Details</h3>
            </div>
            <div class="form-part">
              <!-- Project 1 -->
              <div class="row border-left border-color-lightblue">
                <h4>The NorthStar Nest <span class="text-gray text-right text-small">2021</span></h4>
                <h6>Web Design (Slim - Twing)</h6>
                <ul>
                  <li>Simple, Attractive and informative website built with Twing Template Engin and php slim framework for "The Northstar Nest"</li>
                </ul>
              </div>

              <!-- Project 2 -->
              <div class="row border-left border-color-lightcyan ml-2">
                <h4>ETUs - URL Shortner <span class="text-gray text-right text-small">2021</span></h4>
                <h6>Web Application (Laravel Framework)</h6>
                <ul>
                  <li>Convert your irritating long URLs to short URL with existing features.</li>
                </ul>
              </div>

            </div>
          </section>

          <hr />

          <section id="skillsKnown">
            <div class="form-part">
              <div class="row border-left">
                <h4>Skills</h4>
                  <ul>
                    <li>PHP</li>
                    <li>Android</li>
                    <li>Laravel</li>
                    <li>JS | HTML | CSS</li>
                  </ul>
              </div>
              <div class="row border-left">
                <h4>Hobbies</h4>
                <ul>
                  <li>Listening Music</li>
                  <li>Learning</li>
                  <li>Movie</li>
                </ul>
              </div>
            </div>
          </section>
        </div>
      </div>
      <div class="footer">
        <div class="container">
          <div class="footer-1">
            <span>Darshit Busa</span>
            <span><a href="mailto:darshitbusa8@gmail.com">darshitbusa8@gmail.com</a></span>
            <span><a href="tel:+918511881027">(+91) 851-188-1027</a></span>
          </div>
          <ul class="d-list">
            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
            <li><a href="#"><span class="fa fa-telegram"></span></a></li>
          </ul>
        </div>
      </div>
    </section>
    <section id="videoResume">
      <div class="container">
        <h3>Video Resume</h3>
        <h5>This is the Video Resume of the above Resume</h5>
             
        <video id="video" controls class="video-resume" preload="metadata">
          <source src="../assets/video/resume.mp4" type="video/mp4">
          <track label="English" kind="captions" srclang="en" src="../assets/video/sample.vtt" default>
       </video>

      </div>
    </section>
  </div>
</body>

</html>