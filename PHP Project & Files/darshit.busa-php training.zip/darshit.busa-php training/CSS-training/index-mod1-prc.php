<?php
  include '../header.php';
?>
  <section id="mainSection">
    <div class="row">
      <?php
        include 'sidebar.php';
      ?>
      <div class="main css-mod1-prc" id="content">
        <div id="app">
          <h2 class="page-title">CSS Practice Task - Module 1</h2>
          <!-- Practice 1 Section -->
          <h4>Aim : Provide text alignment to center to student Report Card which is created in Day1 assignment</h4>
          <section id="studentGrade">
            <table>
              <caption>Student Records</caption>
              <thead>
                <th>Name</th>
                <th>Roll No</th>
                <th>Year of Passing</th>
                <th>Maths</th>
                <th>Science</th>
                <th>English</th>
                <th>Grade</th>
              </thead>
              <tbody>
                <tr>
                  <td>101</td>
                  <td>John Doe</td>
                  <td>2019</td>
                  <td>78</td>
                  <td>82</td>
                  <td>70</td>
                  <td>A</td>
                </tr>
                <tr>
                  <td>102</td>
                  <td>Alexa Mark</td>
                  <td>2019</td>
                  <td>77</td>
                  <td>80</td>
                  <td>85</td>
                  <td>A+</td>
                </tr>
                <tr>
                  <td>103</td>
                  <td>Merry Parker</td>
                  <td>2019</td>
                  <td>89</td>
                  <td>90</td>
                  <td>88</td>
                  <td>A+</td>
                </tr>
                <tr>
                  <td>104</td>
                  <td>Alex Ray</td>
                  <td>2019</td>
                  <td>67</td>
                  <td>72</td>
                  <td>68</td>
                  <td>B+</td>
                </tr>
                <tr>
                  <td>105</td>
                  <td>Rose Jor-el</td>
                  <td>2019</td>
                  <td>65</td>
                  <td>60</td>
                  <td>68</td>
                  <td>B</td>
                </tr>
                <tr>
                  <td>106</td>
                  <td>Evens Gray</td>
                  <td>2019</td>
                  <td>80</td>
                  <td>75</td>
                  <td>79</td>
                  <td>B+</td>
                </tr>
              </tbody>
            </table>
          </section>
          <!-- / Practice 1 Section -->
          <hr />
          <!-- Practice 2 Section -->
          <h4>Aim : Provide Border to one paragraph and write some dummy text into it</h4>
          <section id="paragraphSection">
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Qui explicabo numquam nulla nisi, autem maxime
              est
              inventore quasi ex totam dignissimos quae, corporis iste libero animi odio modi? Voluptas, voluptate.
            </p>
            <p class="p1">
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Qui explicabo numquam nulla nisi, autem maxime
              est
              inventore quasi ex totam dignissimos quae, corporis iste libero animi odio modi? Voluptas, voluptate.
            </p>
          </section>
          <!-- / Practice 2 Section -->
          <hr />
          <!-- Practice 3 Section -->
          <h4>Aim : Create city list in horizontal order(using display properties)</h4>
          <section id="cityListSection">
            <ul>
              <li>Rajkot</li>
              <li>Surat</li>
              <li>Mumbai</li>
              <li>Pune</li>
              <li>Ahmedabad</li>
              <li>Vadodara</li>
              <li>Delhi</li>
              <li>Bangalore</li>
              <li>Kolkata</li>
              <li>Jaipur</li>
            </ul>
          </section>
          <!-- / Practice 3 Section -->
          <hr />
          <!-- Practice 4 Section -->
          <h4>Aim : Provide universal selector and apply blue color to a page</h4>
          <section id="universalSection">
            <ul>
              <li>Item 1</li>
              <li>Item 2</li>
              <li>Item 3</li>
            </ul>
            <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quia praesentium possimus dolores amet optio,
              quo dolore laboriosam culpa, cupiditate tenetur velit reiciendis, voluptates laudantium soluta assumenda
              dolorem aliquid eius blanditiis! </p>
          </section>
          <!-- / Practice 4 Section -->
          <hr />
          <!-- Practice 5 Section -->
          <h4>Aim : Suppose html markup below, apply all h1 and h2 blue color.</h4>
          <section id="codeSection">
            <div>
              <h1>Heading1</h1>
              <h2>Sub Heading</h2>
              <h1>Heading2</h1>
              <h2>Sub heading</h2>
            </div>
          </section>
          <!-- / Practice 5 Section -->
        </div>
      </div>
    </div>
  </section>
<?php include '../footer.php' ?>