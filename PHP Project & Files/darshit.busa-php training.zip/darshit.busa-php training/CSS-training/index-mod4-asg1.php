<?php 
    include "../header.php"
?>
    <section id="mainSection">
        <div class="row">
            <?php include 'sidebar.php' ?>
            <div class="main css-mod4-asg1" id="content">
                <h1 class="page-title">Gallery</h1>
                <section id="imageGallery">
                    <div class="row">
                        
                        <div class="grid-row-item">
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/rocks.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/falls2.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/paris.jpg" alt="Image 1">
                            </div>
                        </div>
            
                        <div class="grid-row-item">
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/nature.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/mist.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/paris.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/underwater.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/mist.jpg" alt="Image 1">
                            </div>
                        </div>
            
                        <div class="grid-row-item">
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/underwater.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/ocean.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/mountainskies.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/mist.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/paris.jpg" alt="Image 1">
                            </div>
                        </div>
            
                        <div class="grid-row-item">
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/rocks.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/falls2.jpg" alt="Image 1">
                            </div>
                            <div class="grid-column-item">
                                <img class="img" src="https://www.w3schools.com/w3images/paris.jpg" alt="Image 1">
                            </div>
                        </div>
            
                    </div>
                </section>
            </div>
        </div>
    </section>
<?php include '../footer.php' ?>