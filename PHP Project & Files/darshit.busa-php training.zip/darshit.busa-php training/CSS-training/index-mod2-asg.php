<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/mod2-asg-css-style.css">
    <title>Module 2 - Assignment</title>
</head>

<body>
    <section id="NavigationBar">
        <header>
            <ul>
                <li>
                    <img src="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg" alt="Brand Logo" class="brand_logo" />
                </li>
                <li>
                    <nav aria-label="HomeLink"><a href="index-mod2-asg.php">Home</a></nav>
                </li>
                <li>
                    <nav aria-label="AboutUsLink"><a href="aboutus-mod2-asg.php">AboutUs</a></nav>
                </li>
                <li>
                    <nav aria-label="ContactUsLink"><a href="contactus-mod2-asg.php">ContactUs</a> </nav>
                </li>
            </ul>
        </header>
    </section>
    <section id="mainSection">
        <div class="row">
            <div class="side">
                <h1>News Update</h1>
                <small>News On Internet</small>
                <article class="news">
                    <article class="news1">
                        <h4 title="Cryptocurrency">Warning Indians Against Cryptocurrencies, RBI Governor Shaktikanta
                            Das Says Tulips Have More Value</h4>
                        <p>India's central bank chief delivered a stark warning against investing in cryptocurrencies,
                            saying they lacked the underlying value of even a tulip - in a reference to a speculative
                            bubble that gripped the Netherlands in the 17th Century.</p>
                    </article>

                    <article class="news1">
                        <h4 title="Internet">Pegasus Snooping: Israel Police Allegedly Widely Using NSO Spyware to Hack
                            Phones</h4>
                        <p>Police used Pegasus spyware to hack phones of dozens of prominent Israelis, including a son
                            of former premier Benjamin Netanyahu, activists, and senior government officials, an Israeli
                            newspaper reported Monday.</p>
                    </article>
                </article>
            </div>
            <div class="main">
                <div class="row">
                    <h4>Dashboard </h4>
                    <h4 class="text-right text-muted"> 10-2-2022</h4>
                </div>
                <hr />
                <article class="news">
                    <article class="news1">
                        <h4 title="Cryptocurrency">Warning Indians Against Cryptocurrencies, RBI Governor Shaktikanta
                            Das Says Tulips Have More Value</h4>
                        <p>India's central bank chief delivered a stark warning against investing in cryptocurrencies,
                            saying they lacked the underlying value of even a tulip - in a reference to a speculative
                            bubble that gripped the Netherlands in the 17th Century.</p>
                    </article>

                    <article class="news1">
                        <h4 title="Internet">Pegasus Snooping: Israel Police Allegedly Widely Using NSO Spyware to Hack
                            Phones</h4>
                        <p>Police used Pegasus spyware to hack phones of dozens of prominent Israelis, including a son
                            of former premier Benjamin Netanyahu, activists, and senior government officials, an Israeli
                            newspaper reported Monday.</p>
                    </article>


                    <article class="news1">
                        <h4 title="Cryptocurrency">Warning Indians Against Cryptocurrencies, RBI Governor Shaktikanta
                            Das Says Tulips Have More Value</h4>
                        <p>India's central bank chief delivered a stark warning against investing in cryptocurrencies,
                            saying they lacked the underlying value of even a tulip - in a reference to a speculative
                            bubble that gripped the Netherlands in the 17th Century.</p>
                    </article>

                    <article class="news1">
                        <h4 title="Internet">Pegasus Snooping: Israel Police Allegedly Widely Using NSO Spyware to Hack
                            Phones</h4>
                        <p>Police used Pegasus spyware to hack phones of dozens of prominent Israelis, including a son
                            of former premier Benjamin Netanyahu, activists, and senior government officials, an Israeli
                            newspaper reported Monday.</p>
                    </article>
                </article>

            </div>
        </div>
    </section>
    <footer class="footer">
        <ul>
            <li>Darshit Busa</li>
            <li>info@xyz.com</li>
        </ul>
    </footer>
</body>

</html>