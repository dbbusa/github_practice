<?php include '../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include 'sidebar.php' ?>
        <div class="main css-mod3-prac" id="content">
            <!-- Exercise 1 -->
            <section id="exercise1">
                <h2>Exercise 1 : Set the width of the div element to "200px".</h2>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>
            <!-- / Exercise 1 -->
            <hr />

            <!-- Exercise 2 -->
            <section id="exercise2">
                <h2>Exercise 2 : Add a 2px solid red border to the div element.</h2>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>
            <!-- / Exercise 2 -->
            <hr />

            <!-- Exercise 3 -->
            <section id="exercise3">
                <h2>Exercise 3 : Add 25 pixels space between the div element's border and it's content.</h2>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>
            <!-- / Exercise 3 -->
            <hr />

            <!-- Exercise 4 -->
            <section id="exercise4">
                <h2>Exercise 4 : Add a 25 pixels space outside, to the left of the div element.</h2>
                <div>
                    Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt
                    ut labore et dolore magna aliqua.
                </div>
            </section>
            <!-- / Exercise 4 -->
            <hr />

            <!-- Exercise 5 -->
            <section id="exercise5">
                <h2>Exercise 5 : Create a flexbox with four flex items</h2>
                <div class="row">
                    <div class="boxes"></div>
                    <div class="boxes"></div>
                    <div class="boxes"></div>
                    <div class="boxes"></div>
                </div>
            </section>
            <!-- / Exercise 5 -->

            <hr />
            <!-- Exercise 6 -->
            <section id="exercise6">
                <h2>Exercise 6 : Flexbox with three flex items –right to left direction</h2>
                <div class="row">
                    <div class="boxes">1</div>
                    <div class="boxes">2</div>
                    <div class="boxes">3</div>
                </div>
            </section>
            <!-- / Exercise 6 -->
            <hr />

            <!-- Exercise 7 -->
            <section id="exercise7">
                <h2>Exercise 7 : Flexbox image gallery</h2>
                <div class="row">
                    <div class="column">
                        <img class="img" src="https://www.industrialempathy.com/img/remote/ZiClJf-1920w.jpg" alt="Image 1">
                        <img class="img" src="https://cdn.jpegmini.com/user/images/slider_puffin_before_mobile.jpg" alt="Image 2">
                        <img class="img" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/250px-Image_created_with_a_mobile_phone.png" alt="Image 3">
                        <img class="img" src="https://www.ipnoze.com/wordpress/wp-content/uploads/2019/09/plus-belles-photos-de-l-annee-2019-concours-agora-images-009.jpg" alt="Image 4">
                    </div>

                    <div class="column">
                        <img class="img" src="https://www.industrialempathy.com/img/remote/ZiClJf-1920w.jpg" alt="Image 1">
                        <img class="img" src="https://cdn.jpegmini.com/user/images/slider_puffin_before_mobile.jpg" alt="Image 2">
                        <img class="img" src="https://cdn.jpegmini.com/user/images/slider_puffin_before_mobile.jpg" alt="Image 5">
                        <img class="img" src="https://www.canon.com.au/-/media/images/learning/how-to-print-professional-photos-at-home/image-1-kirkr-twelveapostlesvictoria-1000.ashx?la=en" alt="Image 7">
                    </div>

                    <div class="column">
                        <img class="img" src="https://www.industrialempathy.com/img/remote/ZiClJf-1920w.jpg" alt="Image 1">
                        <img class="img" src="https://cdn.jpegmini.com/user/images/slider_puffin_before_mobile.jpg" alt="Image 2">
                        <img class="img" src="https://www.canon.com.au/-/media/images/learning/how-to-print-professional-photos-at-home/image-1-kirkr-twelveapostlesvictoria-1000.ashx?la=en" alt="Image 7">
                        <img class="img" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/250px-Image_created_with_a_mobile_phone.png" alt="Image 3">
                    </div>
                </div>
            </section>
            <!-- / Exercise 7 -->
        </div>
    </div>
</section>
<?php
include '../footer.php'
?>