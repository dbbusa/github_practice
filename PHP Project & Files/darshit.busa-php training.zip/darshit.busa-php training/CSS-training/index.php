<?php
    include '../header.php';
?>
    <section id="mainSection">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            <div class="main">
                <div class="row">
                    <h4><strong>CSS</strong> </h4>
                    <hr />
                    <div class="image-container" id="addContent">
                        <img src="../assets/image/css.png" alt="Css3 Logos" class="mainimg">
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php 
    include '../footer.php';
?>