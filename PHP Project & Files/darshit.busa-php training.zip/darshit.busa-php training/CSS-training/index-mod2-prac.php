<?php
    include '../header.php';
?>
    <section id="mainSection">
        <div class="row">
            <?php 
                include 'sidebar.php';
            ?>
            <div class="main css-mod2-prac" id="content">
              <div id="app">
                <h2 class="page-title">CSS Practice Task - Module 2</h2>
                <!-- Practice 1 Section -->
                <section id="boxSection">
                  <h4>Aim : Parent div should contain 3 div inside. Div should be arranged in following manner.</h4>
                    <div class="parentDiv">
                        <div class="boxes">
                          
                        </div>
                        <div class="boxes">
          
                        </div>
                        <div class="boxes">
          
                        </div>
                    </div>
                </section>
                <!-- / Practice 1 Section -->
                <hr/>
                <!-- Practice 2 Section -->
                <section class="positionSection">
                  <h4>Aim : Practice position properties static, relative, fixed and absolute.</h4>
                    <div class="p-relative">
                      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat error rem harum nulla minus fugit!
                        <div class="p-absolute">
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, vitae.
                        </div>
                    </div>
          
          
                    <div class="p-static">
                      <h5>Position Static </h5>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem maxime nemo accusamus iusto eius illum provident nihil atque amet, officiis natus placeat vel inventore. Minus accusantium sint repudiandae. Minima, corrupti.
                    </div>
                    <div class="p-fixed">
                      <h5>Position Fixed </h5>
                    </div>
                </section>
                <!-- / Practice 2 Section -->
                <hr />
          
                <!-- Practice 3 Section  -->
                
                <section id="overflowSection">
                  <h4>Aim : Suppose we have a div with specific height and width and we need to arrange more text into it. Use overflow properties.</h4>  
                  <div class="overflowDiv">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem voluptates consectetur, at minima esse consequatur! Asperiores a nisi odit, deserunt vel, itaque repellendus cupiditate consectetur sequi commodi accusamus! Cupiditate numquam eos architecto qui non maiores iste officiis unde aperiam autem maxime ipsam debitis nulla expedita obcaecati, in aspernatur ea itaque, quos perferendis nemo! Eligendi harum animi a sapiente expedita repudiandae nisi dolores fuga reprehenderit, doloribus amet error qui nesciunt magnam aspernatur optio consectetur, rerum dolorum reiciendis minus. Labore ratione sapiente laboriosam soluta nam. Quidem pariatur porro quia at quas? Consectetur atque nulla sequi, id adipisci pariatur ipsam! Eum sequi perferendis quisquam cumque aut ab ea fugit delectus eius dolor animi, ratione quis, corrupti labore, dolores reprehenderit iure quae quibusdam deserunt sapiente deleniti! Amet, unde sed harum dolore, voluptatem omnis, nihil suscipit magnam reiciendis repellendus ab aspernatur minima doloribus eum dignissimos? Neque asperiores nam corrupti corporis minima nemo quo, blanditiis magnam dolorum a nobis, perspiciatis maxime culpa doloribus dicta omnis iusto quidem recusandae necessitatibus maiores ratione cupiditate! Dolorum asperiores, magnam accusantium quibusdam laboriosam voluptate rerum corrupti molestias deleniti neque at sed molestiae nobis repellat dolorem recusandae magni. Fugiat odio, velit maxime debitis minus qui laborum, at nemo quas culpa reiciendis veritatis.
                  </div>
                </section>
                <!-- / Practice 3 Section  -->
              </div>
            </div>
        </div>
    </section>
<?php 
    include '../footer.php';
?>