<div class="side">
    <h3 class="text-center">Learning</h3>

    <ul class="dropdown-ul">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module1" role="button" aria-expanded="false" aria-controls="module1">
                Module 1
            </a>
            <ul class="collapse sub-dropdown" id="module1">
                <li><a class="module-item" target="_blank" href="index-mod1-assignment.php">Assignments</a></li>
                <li><a class="module-item" href="index-mod1-prc.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module2" role="button" aria-expanded="false" aria-controls="module2">
                Module 2
            </a>
            <ul class="collapse sub-dropdown" id="module2">
                <li><a class="module-item" target="_blank" href="index-mod2-asg.php">Assignments</a></li>
                <li><a class="module-item" href="index-mod2-prac.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module3" role="button" aria-expanded="false" aria-controls="module3">
                Module 3
            </a>
            <ul class="collapse sub-dropdown" id="module3">
                <li><a class="module-item" href="index-mod3-asg.php">Assignments</a></li>
                <li><a class="module-item" href="index-mod3-prac.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module4" role="button" aria-expanded="false" aria-controls="module4">
                Module 4
            </a>
            <ul class="collapse sub-dropdown" id="module4">
                <li><a class="module-item" title="Gallery" href="index-mod4-asg1.php">Assignments 1</a></li>
                <li><a class="module-item" target="_blank" title="Resume" href="index-mod4-asg2.php">Assignments 2</a></li>
                <li><a class="module-item" title="Practice" href="index-mod4-prac.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module5" role="button" aria-expanded="false" aria-controls="module5">
                Module 5
            </a>
            <ul class="collapse sub-dropdown" id="module5">
                <li><a class="module-item" title="Responsive Layout Design" target="_blank" href="index-mod5-asg.php">Assignments</a></li>
            </ul>
        </li>
    </ul>
</div>