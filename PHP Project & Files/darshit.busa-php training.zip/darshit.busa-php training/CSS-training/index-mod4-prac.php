<?php 
    include "../header.php";
?>
    <section id="mainSection">
        <div class="row">
            <?php include 'sidebar.php' ?>
            <div class="main css-mod4-prac" id="content">
                <h1 class="page-title">Module 4 - Practice</h1>
    

                <!-- Exercise1 -->
                <section id="Exercise1">
                    <h4>Aim : You have one h1 and one paragraph in your page with blue color border. For all the media screen and query selector (maximum width 500px) it should be change to red color border.</h4>
            
                    <h1 class="ex-heading ex1-border">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis, iste.</h1>
                    <p class="ex-paragraph ex1-border">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Assumenda minus doloribus impedit quae dolore voluptatibus consectetur, adipisci numquam ab eaque velit deserunt tempora perferendis ratione, deleniti placeat libero explicabo esse?</p>
                </section>
                <!-- / Exercise1 -->
                <hr />
            
                <!-- Exercise2 -->
                <section id="Exercise2">
                    <h4>Aim : Media queries with breakpoint</h4>
            
                    <h1 class="ex-heading ex2-border">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis, iste.</h1>
                    <p class="ex-paragraph ex2-border">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Assumenda minus doloribus impedit quae dolore voluptatibus consectetur, adipisci numquam ab eaque velit deserunt tempora perferendis ratione, deleniti placeat libero explicabo esse?</p>
                </section>
                <!-- / Exercise2 -->
                <hr />
            
                <!-- Exercise 3  -->
                <section id="Exercise3">
                    <h4>Aim : Hide elements with Media queries</h4>
            
                    <h1 class="ex-heading">Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus, debitis!</h1>
                    <p class="ex-paragraph d-sm-none"> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Omnis id ratione vel debitis voluptates repudiandae aut, sapiente eaque, dolore pariatur modi harum! Debitis cumque eum vero tenetur expedita, ex sunt.</p>
                </section>
                <!-- / Exercise 3 -->
            
                <hr/>
                <!-- Exercise 4 -->
                <section id="Exercise4">
                    <h4>Aim :  Change Font size with Media Queries</h4>
            
                    <h1 class="ex-heading font-16-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, excepturi!</h1>
                    <p class="ex-paragraph font-14-sm">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident suscipit eum similique labore esse officia doloribus error magnam magni, excepturi vero cumque quos, accusantium, exercitationem deleniti illum impedit beatae earum.</p>
                </section>
                <!-- / Exercise 4 -->
            </div>
        </div>
    </section>
   <?php include '../footer.php' ?>