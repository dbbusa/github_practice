<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark">
            <div class="container" id="content">
                <h2 class="h1 text-center text-warning">Buttons & Buttons Groups</h2>


                <h4 class="text-center text-info">Buttons</h4>
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-primary"> Button Primary </button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-success"> Button Success </button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-danger"> Button Danger</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-info"> Button Info</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-warning"> Button Warning</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-light"> Button Light</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-secondary"> Button Secondary</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-link"> Button Link </button>
                    </div>
                </div>
                <hr class="bg-info mt-5">
                <h4 class="text-center text-info">Buttons Outline</h4>
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-primary "> Button Primary outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-success"> Button Success Outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-danger"> Button Danger Outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-info"> Button Info Outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-warning"> Button Warning Outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-light"> Button Light Outline</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-outline-secondary"> Button Secondary Outline</button>
                    </div>
                </div>
                <hr class="bg-info mt-5">
                <h4 class="text-center text-info">Buttons Size and State</h4>
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-primary btn-lg"> Button Primary Large</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-success btn-sm"> Button Success Small</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <button class="btn btn-danger disabled"> Button Danger Disabled</button>
                    </div>
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-2 text-center">
                        <a href="#" class="btn btn-danger disabled"> Link Disabled</a>
                    </div>
                </div>

                <hr class="bg-info mt-5">
                <h4 class="text-center text-info">Buttons Group</h4>
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group" role="group" aria-label="Practice Button Group">
                            <button class="btn btn-primary"> Button 1</button>
                            <button class="btn btn-primary"> Button 2</button>
                            <button class="btn btn-primary"> Button 3</button>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group">
                            <div class="btn-group" role="group" aria-label="Practice mixed Button Group">
                                <button class="btn btn-primary"> Button 3</button>
                                <button class="btn btn-success"> Button 1</button>
                                <button class="btn btn-warning"> Button 2</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group">
                            <div class="btn-group" role="group" aria-label="Practice mixed outline Button Group">
                                <button class="btn btn-outline-success"> Button 1</button>
                                <button class="btn btn-outline-primary"> Button 3</button>
                                <button class="btn btn-outline-warning"> Button 2</button>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="bg-info mt-5">
                <h4 class="text-center text-info">Input Groups</h4>
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group" role="group" aria-label="Input Group">
                            <div class="input-group">
                                <div class="input-group-text">#</div>
                                <input type="text" class="form-control" placeholder="Enter Text" aria-label="Input Group">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group" role="group" aria-label="Input Group">
                            <div class="input-group">
                                <div class="input-group-text bg-primary">@</div>
                                <input type="email" class="form-control" placeholder="Enter Email" aria-label="Input Group">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group" role="group" aria-label="Input Group">
                            <input type="radio" class="btn-check" id="btn1" name="test" value="success" aria-label="Input Group">
                            <label class="btn btn-outline-success" for="btn1">success</label>
                            <input type="radio" class="btn-check" id="btn2" name="test" value="primary" aria-label="Input Group">
                            <label class="btn btn-outline-primary" for="btn2">primary</label>
                            <input type="radio" class="btn-check" id="btn3" name="test" value="info" aria-label="Input Group">
                            <label class="btn btn-outline-info" for="btn3">info</label>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-4 col-lg-4 mt-2 text-center">
                        <div class="btn-group-vertical" role="group" aria-label="Input Group">
                            <input type="radio" class="btn-check" id="btn1" name="test" value="success" aria-label="Input Group">
                            <label class="btn btn-outline-success" for="btn1">success</label>
                            <input type="radio" class="btn-check" id="btn2" name="test" value="primary" aria-label="Input Group">
                            <label class="btn btn-outline-primary" for="btn2">primary</label>
                            <input type="radio" class="btn-check" id="btn3" name="test" value="info" aria-label="Input Group">
                            <label class="btn btn-outline-info" for="btn3">info</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>