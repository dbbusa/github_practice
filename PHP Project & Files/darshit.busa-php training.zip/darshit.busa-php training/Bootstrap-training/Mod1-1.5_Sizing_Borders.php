<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <h2 class="display-2 text-center text-warning">Sizing & Borders</h2>

                <h4 class="text-center fw-bold mt-4">Sizing</h4>

                <div class="row">
                    <div class="w-25 p-3 text-white bg-secondary">Width 25%</div>
                    <div class="w-75 p-3 text-white bg-warning">Width 75%</div>
                    <div class="w-75 p-3 text-white bg-success">Width 75%</div>
                    <div class="w-25 p-3 text-white bg-info">Width 25%</div>
                    <div class="w-100 p-3 bg-secondary">Width 100%</div>
                    <div class="w-50 p-3 bg-info">Width 50%</div>
                    <div class="w-50 p-3 bg-danger">Width 50%</div>
                    <div class="w-auto p-3 bg-secondary">Width auto</div>
                </div>

                <hr>
                <h4 class="text-center fw-bold mt-4">Borders</h4>

                <div class="row">
                    <div class="p-5 w-auto m-2 border-0"> Border 0</div>
                    <div class="p-5 w-auto m-2 border border-1"> Border 1</div>
                    <div class="p-5 w-auto m-2 border border-2"> Border 2</div>
                    <div class="p-5 w-auto m-2 border border-3"> Border 3</div>
                    <div class="p-5 w-auto m-2 border border-4"> Border 4</div>
                    <div class="p-5 w-auto m-2 border border-5"> Border 5</div>
                </div>
                <hr>
                <h6 class="text-center">Border Width with Color</h6>
                <div class="row">
                    <div class="p-5 w-auto m-2 border-success border-0"> Border 0 Color success </div>
                    <div class="p-5 w-auto m-2 border-warning border border-1"> Border 1 Color warning</div>
                    <div class="p-5 w-auto m-2 border-info border border-2"> Border 2 Color info</div>
                    <div class="p-5 w-auto m-2 border-danger border border-3"> Border 3 Color danger</div>
                    <div class="p-5 w-auto m-2 border-primary border border-4"> Border 4 Color primary</div>
                    <div class="p-5 w-auto m-2 border-success border border-5"> Border 5 Color success</div>
                </div>
                <hr>
                <h6 class="text-center">Border Additive</h6>
                <div class="row">
                    <div class="p-5 bg-light w-auto m-2 border-warning border-top"> Border top</div>
                    <div class="p-5 bg-light w-auto m-2 border-info border-bottom"> Border bottom</div>
                    <div class="p-5 bg-light w-auto m-2 border-danger border-start"> Border left</div>
                    <div class="p-5 bg-light w-auto m-2 border-primary border-end"> Border right</div>
                </div>
                <hr>
                <h6 class="text-center">Border Radius</h6>
                <div class="row">
                    <div class="p-2 bg-dark text-white w-auto m-2 rounded-0"> Border no radius</div>
                    <div class="p-2 bg-dark text-white w-auto m-2 rounded-1"> Border rounded</div>
                    <div class="p-2 bg-dark text-white w-auto m-2 rounded-circle"> Border circle</div>
                    <div class="p-2 bg-dark text-white w-auto m-2 rounded-pill"> Border pill</div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>