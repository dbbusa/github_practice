<?php include '../header.php' ?>
<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark">
            <div class="container" id="content">
                <h2 class="h1 text-center text-warning">Tables & Pagination</h2>

                <div class="row">
                    <div class="col-sm-12 col-md-8 col-lg-8 mx-auto">
                        <h5 class="text-center text-info text-decoration-underline">Normal Table with Center Pagination</h5>
                        <table class="table table-light caption-top">
                            <caption class="text-center">Normal Table with Center Pagination</caption>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Products</th>
                                    <th>Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-info">10</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-secondary">15</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-danger">5</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-primary">3</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-warning">30</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-success">5</span></td>
                                    <td>US</td>
                                </tr>
                            </tbody>
                        </table>
                        <nav aria-label="Table Pagination">
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">&laquo;</a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">&raquo;</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-8 col-lg-8 mx-auto">
                        <h5 class="text-center text-info text-decoration-underline">Active Table with Pagination at End </h5>
                        <table class="table table-light table-border">
                            <caption class="text-center"> Active Table with Pagination at End</caption>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Products</th>
                                    <th>Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-active">
                                    <td>1</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-info">10</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-secondary">15</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-danger">5</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-primary">3</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-warning">30</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-success">5</span></td>
                                    <td>US</td>
                                </tr>
                            </tbody>
                        </table>
                        <nav aria-label="Table Pagination">
                            <ul class="pagination justify-content-end ">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12 col-md-8 col-lg-8 mx-auto">
                        <h5 class="text-center text-info text-decoration-underline">Head Color Table and small Pagination</h5>
                        <table class="table table-light table-border">
                            <caption class="text-end">Head Color Table and small Pagination</caption>
                            <thead class="table-primary">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Products</th>
                                    <th>Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-active">
                                    <td>1</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-info">10</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-secondary">15</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-danger">5</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-primary">3</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-warning">30</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-success">5</span></td>
                                    <td>US</td>
                                </tr>
                            </tbody>
                        </table>

                        <nav aria-label="Table Pagination">
                            <ul class="pagination pagination-sm justify-content-end">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">&laquo;</a>
                                </li>
                                <li class="page-item active "><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">&raquo;</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>

                <div class="row">
                    <div class=" table-responsive col-sm-12 col-md-8 col-lg-8 mx-auto">
                        <table class="table  table-responsive table-light table-border">
                            <caption class="text-center text-info text-decoration-underline">Table Responsive</caption>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Products</th>
                                    <th>Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-active">
                                    <td>1</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-info">10</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-secondary">15</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-danger">5</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-primary">3</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-warning">30</span></td>
                                    <td>US</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>John Doe</td>
                                    <td>John@gmail.com</td>
                                    <td><span class="badge bg-success">5</span></td>
                                    <td>US</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>