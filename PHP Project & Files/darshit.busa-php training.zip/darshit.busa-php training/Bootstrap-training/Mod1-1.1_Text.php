<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <div class="row">
                    <h2 class="display-2 text-center text-success">Text Alignment & Display</h2>
                    <h1 class="display-1 text-muted">Display 1</h1>
                    <h1 class="display-2 text-warning">Display 2</h1>
                    <h1 class="display-3 text-primary">Display 3</h1>
                    <h1 class="display-4 text-danger">Display 4</h1>
                    <br>
                    <br>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptates eum officiis nesciunt
                        provident quidem iure est modi consequuntur ipsum quibusdam.</p>
                    <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus, ullam!
                        Pariatur blanditiis sequi, ea voluptatibus aspernatur dolorem omnis magnam temporibus?</p>
                    <p class="text-truncate">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facere
                        ducimus ipsa voluptates ad accusantium asperiores error neque nisi a veritatis.</p>

                    <p class="fw-bold">Text Bold</p>
                    <p class="fw-normal">Text Normal</p>
                    <p class="fst-italic">Text Italic</p>

                    <p class="text-lowercase">MAKE LOWERCASE</p>
                    <p class="text-uppercase">make uppercase</p>
                    <p class="text-capitalize">make capitalized</p>

                    <ul class="list-unstyled">
                        <li>Lorem ipsum dolor sit amet.</li>
                        <li>Lorem ipsum dolor sit amet.</li>
                        <li>Lorem ipsum dolor sit amet.</li>
                        <li>Lorem ipsum dolor sit amet.</li>
                    </ul>

                    <ul class="list-inline">
                        <li class="list-inline-item">Lorem ipsum</li>
                        <li class="list-inline-item">Lorem ipsum </li>
                        <li class="list-inline-item">Lorem ipsum </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>