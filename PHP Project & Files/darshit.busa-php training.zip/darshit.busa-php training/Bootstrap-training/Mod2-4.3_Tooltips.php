<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bg-dark bootstrap-mod2-prac p-2">
            <div class="container">
                <h2 class="h1 text-center text-warning">Tooltips</h2>

                <div class="row">
                    <div class="d-block">
                        <button class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Top"> Tooltip
                            1</button>
                        <button class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="left" title="Left"> Tooltip
                            2</button>
                        <button class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bottom">
                            Tooltip 3</button>
                        <button class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Right">
                            Tooltip 4</button>
                    </div>
                </div>

                <div class="d-block mt-5 text-center">
                    <span class="d-inline-block mx-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Disabled Top">
                        <button class="btn btn-success" disabled> Tooltip
                            1</button>
                    </span>
                    <span class="d-inline-block mx-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="left" title="Disabled Left">
                        <button class="btn btn-primary" disabled> Tooltip
                            2</button>
                    </span>
                    <span class="d-inline-block mx-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Disabled Bottom">
                        <button class="btn btn-danger" disabled>
                            Tooltip 3</button>
                    </span>

                    <span class="d-inline-block mx-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="right" title="Disabled Right">
                        <button class="btn btn-secondary" disabled>
                            Tooltip 4</button>
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../footer.php' ?>