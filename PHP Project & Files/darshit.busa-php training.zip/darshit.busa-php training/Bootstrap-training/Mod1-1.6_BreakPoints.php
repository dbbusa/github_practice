<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark">
            <div class="container">
                <h2 class="display-2 text-center text-warning">Break Points</h2>


                <div class="row mt-4">
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-white bg-success"> Lorem ipsum dolor sit, amet
                        consectetur adipisicing elit. Illum, inventore. </div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-white bg-danger"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi. </div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-white bg-success"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-dark bg-info"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-dark bg-warning"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-white bg-success"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-drak bg-info"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                    <div class="col-sm-12 col-md-4 col-lg-3 p-3 text-dark bg-warning"> Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Soluta, modi.</div>
                </div>


            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>