<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <h2 class="display-2 text-center text-warning">Colors & Background</h2>

                <h4 class="text-center fw-bold mt-4">Colors</h4>

                <div class="row">
                    <div class="col-3 text-primary">Text Color Primary</div>
                    <div class="col-3 text-muted">Text Color Muted</div>
                    <div class="col-3 text-warning">Text Color Warning</div>
                    <div class="col-3 text-danger">Text Color Danger</div>
                    <div class="col-3 text-secondary">Text Color Secondary</div>
                    <div class="col-3 text-danger">Text Color Dark</div>
                    <div class="col-3 text-info">Text Color Info</div>
                </div>

                <h4 class="text-center fw-bold mt-4">Background</h4>
                <div class="row">
                    <div class="col-2 p-3 m-2 bg-danger"> Background - Danger </div>
                    <div class="col-2 p-3 m-2 bg-info"> Background - Info</div>
                    <div class="col-2 p-3 m-2 bg-warning"> Background - Warning </div>
                    <div class="col-2 p-3 m-2 bg-primary"> Background - Primary </div>
                    <div class="col-2 p-3 m-2 bg-dark text-white"> Background - Dark </div>
                    <div class="col-2 p-3 m-2 bg-secondary"> Background - Secondary</div>
                </div>

                <h4 class="text-center fw-bold mt-4">Gradient Background</h4>
                <div class="row">
                    <div class="col-2 p-3 m-2 bg-danger bg-gradient"> Background - Danger </div>
                    <div class="col-2 p-3 m-2 bg-info bg-gradient"> Background - Info</div>
                    <div class="col-2 p-3 m-2 bg-warning bg-gradient"> Background - Warning </div>
                    <div class="col-2 p-3 m-2 bg-primary bg-gradient"> Background - Primary </div>
                    <div class="col-2 p-3 m-2 bg-dark bg-gradient text-white"> Background - Dark </div>
                    <div class="col-2 p-3 m-2 bg-secondary bg-gradient"> Background - Secondary</div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>