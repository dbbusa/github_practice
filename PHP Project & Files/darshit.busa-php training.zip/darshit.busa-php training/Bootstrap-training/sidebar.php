<div class="side">
    <h3 class="text-center">Learning</h3>

    <ul class="dropdown-ul">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module1" role="button" aria-expanded="false" aria-controls="module1">
                Module 1
            </a>
            <ul class="collapse sub-dropdown" id="module1">
                <li><a class="module-item" href="Mod1-1.1_Text.php">1.1 Text Alignment
                        & Display</a></li>
                <li><a class="module-item" href="Mod1-1.2_Float_Fixed.php">1.2 Float &
                        Fixed Positions</a></li>
                <li><a class="module-item" href="Mod1-1.3_Colors_Background.php">1.3
                        Colors & Background</a></li>
                <li><a class="module-item" href="Mod1-1.4_Margin_Spacing.php">1.4
                        Margin and Spacing</a></li>
                <li><a class="module-item" href="Mod1-1.5_Sizing_Borders.php">1.5
                        Sizing & Borders</a></li>
                <li><a class="module-item" href="Mod1-1.6_BreakPoints.php">1.6 CSS
                        Breakpoints</a></li>
                <li><a href="Mod1-2.1_Btn_BtnGrp.php" class="module-item"> 2.1 Buttons &
                        Buttons Groups</a></li>
                <li><a href="Mod1-2.2_Navbars_Nav.php" class="module-item"> 2.2 Navbars
                        &
                        Nav</a></li>
                <li><a href="Mod1-2.3_ListGroups_Badges.php" class="module-item"> 2.3
                        ListGroups & Badges</a></li>
                <li><a href="Mod1-2.4_Forms_Input.php" class="module-item"> 2.4 Forms &
                        Input</a></li>
                <li><a href="Mod1-2.5_Input_Group.php" class="module-item"> 2.5 Input
                        Groups</a></li>
                <li><a href="Mod1-2.6_Alerts_Progress.php" class="module-item"> 2.6
                        Alerts
                        and Progress Bars</a></li>
                <li><a href="Mod1-2.7_Tables_Pagination.php" class="module-item"> 2.7
                        Tables & Pagination</a></li>
                <li><a href="Mod1-2.8_Working_Cards.php" class="module-item"> 2.8
                        Working
                        with Cards</a></li>
                <li><a href="Mod1-2.9_Media_Objects.php" class="module-item"> 2.9 Media
                        Objects</a></li>
                <li><a href="Mod1-2.10_Breadcrumbs.php" class="module-item"> 2.10
                        Breadcrumbs</a></li>
                <li><a href="Mod1-2.11_Carousel.php" class="module-item"> 2.11
                        Carousel</a></li>
                <li><a href="Mod1-2.12_Badges.php" class="module-item"> 2.12 Badge</a>
                </li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module2" role="button" aria-expanded="false" aria-controls="module2">
                Module 2
            </a>
            <ul class="collapse sub-dropdown" id="module2">
                <hr>
                <li><a href="index-mod2-asg.php" target="_blank" class="module-item" title="Responsive Resume"> Assignment</a></li>
                <hr>
                <li><a href="Mod2-3.1_Grid_Align.php" class="module-item"> 3.1 Grid
                        Alignment </a></li>
                <li><a href="Mod2-3.2_Flexbox.php" class="module-item"> 3.2 Flexbox
                        Classes </a></li>
                <li><a href="Mod2-3.3_Margin_Order.php" class="module-item"> 3.3 Auto
                        Margin wrap & Ordering </a></li>
                <li><a href="Mod2-4.1_Carousel_Slider.php" class="module-item"> 4.1
                        Carousel Slider </a></li>
                <li><a href="Mod2-4.2_Collapse_Accordion.php" class="module-item"> 4.2
                        Collapse & Accordion </a></li>
                <li><a href="Mod2-4.3_Tooltips.php" class="module-item"> 4.3 Tooltips
                    </a>
                </li>
                <li><a href="Mod2-4.4_Popovers.php" class="module-item"> 4.4 Popovers
                    </a>
                </li>
                <li><a href="Mod2-4.5_Modals.php" class="module-item"> 4.5 Modals </a>
                </li>
            </ul>
        </li>

        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module3" role="button" aria-expanded="false" aria-controls="module3">
                Module 3
            </a>
            <ul class="collapse sub-dropdown" id="module3">
                <li><a href="index-mod3-asg.php" target="_blank" class="module-item" title="LoopLAB Project"> Assignment</a></li>
                <li><a href="index-mod3-prac.php" target="_blank" class="module-item" title="Album Example"> Practice</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module4" role="button" aria-expanded="false" aria-controls="module4">
                Module 4
            </a>
            <ul class="collapse sub-dropdown" id="module4">
                <li><a href="index-mod4-asg.php" target="_blank" class="module-item" title="Blogen Project"> Assignment</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module5" role="button" aria-expanded="false" aria-controls="module5">
                Module 5
            </a>
            <ul class="collapse sub-dropdown" id="module5">
                <li><a href="index-mod5-asg.php" target="_blank" class="module-item" title="Mizuxe Project"> Assignment</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module6" role="button" aria-expanded="false" aria-controls="module6">
                Module 6
            </a>
            <ul class="collapse sub-dropdown" id="module6">
                <li><a href="index-mod6-asg.php" target="_blank" class="module-item" title="goibibo design"> Assignment</a></li>
                <li><a href="index-mod6-prac.php" target="_blank" class="module-item" title="Practice Portfolio"> Practice</a></li>
            </ul>
        </li>

    </ul>
</div>