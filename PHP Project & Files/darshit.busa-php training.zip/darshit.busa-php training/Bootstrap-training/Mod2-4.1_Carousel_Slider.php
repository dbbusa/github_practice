<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod2-prac bg-dark p-2">
            <div class="container">
                <h2 class="h1 text-center text-warning">Carousel Slider</h2>

                <div class="container">
                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" title="Lake" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" title="Mountain" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" title="Sunrise" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="https://cdn.pixabay.com/photo/2016/05/05/02/37/sunset-1373171_960_720.jpg" class="d-block w-100" alt="Lake">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4 class="fw-bold">Lake Image</h4>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="https://cdn.pixabay.com/photo/2012/08/27/14/19/mountains-55067_960_720.png" class="d-block w-100" alt="Mountain">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4 class="fw-bold">Mountain Image</h4>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="https://cdn.pixabay.com/photo/2015/10/30/20/13/sunrise-1014712_960_720.jpg" class="d-block w-100" alt="Sunrise">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4 class="fw-bold">Sunrise Image</h4>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>