<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark p-2">
            <div class="container">
                <h2 class="h1 text-center text-warning">Working with Cards</h2>

                <div class="row">
                    <div class="col-sm-12 col-md-4 col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                Normal Card
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Lorem ipsum dolor sit amet.</h5>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                                <a href="#" class="btn btn-sm btn-warning">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4">
                        <div class="card bg-warning">
                            <div class="card-header">
                                Card With Color Warning
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Lorem ipsum dolor sit amet.</h5>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                                <a href="#" class="btn btn-sm btn-success">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4">
                        <div class="card bg-info">
                            <div class="card-header">
                                Card With Color Info
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Lorem ipsum dolor sit amet.</h5>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                                <a href="#" class="btn btn-sm btn-danger">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <div class="card mb-3 p-3">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="https://1000logos.net/wp-content/uploads/2020/05/Google-Photos-logo.png" class="img-fluid rounded-start" alt="Image">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Lorem ipsum dolor sit amet.</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, amet? Repudiandae veritatis facere ipsum temporibus!</p>
                                        <p class="card-text"><small class="text-muted">- Card Practice</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <div class="card mb-3 p-3">
                            <div class="row g-0">
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Lorem ipsum dolor sit amet.</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, amet? Repudiandae veritatis facere ipsum temporibus!</p>
                                        <p class="card-text"><small class="text-muted">- Card Practice</small></p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="https://1000logos.net/wp-content/uploads/2020/05/Google-Photos-logo.png" class="img-fluid rounded-start" alt="Image">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>