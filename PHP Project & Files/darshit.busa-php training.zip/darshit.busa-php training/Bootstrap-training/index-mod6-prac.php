<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="icon" type="image/svg+xml" href="favicon.svg" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/css/style-bootstrap-mod6-prac.css">
  <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <title>Portfolio</title>
</head>

<body>

  <div class="container">
    <header id="main-header">
      <div class="row no-gutters">
        <div class="col-lg-4 col-md-5">
          <img src="../assets/image/person1.jpg" alt="Avatar">
        </div>
        <div class="col-lg-8 col-md-7">
          <div class="d-flex flex-column">
            <div class="p-5 bg-dark text-white">
              <div class="name d-flex flex-row justify-content-between align-items-center">
                <h1 class="display-4">John Doe</h1>
                <div><em class="fa fa-twitter"></em></div>
                <div><em class="fa fa-facebook"></em></div>
                <div><em class="fa fa-instagram"></em></div>
                <div><em class="fa fa-github"></em></div>
              </div>
            </div>

            <div class="p-4 bg-black">
              Experienced Full Stack Web Developer
            </div>

            <div class="d-flex flex-row text-white align-items-stretch text-center">
              <div class="port-item bg-primary" data-toggle="collapse" data-target="#home">
                <em class="fa fa-home d-block"></em> Home
              </div>
              <div class="port-item bg-success" data-toggle="collapse" data-target="#resume">
                <em class="fa fa-graduation-cap d-block"></em> Resume
              </div>
              <div class="port-item bg-warning" data-toggle="collapse" data-target="#work">
                <em class="fa fa-folder-open d-block"></em> Work
              </div>
              <div class="port-item bg-danger">
                <em class="fa fa-envelope d-block"></em> Contact
              </div>
            </div>

          </div>
        </div>
      </div>
    </header>

    <!-- Home -->
    <div id="home" class="collapse show">
      <div class="card card-body bg-primary text-white py-5">
        <h2>Welcome to my page</h2>
        <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed id fugiat repellendus illum vel
          minima. Blanditiis mollitia sit impedit error!</p>
      </div>

      <div class="card card-body py-5">
        <h3>My Skills</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti natus aliquam qui reprehenderit,
          cupiditate repellendus deserunt hic aspernatur voluptate quidem.</p>
        <hr>

        <h4>HTML</h4>
        <div class="progress mb-3">
          <div class="progress-bar bg-primary" style="width: 100%;"></div>
        </div>

        <h4>CSS</h4>
        <div class="progress mb-3">
          <div class="progress-bar bg-primary" style="width: 100%;"></div>
        </div>

        <h4>JavaScript</h4>
        <div class="progress mb-3">
          <div class="progress-bar bg-primary" style="width: 90%;"></div>
        </div>

        <h4>PHP</h4>
        <div class="progress mb-3">
          <div class="progress-bar bg-primary" style="width: 80%;"></div>
        </div>

        <h4>Python</h4>
        <div class="progress mb-3">
          <div class="progress-bar bg-primary" style="width: 70%;"></div>
        </div>
      </div>
    </div>

    <!-- Resume -->
    <div id="resume" class="collapse">
      <div class="card card-body bg-success text-white py-5">
        <h2>My Resume</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In, doloremque, dolores quasi blanditiis suscipit
          architecto numquam reprehenderit repudiandae consectetur sint provident officia, nemo totam similique.</p>
      </div>

      <div class="card card-body py-5">
        <h3>Where have I worked?</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A eveniet sapiente ducimus tempore modi fugiat
          autem, numquam sint soluta illum.</p>

        <div class="card-deck">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Devmasters</h4>
              <p class="card-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae hic a delectus quas fugiat dolorem
                provident placeat laborum magni doloribus!
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Position: Full Stack Developer
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Phone: (444) 444-4444
              </p>
            </div>
            <div class="card-footer">
              <h6 class="text-muted">Dates: 2015 - 2017</h6>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Websites Pro</h4>
              <p class="card-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae hic a delectus quas fugiat dolorem
                provident placeat laborum magni doloribus!
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Position: Front End Developer
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Phone: (333) 333-3333
              </p>
            </div>
            <div class="card-footer">
              <h6 class="text-muted">Dates: 2013 - 2015</h6>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <h4 class="card-title">123 Designs</h4>
              <p class="card-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae hic a delectus quas fugiat dolorem
                provident placeat laborum magni doloribus!
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Position: Designer
              </p>
              <p class="p-2 mb-3 bg-dark text-white">
                Phone: (222) 222-2222
              </p>
            </div>
            <div class="card-footer">
              <h6 class="text-muted">Dates: 2015 - 2017</h6>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Work -->
    <div id="work" class="collapse">
      <div class="card card-body bg-warning py-5">
        <h3>My Portfolio</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus tempore itaque, rerum dolor placeat asperiores, assumenda aspernatur perspiciatis, voluptate quos adipisci quae aperiam sed? Quidem!</p>
      </div>

      <div class="card card-body py-5">
        <h3>What have I built?</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vero, repudiandae!</p>
        <div class="row no-gutters">
          <div class="col-md-3">
            <a href="">
              <img src="" alt="">
            </a>
          </div>
          <div class="col-md-3"></div>
          <div class="col-md-3"></div>
          <div class="col-md-3"></div>
        </div>
      </div>
    </div>

    <!-- footer -->
    <footer id="main-footer" class="p-5 bg-dark text-white">
      <div class="row">
        <div class="col-md-6">
          <a href="#" class="btn btn-outline-light"><em class="fa fa-cloud"></em> Download Resume</a>
        </div>
      </div>
    </footer>
  </div>

  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/popper.min.js"></script>
  <script src="../assets/js/bootstrap.bundle.min.js"></script>
  <script>
    $('.port-item').click(function () {
      $('.collapse').collapse('hide');
    });
  </script>
  
</body>

</html>