<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/Mizuxe/style.css">
    <title>Mizuxe</title>
</head>

<body>

    <nav class="navbar navbar-expand-md navbar-light fixed-top py-4" aria-label="Navigation Bar">
        <div class="container">
            <a href="index.html" class="navbar-brand">
                <img src="../assets/image/Mizuxe/mlogo.png" alt="Brand Logo" class="navbar-brand-image" />
                <h3 class="d-inline align-middle">Mizuxe</h3>
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="#home" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#about" class="nav-link">About</a>
                    </li>
                    <li class="nav-item">
                        <a href="#authors" class="nav-link">Meet The Authors</a>
                    </li>
                    <li class="nav-item">
                        <a href="#contact" class="nav-link">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Showcase -->
    <section id="showcase" class="py-5">
        <div class="primary-overlay text-white">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 text-center">
                        <h1 class="display-2 mt-5 pt-5">So What You Dream Of...</h1>
                        <p class="lead">
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sed, illum?
                        </p>
                        <a href="#" class="btn btn-outline-secondary btn-lg text-white">
                            <em class="fa fa-arrow-right"></em> Read More
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <img src="../assets/image//Mizuxe/book.png" alt="Book" class="img-fluid d-none d-lg-block">
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Newsletter -->
    <section id="newsletter" class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" class="form-control form-control-lg no-radius" placeholder="Enter Name">
                </div>
                <div class="col-md-4">
                    <input type="text" class="form-control form-control-lg no-radius" placeholder="Enter Email">
                </div>
                <div class="col-md-4">
                    <button class="btn btn-primary btn-lg btn-block no-radius">
                        <em class="fa fa-envelope-open-o"></em> Subscribe
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Boxes -->

    <section id="boxes" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card text-center border-primary">
                        <div class="card-body">
                            <h3 class="text-primary">Be Better</h3>
                            <p class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo, nobis?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center bg-primary text-white">
                        <div class="card-body">
                            <h3>Be Smarter</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo, nobis?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center border-primary">
                        <div class="card-body">
                            <h3 class="text-primary">Be Faster</h3>
                            <p class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo, nobis?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center bg-primary text-white ">
                        <div class="card-body">
                            <h3>Be Stronger</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo, nobis?
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- About / Why Selection -->
    <section id="about" class="py-5 text-center bg-light">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="info-header mb-5">
                        <h1 class="text-primary pb-3">
                            Why This Book?
                        </h1>
                        <p class="lead pb-3">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem laboriosam soluta modi adipisci
                            reiciendis cupiditate.
                        </p>
                    </div>
                    <!-- Accordion -->
                    <div id="accordion" class="accordion" role="tablist">

                        <div class="card">
                            <div class="card-header" id="heading1">
                                <h5 class="mb-0">
                                    <div data-bs-toggle="collapse" data-bs-target="#collapse1" aria-expanded="true"
                                        aria-controls="collapse1">
                                        <em class="fa fa-arrow-circle-down"> Get Inspired</em>
                                    </div>
                                </h5>
                            </div>

                            <div id="collapse1" class="collapse show" aria-labelledby="heading1"
                                data-parent="#accordion">
                                <div class="card-body">
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet, perspiciatis
                                    dolorum. Voluptatem molestias accusantium quis, fugit iure doloribus veniam
                                    asperiores! Libero iure quod, iste inventore neque commodi esse earum praesentium
                                    quibusdam delectus dolorum? Asperiores possimus voluptatem atque et id fugit eos rem
                                    neque! Vero quidem dolorum nemo minus recusandae voluptates accusamus quia assumenda
                                    quod? Dolore, molestias dignissimos. Doloribus, dolores necessitatibus?
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading2">
                                <h5 class="mb-0">
                                    <div data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="true"
                                        aria-controls="collapse2">
                                        <em class="fa fa-arrow-circle-down"> Gain The Knowledge</em>
                                    </div>
                                </h5>
                            </div>

                            <div id="collapse2" class="collapse " aria-labelledby="heading2" data-parent="#accordion">
                                <div class="card-body">
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet, perspiciatis
                                    dolorum. Voluptatem molestias accusantium quis, fugit iure doloribus veniam
                                    asperiores! Libero iure quod, iste inventore neque commodi esse earum praesentium
                                    quibusdam delectus dolorum? Asperiores possimus voluptatem atque et id fugit eos rem
                                    neque! Vero quidem dolorum nemo minus recusandae voluptates accusamus quia assumenda
                                    quod? Dolore, molestias dignissimos. Doloribus, dolores necessitatibus?
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" id="heading3">
                                <h5 class="mb-0">
                                    <div data-bs-toggle="collapse" data-bs-target="#collapse3" aria-expanded="true"
                                        aria-controls="collapse3">
                                        <em class="fa fa-arrow-circle-down"> Open Your Mind</em>
                                    </div>
                                </h5>
                            </div>

                            <div id="collapse3" class="collapse " aria-labelledby="heading3" data-parent="#accordion">
                                <div class="card-body">
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet, perspiciatis
                                    dolorum. Voluptatem molestias accusantium quis, fugit iure doloribus veniam
                                    asperiores! Libero iure quod, iste inventore neque commodi esse earum praesentium
                                    quibusdam delectus dolorum? Asperiores possimus voluptatem atque et id fugit eos rem
                                    neque! Vero quidem dolorum nemo minus recusandae voluptates accusamus quia assumenda
                                    quod? Dolore, molestias dignissimos. Doloribus, dolores necessitatibus?
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Authors -->
    <section id="authors" class="my-5 text-center">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="info-header mb-5">
                        <h1 class="text-primary pb-3">
                            Meet The Authors
                        </h1>
                        <p class="lead pb-3">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem laboriosam soluta modi adipisci
                            reiciendis cupiditate.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <img src="../assets/image/Mizuxe/person1.jpg" alt="person 1" class="img-fluid rounded-circle w-50 mb-3">
                            <h3>Susan Williams</h3>
                            <h5 class="text-muted">Lead Writer</h5>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos, quis expedita
                                suscipit pariatur tempore corrupti!</p>
                            <div class="d-flex flex-row justify-content-center">
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-facebook"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-twitter"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-instagram"></em></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <img src="../assets/image/Mizuxe/person2.jpg" alt="person 2" class="img-fluid rounded-circle w-50 mb-3">
                            <h3>Grace Smith</h3>
                            <h5 class="text-muted">Co-Writer</h5>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos, quis expedita
                                suscipit pariatur tempore corrupti!</p>
                            <div class="d-flex flex-row justify-content-center">
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-facebook"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-twitter"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-instagram"></em></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <img src="../assets/image/Mizuxe/person3.jpg" alt="person 3" class="img-fluid rounded-circle w-50 mb-3">
                            <h3>John Doe</h3>
                            <h5 class="text-muted">Editor</h5>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos, quis expedita
                                suscipit pariatur tempore corrupti!</p>
                            <div class="d-flex flex-row justify-content-center">
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-facebook"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-twitter"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-instagram"></em></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <img src="../assets/image/Mizuxe/person4.jpg" alt="person 4" class="img-fluid rounded-circle w-50 mb-3">
                            <h3>Kevin Swanson</h3>
                            <h5 class="text-muted">Designer</h5>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos, quis expedita
                                suscipit pariatur tempore corrupti!</p>
                            <div class="d-flex flex-row justify-content-center">
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-facebook"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-twitter"></em></a>
                                </div>
                                <div class="p-4">
                                    <a href="#"><em class="fa fa-instagram"></em></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact -->
    <section id="contact" class="bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <h3>Get In Touch</h3>
                    <p class="lead">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quisquam, laudantium! Repudiandae eum commodi omnis modi.</p>
                    <form>
                        <div class="form-group">
                            <div class="input-group input-group-lg">
                                <span class="input-group-append input-group-text"><em class="fa fa-user"></em></span>
                                <input type="text" class="form-control" placeholder="Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group input-group-lg">
                                <span class="input-group-append input-group-text"><em class="fa fa-envelope"></em></span>
                                <input type="email" class="form-control" placeholder="Email">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group input-group-lg">
                                <span class="input-group-append input-group-text"><em class="fa fa-pencil"></em></span>
                                <textarea class="form-control" placeholder="Message" rows="5"></textarea>
                            </div>
                        </div>
                        <input type="submit" value="Submit" class="btn btn-block btn-primary btn-lg">
                    </form>
                </div>
                <div class="col-lg-3 align-self-center">
                    <img src="../assets/image/Mizuxe/mlogo.png" alt="" class="img-fluid ">
                </div>
            </div>
        </div>
    </section>

    <footer id="main-footer" class="py-5 bg-primary text-white">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-6 ml-auto">
                    <p class="lead">Copyright &copy; 2017</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/Mizuxe/navbar-fixed.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/navbar-fixed.js"></script>
    
</body>

</html>