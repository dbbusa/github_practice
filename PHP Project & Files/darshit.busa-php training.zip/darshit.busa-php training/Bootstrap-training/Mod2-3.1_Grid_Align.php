<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod2-prac">
            <div class="container bg-dark text-white p-3">
                <h2 class="h1 text-center text-warning">Grid Alignment</h2>
                <h3 class="text-center text-info">Grid System</h3>

                <div class="row bg-secondary my-2 p-3">
                    <div class="col">
                        Col-1
                    </div>
                    <div class="col">
                        Col-2
                    </div>
                </div>
                <div class="row bg-secondary my-2 p-3">
                    <div class="col">
                        Col-1
                    </div>
                    <div class="col">
                        Col-2
                    </div>
                    <div class="col">
                        Col-3
                    </div>
                </div>

                <h3 class="text-center text-info">Grid Alignment</h3>
                <div class="row my-2">
                    <div class="p-3 bg-success col">
                        Col-1
                    </div>
                    <div class="p-3 bg-primary col-6">
                        Col-2 of column 6
                    </div>
                    <div class="p-3 bg-success col">
                        Col-3
                    </div>
                </div>
                <div class="row my-2">
                    <div class="p-3 bg-primary col">
                        Col-1
                    </div>
                    <div class="p-3 bg-success col">
                        Col-2
                    </div>
                    <div class="p-3 bg-primary col-5">
                        Col-3 of column 5
                    </div>
                </div>

                <h3 class="text-center text-info">Grid Alignment</h3>
                <div class="row row-height border border-primary my-2 align-items-start">
                    <div class="col-md-8">Lorem ipsum dolor sit amet.</div>
                    <div class="col-6 col-md-4">Lorem ipsum dolor sit amet.</div>
                </div>

                <div class="row row-height border border-primary my-2 align-items-center">
                    <div class="col-6 col-md-4">Lorem ipsum dolor sit amet.</div>
                    <div class="col-6 col-md-4">Lorem ipsum dolor sit amet.</div>
                    <div class="col-6 col-md-4">Lorem ipsum dolor sit amet.</div>
                </div>

                <div class="row row-height border border-primary my-2 align-items-end">
                    <div class="col-6">Lorem ipsum dolor sit amet.</div>
                    <div class="col-6">Lorem ipsum dolor sit amet.</div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>