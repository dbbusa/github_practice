<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark">
            <div class="container p-3" id="content">
                <h2 class="h1 text-center text-warning">ListGroups & Badges</h2>


                <h4 class="text-center text-info">ListGroup</h4>
                <div class="row justify-content-center">

                    <div class="w-full">
                        <p class="text-white text-center"> Normal List Group</p>
                        <ul class="list-group">
                            <li class="list-group-item">Item 1</li>
                            <li class="list-group-item">Item 2</li>
                            <li class="list-group-item">Item 3</li>
                            <li class="list-group-item">Item 4</li>
                            <li class="list-group-item">Item 5</li>
                        </ul>
                    </div>

                    <div class="w-full">
                        <p class="text-white text-center">List With Action</p>
                        <div class="list-group">
                            <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                                Selected Item 1
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">Item 2</a>
                            <a href="#" class="list-group-item list-group-item-action">Item 3</a>
                            <a href="#" class="list-group-item list-group-item-action">Item 4</a>
                            <a href="#" class="list-group-item list-group-item-action disabled" tabindex="-1" aria-disabled="true">Item 5</a>
                        </div>
                    </div>

                    <div class="w-full">
                        <p class="text-white text-center">List Group With Flush</p>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Item 1</li>
                            <li class="list-group-item">Item 2</li>
                            <li class="list-group-item">Item 3</li>
                            <li class="list-group-item">Item 4</li>
                            <li class="list-group-item">Item 5</li>
                        </ul>
                    </div>

                    <div class="w-full">
                        <p class="text-white text-center">List Group With Badges</p>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Item 1
                                <span class="badge bg-secondary rounded-pill">9</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Item 2
                                <span class="badge bg-primary rounded-pill">6</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Item 3
                                <span class="badge bg-success rounded-pill">5</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Item 4
                                <span class="badge bg-info rounded-pill">8</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Item 5
                                <span class="badge bg-danger rounded-pill">1</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>