<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style-bootstrap-mod2-asg.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Resume - Darshit Busa</title>
</head>

<body class="text-white">
    <div class="row g-0 h-100">
        <div class="d-sm-none d-md-block fixed-start col-md-3 col-lg-3 bg-primary h-100">
            <div class="d-flex flex-column min-vh-100 justify-content-center">
                <div class="text-center">
                    <img src="../assets/image/avtar.jpg" alt="avtar" class="img-fluid border-image rounded-circle">
                </div>
                <nav class="nav d-block" aria-label="Navigation">
                    <a href="#home" class="nav-link text-white fw-bold text-center" title="About Me">About</a>
                    <a href="#education" class="nav-link text-white fw-bold text-center"
                        title="Education Details">Education </a>
                    <a href="#project" class="nav-link text-white fw-bold text-center"
                        title="Project Details">Project</a>
                    <a href="#skills" class="nav-link text-white fw-bold text-center" title="Skills & Interests">Skills
                        & Interests</a>
                </nav>
            </div>
        </div>
        <div class="d-sm-block d-md-none fixed-start z-index-100 col-sm-12 col-md-3 col-lg-3">
            <nav class="navbar navbar-expand-lg navbar-dark bg-primary" aria-label="navbar mobile">
                <div class="container-fluid border-bottom p-2">
                    <a class="navbar-brand" href="#"><strong>DB</strong></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="#home" class="nav-link text-white fw-bold text-center"
                                    title="About Me">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="#education" class="nav-link text-white fw-bold text-center"
                                    title="Education Details">Education </a>
                            </li>
                            <li class="nav-item">
                                <a href="#project" class="nav-link text-white fw-bold text-center"
                                    title="Project Details">Project</a>
                            </li>
                            <li class="nav-item">
                                <a href="#skills" class="nav-link text-white fw-bold text-center"
                                    title="Skills & Interests">Skills
                                    & Interests</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="d-md-block content col-md-9 col-lg-9 bg-dark p-4">
            <section class="row" id="home">
                <div class="d-flex flex-column min-vh-100 justify-content-center">
                    <h1 class="jumbotron fw-bold">Darshit <span class="text-primary">Busa</span></h1>
                    <p class="description">
                        <span class="fa fa-map-marker"></span> B-81, Shree Ram Park Society, Morbi Road, Rajkot, 360003
                        <span class="fa fa-mobile"></span> (+91)-851-188-1027
                        <span class="fa fa-envelope"></span> <span></span> <a href="mailto:darshitbusa8@gmail.com"
                            class="text-orange links text-decoration-none" target="_blank"> darshitbusa8@gmail.com </a>
                    </p>
                    <p class="mt-2 txt-sm">
                        To gain confidence and fame using my potential in the field of “Web Development”, and express my
                        innovative creative skills for self and company growth.
                    </p>
                    <div class="social-media">
                        <a class="badge rounded-circle bg-primary" href="#"><span class="fa fa-linkedin"></span></a>
                        <a class="badge rounded-circle bg-primary" href="#"><span class="fa fa-github"></span></a>
                        <a class="badge rounded-circle bg-primary" href="#"><span class="fa fa-facebook"></span></a>
                    </div>
                </div>
            </section>
            <section class="row" id="education">
                <div class="d-flex flex-column min-vh-100 justify-content-center">
                    <!-- SSC Details -->
                    <div class="border-start ps-3 border-primary mt-2 text-sm">
                        <h4 class="border-bottom border-primary">SSC <small
                                class="text-muted float-end text-small">2011-2016</small></h4>
                        <h5 class="no-my">Maruti Motherland School, Rajkot</h5>
                        <ul class="sub-disc">
                            <li>Achived Grade : 69.50%</li>
                        </ul>
                    </div>

                    <!-- Diploma Details -->
                    <div class="border-start ps-3 border-primary mt-2 text-sm">
                        <h4 class="border-bottom  border-primary">Diploma in Computer Engineering<small
                                class="text-muted float-end text-small">2016-2019</small></h4>
                        <h5 class="no-my">RK University, Rajkot</h5>
                        <ul class="sub-disc">
                            <li>Achived Grade : 8.84 CGPA</li>
                        </ul>
                    </div>

                    <!-- Bachelor Degree Details -->
                    <div class="border-start ps-3 border-danger mt-2 text-sm">
                        <h4 class="border-bottom  border-danger">Bachelor of Technology <small
                                class="text-muted float-end text-small">2019-Present</small></h4>
                        <h5 class="no-my">RK University, Rajkot</h5>
                        <ul class="sub-disc">
                            <li>Computer Engineering</li>
                            <li>Achived Grade : 8.77 CGPA</li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="row" id="project">
                <div class="d-flex flex-column min-vh-100 justify-content-center">
                    <!-- Project 1 -->
                    <div class="border-start border-primary ps-3 mt-3">
                        <h4 class="border-bottom border-primary">The NorthStar Nest <small
                                class="text-muted float-end text-small">2021</small></h4>
                        <h6 class="no-my">Web Design (Slim - Twing)</h6>
                        <ul class="sub-disc">
                            <li>Simple, Attractive and informative website built with Twing Template Engin and php slim
                                framework for "The Northstar Nest"</li>
                        </ul>
                    </div>

                    <!-- Project 2 -->
                    <div class="border-start border-warning ps-3 mt-4">
                        <h4 class="border-bottom border-warning">ETUs - URL Shortner <small
                                class="text-muted float-end text-small">2021</small></h4>
                        <h6 class="no-my">Web Application (Laravel Framework)</h6>
                        <ul class="sub-disc">
                            <li>Convert your irritating long URLs to short URL with existing features.</li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="row" id="skills">
                <div class="d-flex flex-column min-vh-100 justify-content-center">
                    <div class="row">

                        <div class="col-sm-12 col-md-5 col-lg-5">
                            <div class="skill">
                                <h4 class="border-bottom border-success">Skills</h4>
                                <ul>
                                    <li>PHP</li>
                                    <li>Android</li>
                                    <li>Laravel</li>
                                    <li>JS | HTML | CSS</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5 col-lg-5">
                            <div class="skill">
                                <h4 class="border-bottom border-primary">Hobbies</h4>
                                <ul>
                                    <li>Listening Music</li>
                                    <li>Learning</li>
                                    <li>Movie</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script>
        const navLinks = document.querySelectorAll('.nav-item')
        const menuToggle = document.getElementById('navbarNav')
        const bsCollapse = new bootstrap.Collapse(menuToggle,{toggle:false})
        navLinks.forEach((l) => {
            l.addEventListener('click', () => { bsCollapse.toggle() })
        })
    </script>
</body>

</html>