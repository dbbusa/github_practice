<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-secondary">
            <div class="container">
                <h2 class="h1 text-center text-warning">Input Groups</h2>


                <div class="row mt-5">
                    <div class="mx-auto col-sm-12 col-md-6 col-lg-6">
                        <div class="mb-3">
                            <div class="input-group">
                                <label for="email" class="input-group-text">@</label>
                                <input type="email" class="form-control" id="email" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" rows="3" placeholder="Enter Description"></textarea>
                        </div>
                        <div class="mb-3">
                            <div class="input-group">
                                <label for="exampleDataList" class="input-group-text">Datalist</label>
                                <input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="Type to search...">
                                <datalist id="datalistOptions">
                                    <option value="San Francisco"></option>
                                    <option value="New York"></option>
                                    <option value="Seattle"></option>
                                    <option value="Los Angeles"></option>
                                    <option value="Chicago"> </option>
                                </datalist>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="fileInput">Click Here</label>
                                <input type="file" class="form-control" id="fileInput">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>