<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod2-prac bg-dark p-2">
            <div class="container">
                <h2 class="h1 text-center text-warning">Modals</h2>

                <div class="row mt-4">
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Open Modal
                        </button>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Open Static Modal
                        </button>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#centerModal">
                            Open Center Modal
                        </button>
                    </div>
                </div>

                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Lorem, ipsum dolor.</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugit, mollitia placeat eveniet ad
                                beatae, aliquam qui modi et illo voluptas id laudantium delectus? Voluptate atque eius
                                accusantium provident dolorem similique.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Lorem, ipsum dolor.</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fuga impedit harum labore est.
                                Blanditiis laborum, quos maiores obcaecati debitis eveniet, dicta praesentium vel, asperiores
                                omnis ratione autem delectus voluptatibus a.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="centerModal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="centerModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Lorem, ipsum dolor.</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fuga impedit harum labore est.
                                Blanditiis laborum, quos maiores obcaecati debitis eveniet, dicta praesentium vel, asperiores
                                omnis ratione autem delectus voluptatibus a.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>