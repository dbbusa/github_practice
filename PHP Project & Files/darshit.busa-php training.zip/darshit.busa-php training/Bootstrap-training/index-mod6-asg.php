<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="../assets/image/goibibo/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Goibibo - Best Travel Website. Book Hotels, Flights, Trains, Bus and Cabs with upto 50% off</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/style-bootstrap-mod6.css">
</head>

<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light shadow bg-white" aria-label="Navigation Bar">
        <div class="container-fluid">
            <a class="navbar-brand text-end me-3 ps-5" href="#">
                <img src="../assets/image/goibibo/logo.png" alt="Goibibo" class="img-fluid w-100">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav my-navbar d-sm-flex flex-row flex-wrap justify-content-sm-center">
                    <li class="nav-item nav-item-border active">
                        <a class="nav-link nav-pill" aria-current="page" href="#"> <em class="fa fa-plane">&nbsp; </em> Flights
                        </a>
                    </li>
                    <li class="nav-item nav-item-border">
                        <a class="nav-link nav-pill" aria-current="page" href="#"> <em class="fa fa-hotel">&nbsp; </em> Hotel
                        </a>
                    </li>
                    <li class="nav-item nav-item-border">
                        <a class="nav-link nav-pill" aria-current="page" href="#"> <em class="fa fa-train">&nbsp; </em> Trains
                        </a>
                    </li>
                    <li class="nav-item nav-item-border">
                        <a class="nav-link nav-pill" aria-current="page" href="#"> <em class="fa fa-cab">&nbsp; </em> Cabs
                        </a>
                    </li>
                    <li class="nav-item nav-item-border">
                        <a class="nav-link nav-pill" aria-current="page" href="#"> <em class="fa fa-bus">&nbsp; </em> Bus
                        </a>
                    </li>
                </ul>

                <div class="d-flex flex-row-reverse ms-auto align-items-center justify-content-sm-center mt-sm-2">
                    <div class="col-lg-6 col-sm-3 ms-2">
                        <a href="#" class="text-no-underline text-no-underline">
                            <div class="d-flex flex-row align-items-center btn-auth-primary">
                                <img src="../assets/image/goibibo/user.png" alt="User Icon" class="icon-img-user">
                                <span class="btn-auth-text">Login OR Signup</span>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-4 col-sm-2 me-2 line-height-1">
                        <div class="d-flex flex-row align-items-center" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-placement="bottom" data-bs-content="<div class='popover-trip'><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia</p></div>">
                            <em class="text-muted fa fa-suitcase fs-3"></em>
                            <div class="ms-2">
                                <small class="d-block text-header-end">
                                    Manage Booking
                                </small>
                                <span class="text-header-span text-muted">My Trips</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </nav>

    <div class="new-background">
        <div class="container">
            <h1 class="h4 text-white text-center fw-bold py-4">Domestic and International Flights</h1>

            <div class="card card-shadow position-relative card-body border-radius-20 p-4">
                <div class="row">
                    <div class="col-12">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                            <label class="form-check-label fw-bold text-muted" for="exampleRadios1">
                                One-way
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                            <label class="form-check-label fw-bold text-muted" for="exampleRadios2">
                                Round-trip
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3">
                            <label class="form-check-label fw-bold text-muted" for="exampleRadios3">
                                Multi-city
                            </label>
                        </div>
                    </div>
                </div>
                <form action="">
                    <div class="row mt-4">
                        <div class="col-sm-12 col-md-3 col-lg-3">
                            <div class="custom-input border border-2 border-secondary-custom border-radius-5 position-relative p-4">
                                <input type="text" class="input-field" placeholder="Enter city or airport">
                                <span class="position-absolute top-min-3 start-30 translate-middle badge rounded-pill bg-badge-white">
                                    From
                                    <span class="visually-hidden">From</span>
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-3 col-lg-3 g-sm-0">
                            <div class="custom-input border border-2 border-secondary-custom border-radius-5 position-relative p-4">
                                <input type="text" class="input-field" placeholder="Enter city or airport">
                                <span class="position-absolute top-min-3 start-30 translate-middle badge rounded-pill bg-badge-white">
                                    To
                                    <span class="visually-hidden">To</span>
                                </span>
                                <span class="position-absolute shadow d-none d-md-block top-50 end-90 translate-middle badge border-radius-5 bg-badge-white p-2">
                                    <img src="../assets/image/goibibo/swap_arrows.svg" alt="">
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-3 col-lg-3">
                            <div class="row">
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <div class="custom-input border border-2 border-secondary-custom border-radius-5 position-relative p-4">
                                        <input type="date" class="input-field">
                                        <span class="position-absolute top-min-3 start-30 translate-middle badge rounded-pill bg-badge-white">
                                            Departure
                                            <span class="visually-hidden">Departure</span>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-6 g-sm-0">
                                    <div class="custom-input line-height-1 border border-2 border-secondary-custom border-radius-5 position-relative p-4">
                                        <input type="date" class="input-field">
                                        <span class="position-absolute top-min-3 start-30 translate-middle badge rounded-pill bg-badge-white">
                                            Return
                                            <span class="visually-hidden">Return</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-3 col-lg-3">
                            <div class="custom-input border border-2 border-secondary-custom border-radius-5 position-relative p-4">

                                <p class="text-black fw-bold no-line-margin">1 Adult </p>
                                <small class="fs-10x text-muted">Economy</small>

                                <span class="position-absolute top-min-3 start-50 translate-middle badge rounded-pill bg-badge-white">
                                    Travellers & Class
                                    <span class="visually-hidden">Travellers & Class</span>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4 mb-4">
                        <div class="col-sm-12 col-md-8 col-lg-7">
                            <div class="d-flex flex-row align-items-center">
                                <div class="text-muted line-height-1 fs-12x">
                                    Select A<br />Fare Type:
                                </div>
                                <div>
                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                        <span class="btn btn-secondary bg-light-gray">
                                            <input type="radio" checked>
                                            <label class="" for="btnradio1">Regular</label>
                                        </span>

                                        <span class="btn btn-secondary bg-light-gray">
                                            <input type="radio">
                                            <label class="" for="btnradio1">Armed Forces</label>
                                        </span>

                                        <span class="btn btn-secondary bg-light-gray">
                                            <input type="radio">
                                            <label class="" for="btnradio1">Senior Citizen</label>
                                        </span>

                                        <span class="btn btn-secondary bg-light-gray">
                                            <input type="radio">
                                            <label class="" for="btnradio1">Student</label>
                                        </span>

                                        <span class="btn btn-secondary bg-light-gray">
                                            <input type="radio">
                                            <label class="" for="btnradio1">Extra Seat</label>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5 col-lg-5">
                            <div class="d-flex flex-row align-items-center justify-content-end">
                                <span class="vertical-bar"></span>
                                <div class="text-muted line-height-1 fs-12x">
                                    Trending<br /> Search:
                                </div>
                                <div>
                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                        <span class="btn btn-block bg-light-gray1">
                                            <label class="">Bengaluru</label>
                                            <label class=""><span class="fa fa-arrow-right text-primary"></span></label>
                                        <label class="">Mumbai</label>
                                        </span>

                                        <span class="btn btn-block bg-light-gray1">
                                            <label class="">Delhi</label>
                                            <label class=""><span class="fa fa-arrow-right text-primary"></span></label>
                                        <label class="">Goa</label>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="position-absolute top-100 start-50pr translate-middle">
                        <button class="btn btn-orange text-uppercase rounded-pill">Search Flights</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Ads Section -->
        <div class="row mt-5 p-5">
            <a href="#">
                <img src="../assets/image/goibibo/970x90.jpg" alt="Ads" class="img-fluid">
            </a>
        </div>

        <!-- Offer section  -->
        <div class="card card-shadow border-radius-20">
            <div class="card-header">
                <h5 class="text-center margin-bottom-4 align-items-end"><span class="border-3 border-primary border-bottom text-primary">Offers</span></h5>
            </div>
            <div class="card-body p-4">
                <h4 class="text-center">Flight offers for you</h4>

                <!-- Card Slider -->

                <div class="row">

                    <div class="col-1 align-self-center">
                        <span class="fa fa-angle-left fa-2x border-primary text-primary border border-1 rounded-circle p-2-3"></span>
                    </div>
                    <div class="col-10">
                        <div class="row justify-content-center mt-3">
                            <!-- Card 1 -->
                            <div class="col-4">
                                <div class="card shadow-card-offer">
                                    <img src="../assets/image/goibibo/offers-1.jpg" class="border-top-radius" alt="Offers 1">
                                    <div class="card-body">
                                        <p class="card-text mb-0 fs-14x">New Routes Open: Varanasi - Dehradun</p>
                                        <p class="card-text fs-14x d-inline align-self-center"><small class="text-muted">Valid
                                                till:OPEN</small> <span class="fa fa-angle-right text-primary float-end fa-2x"></span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Card 2 -->
                            <div class="col-4">
                                <div class="card shadow-card-offer">
                                    <img src="../assets/image/goibibo/offers-2.jpg" class="border-top-radius" alt="Offers 2">
                                    <div class="card-body">
                                        <p class="card-text mb-0 fs-14x">New Routes Open: Pune - Sharjah</p>
                                        <p class="card-text fs-14x d-inline align-self-center"><small class="text-muted">Valid
                                                till:OPEN</small> <span class="fa fa-angle-right text-primary float-end fa-2x"></span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Card 3 -->
                            <div class="col-4">
                                <div class="card shadow-card-offer">
                                    <img src="../assets/image/goibibo/offers-3.jpg" class="border-top-radius" alt="Offers 3">
                                    <div class="card-body">
                                        <p class="card-text fs-14x mb-no">New Routes Open: Tirupati - Mumbai</p>
                                        <p class="card-text fs-14x d-inline align-self-center"><small class="text-muted">Valid
                                                till:OPEN</small> <span class="fa fa-angle-right text-primary float-end fa-2x"></span></p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-1 align-self-center">
                        <span class="fa fa-angle-right fa-2x border border-primary text-primary border-1 rounded-circle p-2-3"></span>
                    </div>
                </div>

                <!-- Button -->
                <div class="row justify-content-center mt-4">
                    <button class="btn btn-orange-2 text-uppercase btn-sm w-auto">Explore All Offers</button>
                </div>
            </div>
        </div>

        <!-- Important Notice -->
        <div class="row mt-5 p-0">
            <a href="#">
                <img src="../assets/image/goibibo/gosafeHome.png" alt="Go Safe Home" class="img-fluid border-radius-8">
            </a>
        </div>
    </div>


    <div class="bg-blue-gradient mt-5 py-2">
        <div class="container pt-3">
            <h4 class="h4 text-white text-center padding-TB-10 font-24px">What's new on Goibibo Flights?</h4>
            <p class="text-white text-center font-16px line-height-1">See why India loves to book flights with us</p>
            <!-- Card Slider -->

            <div class="row mt-5 mb-3">
                <div class="col-1 align-self-center">
                    <span class="fa fa-angle-left fa-2x border-light text-light border border-1 rounded-circle p-2-3"></span>
                </div>
                <div class="col-10">
                    <div class="row justify-content-center mt-3">
                        <!-- Card 1 -->
                        <div class="col-4 scale-0-9">
                            <div class="card card-new shadow-card-offer">
                                <h2 class="text-center d-inline-block font-18px blue-gray pb-3 fw-bold">Multi City
                                </h2>
                                <div class="position-relative">
                                    <img src="../assets/image/goibibo/temp1.png" class="img-fluid img-new-box border-top-radius" alt="Multi City">
                                    <div class="new-image-text text-center">
                                        <strong class="font-13px text-light">Multi City</strong>
                                        <p class="line-height-1 p-tb-5 font-11px text-light">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate, consectetur adipisicing Voluptate, laboriosam.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Card 2 -->
                        <div class="col-4 scale-1-1">
                            <div class="card card-new shadow-card-offer">
                                <h2 class="text-center d-inline-block font-18px blue-gray pb-3 fw-bold">Multi Airlines
                                </h2>
                                <div class="position-relative">
                                    <img src="../assets/image/goibibo/temp2.png" class="img-fluid img-new-box border-top-radius" alt="Multi Airlines">
                                    <div class="new-image-text text-center">
                                        <strong class="font-13px text-light">Multi Airlines</strong>
                                        <p class="line-height-1 p-tb-5 font-11px text-light">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate, consectetur adipisicing Voluptate, laboriosam.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Card 3 -->
                        <div class="col-4 scale-0-9">
                            <div class="card card-new shadow-card-offer">
                                <h2 class="text-center d-inline-block font-18px blue-gray pb-3 fw-bold">Nearby Airports
                                </h2>
                                <div class="position-relative">
                                    <img src="../assets/image/goibibo/temp3.png" class="img-fluid img-new-box border-top-radius" alt="Nearby Airports">
                                    <div class="new-image-text text-center">
                                        <strong class="font-13px text-light">Nearby Airports</strong>
                                        <p class="line-height-1 p-tb-5 font-11px text-light">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate, consectetur adipisicing Voluptate, laboriosam.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-1 align-self-center">
                    <span class="fa fa-angle-right fa-2x border border-light text-light border-1 rounded-circle p-2-3"></span>
                </div>
            </div>

            <div class="row mt-5 justify-content-center mb-3">
                <button class="btn btn-orange-2 border-radius-8 text-uppercase btn-sm w-auto py-2 px-4"> View All
                    Products</button>
            </div>

        </div>
    </div>
    <div class="bg-white">
        <div class="container">
            <div class="row  p-3">
                <div class="col-sm-6 col-md-3 col-lg-3">
                    <strong class="text-uppercase mb-6px"><small>our products</small></strong>
                    <ul class="footer-link">
                        <li> Domestic Hotels </li>
                        <li> International Hotels </li>
                        <li> Domestic Flights </li>
                        <li> International Flights </li>
                        <li> Multi-City Flights </li>
                        <li> Couple Friendly Hotels </li>
                        <li> Nearby Getaways </li>
                        <li> Bus Booking </li>
                        <li> Cab Booking </li>
                        <li> Airport Cabs Booking </li>
                        <li> Outstation Cabs Booking </li>
                        <li> Train Booking </li>
                        <li> Go Stays </li>
                        <li> Trip Money </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                    <strong class="text-uppercase mb-6px"><small>more links</small></strong>
                    <ul class="footer-link">
                        <li>Cheap Flights </li>
                        <li>Hotels Near Me </li>
                        <li>My Bookings </li>
                        <li>Cancellation </li>
                        <li>My Account </li>
                        <li>Wallet </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                    <strong class="text-uppercase mb-6px"><small>About Us</small></strong>
                    <ul class="footer-link">
                        <li> About Us </li>
                        <li> Investor Relations </li>
                        <li> Management </li>
                        <li> Terms of Services </li>
                        <li> User Agreement </li>
                        <li> Privacy </li>
                        <li> Careers </li>
                        <li> YouTube Channel </li>
                        <li> Technology@Goibibo </li>
                        <li> Customer Support </li>
                        <li> Facebook Page </li>
                        <li> Twitter Handle </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                    <strong class="text-uppercase mb-6px"><small>travel essentials</small></strong>
                    <ul class="footer-link">
                        <li> PNR Status </li>
                        <li> Offers </li>
                        <li> Airline Routes </li>
                        <li> Train Running Status </li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row d-inline-block">
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Popular Flight Sectors</small></strong></li>
                    <li><a href="#">Kolkata to Delhi Flight |</a></li>
                    <li><a href="#">Hyderabad to Delhi Flight |</a></li>
                    <li><a href="#">Chennai to Hyderabad Flight |</a></li>
                    <li><a href="#">Delhi to Guwahati Flight |</a></li>
                    <li><a href="#">Lucknow to Delhi Flight |</a></li>
                    <li><a href="#">Nagpur to Mumbai Flight |</a></li>
                    <li><a href="#">Ranchi to Delhi Flight |</a></li>
                    <li><a href="#">Ahmedabad to Goa Flight |</a></li>
                    <li><a href="#">Mumbai to Chandigarh Flight |</a></li>
                    <li><a href="#">Pune to Kolkata Flight |</a></li>
                    <li><a href="#">Bangalore to Bhubaneshwar Flight |</a></li>
                    <li><a href="#">Bangalore to Guwahati Flight |</a></li>
                    <li><a href="#">Chennai to Goa Flight |</a></li>
                    <li><a href="#">Chennai to Kolkata Flight |</a></li>
                    <li><a href="#">Delhi to Jaipur Flight |</a></li>
                    <li><a href="#">Delhi to Leh Flight |</a></li>
                    <li><a href="#">Hyderabad to Goa Flight |</a></li>
                    <li><a href="#">Bangalore to Ranchi Flight |</a></li>
                    <li><a href="#">Delhi to Bagdogra Flight |</a></li>
                    <li><a href="#">Srinagar to Delhi Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Top Routes </small></strong></li>
                    <li><a href="#">Chandigarh to Delhi Flight |</a></li>
                    <li><a href="#">Delhi to Bhopal Flight |</a></li>
                    <li><a href="#">Delhi to Dehradun Flight |</a></li>
                    <li><a href="#">Delhi to Udaipur Flight |</a></li>
                    <li><a href="#">Hyderabad to Tirupati Flight |</a></li>
                    <li><a href="#">Kolkata to Chennai Flight |</a></li>
                    <li><a href="#">Kolkata to Guwahati Flight |</a></li>
                    <li><a href="#">Mumbai to Amritsar Flight |</a></li>
                    <li><a href="#">Mumbai to Dehradun Flight |</a></li>
                    <li><a href="#">Indore to Goa Flight |</a></li>
                    <li><a href="#">Jaipur to Delhi Flight |</a></li>
                    <li><a href="#">Kolkata to Bagdogra Flight |</a></li>
                    <li><a href="#">Patna to Bangalore Flight |</a></li>
                    <li><a href="#">Varanasi to Delhi Flight |</a></li>
                    <li><a href="#">Ahmedabad to Kolkata Flight |</a></li>
                    <li><a href="#">Delhi to Gorakhpur Flight |</a></li>
                    <li><a href="#">Guwahati to Kolkata Flight |</a></li>
                    <li><a href="#">Indore to Bangalore Flight |</a></li>
                    <li><a href="#">Jaipur to Pune Flight |</a></li>
                    <li><a href="#">Mumbai to Raipur Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Popular Domestic Routes </small></strong></li>
                    <li><a href="#">Patna to Kolkata Flight |</a></li>
                    <li><a href="#">Ranchi to Bangalore Flight |</a></li>
                    <li><a href="#">Patna to Delhi Flight |</a></li>
                    <li><a href="#">Bangalore to Goa Flight |</a></li>
                    <li><a href="#">Delhi to Ranchi Flight |</a></li>
                    <li><a href="#">Pune to Nagpur Flight |</a></li>
                    <li><a href="#">Chennai to Coimbatore Flight |</a></li>
                    <li><a href="#">Delhi to Srinagar Flight |</a></li>
                    <li><a href="#">Goa to Mumbai Flight |</a></li>
                    <li><a href="#">Hyderabad to Bangalore Flight |</a></li>
                    <li><a href="#">Indore to Delhi Flight |</a></li>
                    <li><a href="#">Kolkata to Mumbai Flight |</a></li>
                    <li><a href="#">Mumbai to Nagpur Flight |</a></li>
                    <li><a href="#">Mumbai to Varanasi Flight |</a></li>
                    <li><a href="#">Pune to Goa Flight |</a></li>
                    <li><a href="#">Bangalore to Chennai Flight |</a></li>
                    <li><a href="#">Bangalore to Jaipur Flight |</a></li>
                    <li><a href="#">Chennai to Bangalore Flight |</a></li>
                    <li><a href="#">Chennai to Madurai Flight |</a></li>
                    <li><a href="#">Delhi to Indore Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Top Sectors</small></strong></li>
                    <li><a href="#">Delhi to Jammu Flight |</a></li>
                    <li><a href="#">Delhi to Varanasi Flight |</a></li>
                    <li><a href="#">Hyderabad to Chennai Flight |</a></li>
                    <li><a href="#">Hyderabad to Mumbai Flight |</a></li>
                    <li><a href="#">Jaipur to Mumbai Flight |</a></li>
                    <li><a href="#">Bangalore to Srinagar Flight |</a></li>
                    <li><a href="#">Bhopal to Chennai Flight |</a></li>
                    <li><a href="#">Chandigarh to Mumbai Flight |</a></li>
                    <li><a href="#">Coimbatore to Ahmedabad Flight |</a></li>
                    <li><a href="#">Coimbatore to Bangalore Flight |</a></li>
                    <li><a href="#">Coimbatore to Mumbai Flight |</a></li>
                    <li><a href="#">Delhi to Chandigarh Flight |</a></li>
                    <li><a href="#">Delhi to Coimbatore Flight |</a></li>
                    <li><a href="#">Delhi to Raipur Flight |</a></li>
                    <li><a href="#">Hyderabad to Kolkata Flight |</a></li>
                    <li><a href="#">Hyderabad to Vijaywada Flight |</a></li>
                    <li><a href="#">Lucknow to Ahmedabad Flight |</a></li>
                    <li><a href="#">Madurai to Chennai Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Important Routes </small></strong></li>
                    <li><a href="#">Madurai to Hyderabad Flight |</a></li>
                    <li><a href="#">Mumbai to Srinagar Flight |</a></li>
                    <li><a href="#">Pune to Ranchi Flight |</a></li>
                    <li><a href="#">Raipur to Hyderabad Flight |</a></li>
                    <li><a href="#">Raipur to Mumbai Flight |</a></li>
                    <li><a href="#">Bhopal to Hyderabad Flight |</a></li>
                    <li><a href="#">Bhubaneshwar to Chennai Flight |</a></li>
                    <li><a href="#">Chennai to Nagpur Flight |</a></li>
                    <li><a href="#">Chennai to Port Blair Flight |</a></li>
                    <li><a href="#">Cochin to Chennai Flight |</a></li>
                    <li><a href="#">Delhi to Mangalore Flight |</a></li>
                    <li><a href="#">Hyderabad to Nagpur Flight |</a></li>
                    <li><a href="#">Jammu to Delhi Flight |</a></li>
                    <li><a href="#">Kolkata to Aizawl Flight |</a></li>
                    <li><a href="#">Lucknow to Hyderabad Flight |</a></li>
                    <li><a href="#">Udaipur to Delhi Flight |</a></li>
                    <li><a href="#">Agartala to Delhi Flight |</a></li>
                    <li><a href="#">Bangalore to Imphal Flight |</a></li>
                    <li><a href="#">Imphal to Guwahati Flight |</a></li>
                    <li><a href="#">Imphal to Kolkata Flight |</a></li>
                    <li><a href="#">Indore to Raipur Flight |</a></li>
                    <li><a href="#">Kozhikode to Chennai Flight |</a></li>
                    <li><a href="#">Mumbai to Imphal Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Trending Domestic Routes </small></strong></li>
                    <li><a href="#">Ahmedabad to Mumbai Flight |</a></li>
                    <li><a href="#">Bagdogra to Kolkata Flight |</a></li>
                    <li><a href="#">Bangalore to Udaipur Flight |</a></li>
                    <li><a href="#">Bhopal to Bangalore Flight |</a></li>
                    <li><a href="#">Bhubaneshwar to Mumbai Flight |</a></li>
                    <li><a href="#">Chandigarh to Chennai Flight |</a></li>
                    <li><a href="#">Chennai to Jaipur Flight |</a></li>
                    <li><a href="#">Delhi to Vadodara Flight |</a></li>
                    <li><a href="#">Goa to Pune Flight |</a></li>
                    <li><a href="#">Hyderabad to Coimbatore Flight |</a></li>
                    <li><a href="#">Hyderabad to Patna Flight |</a></li>
                    <li><a href="#">Jaipur to Bangalore Flight |</a></li>
                    <li><a href="#">Lucknow to Kolkata Flight |</a></li>
                    <li><a href="#">Mangalore to Bangalore Flight |</a></li>
                    <li><a href="#">Mumbai to Coimbatore Flight |</a></li>
                    <li><a href="#">Mumbai to Indore Flight |</a></li>
                    <li><a href="#">Mumbai to Rajkot Flight |</a></li>
                    <li><a href="#">Mumbai to Surat Flight |</a></li>
                    <li><a href="#">Mumbai to Vijaywada Flight |</a></li>
                    <li><a href="#">Pune to Chennai Flight |</a></li>
                    <li><a href="#">Bhubaneshwar to Kolkata Flight |</a></li>
                    <li><a href="#">Delhi to Kozhikode Flight |</a></li>
                    <li><a href="#">Mumbai to Jodhpur Flight |</a></li>
                    <li><a href="#">Ranchi to Mumbai Flight |</a></li>
                    <li><a href="#">Vadodara to Chennai Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>New Udaan Sectors </small></strong></li>
                    <li><a href="#">Guwahati to Rupsi Flight |</a></li>
                    <li><a href="#">Rupsi to Kolkata Flight |</a></li>
                    <li><a href="#">Guwahati to Agartala Flight |</a></li>
                    <li><a href="#">Agartala to Dibrugarh Flight |</a></li>
                    <li><a href="#">Dibrugarh to Agartala Flight |</a></li>
                    <li><a href="#">Agartala to Guwahati Flight |</a></li>
                    <li><a href="#">Guwahati to Pasighat Flight |</a></li>
                    <li><a href="#">Pasighat to Shillong Flight |</a></li>
                    <li><a href="#">Shillong to Pasighat Flight |</a></li>
                    <li><a href="#">Pasighat to Guwahati Flight</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Trending Hotel Cities </small></strong></li>
                    <li><a href="#">Hotels in Goa |</a></li>
                    <li><a href="#">Hotels in Delhi |</a></li>
                    <li><a href="#">Hotels in Mumbai |</a></li>
                    <li><a href="#">Hotels in Bangalore |</a></li>
                    <li><a href="#">Hotels in Shimla |</a></li>
                    <li><a href="#">Hotels in Jaipur |</a></li>
                    <li><a href="#">Hotels in Manali |</a></li>
                    <li><a href="#">Hotels in Puri |</a></li>
                    <li><a href="#">Hotels in Mussoorie |</a></li>
                    <li><a href="#">Hotels in Hyderabad |</a></li>
                    <li><a href="#">Hotels in Udaipur |</a></li>
                    <li><a href="#">Hotels in Kolkata |</a></li>
                    <li><a href="#">Hotels in Mahabaleshwar |</a></li>
                    <li><a href="#">Hotels in Pune |</a></li>
                    <li><a href="#">Hotels in Mount Abu |</a></li>
                    <li><a href="#">Hotels in Chennai |</a></li>
                    <li><a href="#">Hotels in Lonavala |</a></li>
                    <li><a href="#">Hotels in Tirupati |</a></li>
                    <li><a href="#">Hotels in Ooty |</a></li>
                    <li><a href="#">Hotels in Alibag |</a></li>
                    <li><a href="#">Hotels in Digha |</a></li>
                    <li><a href="#">Hotels in Shirdi |</a></li>
                    <li><a href="#">Hotels in Lucknow |</a></li>
                    <li><a href="#">Hotels in Pondicherry |</a></li>
                    <li><a href="#">Hotels in Nainital</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Trending Resort Cities </small></strong></li>
                    <li><a href="#">Resorts in Bangalore |</a></li>
                    <li><a href="#">Resorts in Goa |</a></li>
                    <li><a href="#">Resorts in Lonavala |</a></li>
                    <li><a href="#">Resorts in Hyderabad |</a></li>
                    <li><a href="#">Resorts in Chennai |</a></li>
                    <li><a href="#">Resorts in Mumbai |</a></li>
                    <li><a href="#">Resorts in Wayanad |</a></li>
                    <li><a href="#">Resorts in Alibag |</a></li>
                    <li><a href="#">Resorts in Coorg |</a></li>
                    <li><a href="#">Resorts in Munnar</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Book Alternative Accommodation </small></strong></li>
                    <li><a href="#">Houseboats in Alleppey |</a></li>
                    <li><a href="#">Villas in Lonavala |</a></li>
                    <li><a href="#">Villas in Goa |</a></li>
                    <li><a href="#">Villas in Alibag |</a></li>
                    <li><a href="#">Hostels in Goa |</a></li>
                    <li><a href="#">Service Apartments In Goa |</a></li>
                    <li><a href="#">Tents in Rishikesh |</a></li>
                    <li><a href="#">Villas in Mumbai |</a></li>
                    <li><a href="#">Cottages in Alibag |</a></li>
                    <li><a href="#">Homestays in Chikmagalur |</a></li>
                    <li><a href="#">Houseboats in Srinagar |</a></li>
                    <li><a href="#">Villas in Igatpuri |</a></li>
                    <li><a href="#">Beach Huts In Goa |</a></li>
                    <li><a href="#">Guest Houses In Varanasi |</a></li>
                    <li><a href="#">Homestays in Coorg |</a></li>
                    <li><a href="#">Cottages in Goa |</a></li>
                    <li><a href="#">Tents in Jaisalmer |</a></li>
                    <li><a href="#">Hostels in Delhi |</a></li>
                    <li><a href="#">Guest Houses In Delhi |</a></li>
                    <li><a href="#">Hostels in Hyderabad</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Trending International Hotel Cities </small></strong></li>
                    <li><a href="#">Hotels in Dubai |</a></li>
                    <li><a href="#">Hotels in Maldives |</a></li>
                    <li><a href="#">Hotels in Singapore |</a></li>
                    <li><a href="#">Hotels in Bali |</a></li>
                    <li><a href="#">Hotels in bangkok |</a></li>
                    <li><a href="#">Hotels in pattaya |</a></li>
                    <li><a href="#">Hotels in Phuket |</a></li>
                    <li><a href="#">Hotels in Kathmandu |</a></li>
                    <li><a href="#">Hotels in London |</a></li>
                    <li><a href="#">Hotels in Paris</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small>Popular Bus Routes </small></strong></li>
                    <li><a href="#">delhi to manali bus |</a></li>
                    <li><a href="#">jaipur to delhi bus |</a></li>
                    <li><a href="#">chandigarh to delhi bus |</a></li>
                    <li><a href="#">bangalore to goa bus |</a></li>
                    <li><a href="#">mumbai to goa bus |</a></li>
                    <li><a href="#">delhi to dehradun bus |</a></li>
                    <li><a href="#">delhi to chandigarh bus |</a></li>
                    <li><a href="#">bangalore to chennai bus |</a></li>
                    <li><a href="#">hyderabad to bangalore bus |</a></li>
                    <li><a href="#">bangalore to hyderabad bus |</a></li>
                    <li><a href="#">delhi to jaipur bus |</a></li>
                    <li><a href="#">chennai to bangalore bus |</a></li>
                    <li><a href="#">indore to bhopal bus |</a></li>
                    <li><a href="#">delhi to shimla bus |</a></li>
                    <li><a href="#">kolkata to siliguri bus</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small> Popular Cab Routes </small></strong></li>
                    <li><a href="#">mumbai to vadodara cab |</a></li>
                    <li><a href="#">mumbai to pune cab |</a></li>
                    <li><a href="#">mumbai to nashik cab |</a></li>
                    <li><a href="#">nashik to mumbai cab |</a></li>
                    <li><a href="#">pune to mumbai cab |</a></li>
                    <li><a href="#">delhi to manali cab |</a></li>
                    <li><a href="#">delhi to chandigarh cab |</a></li>
                    <li><a href="#">pune to shirdi cab |</a></li>
                    <li><a href="#">delhi to jaipur cab |</a></li>
                    <li><a href="#">mumbai to surat cab |</a></li>
                    <li><a href="#">vadodara to mumbai cab |</a></li>
                    <li><a href="#">pune to nashik cab |</a></li>
                    <li><a href="#">chandigarh to manali cab |</a></li>
                    <li><a href="#">delhi to shimla cab |</a></li>
                    <li><a href="#">pune to lonavala cab</a></li>
                </ul>
                <ul class="footer-desc">
                    <li><strong class="text-muted"><small> Popular Train Routes </small></strong></li>
                    <li><a href="#">delhi to goa train |</a></li>
                    <li><a href="#">chennai to bangalore train |</a></li>
                    <li><a href="#">mumbai to goa train |</a></li>
                    <li><a href="#">mumbai to delhi train |</a></li>
                    <li><a href="#">delhi to mumbai train |</a></li>
                    <li><a href="#">bangalore to chennai train |</a></li>
                    <li><a href="#">bangalore to goa train |</a></li>
                    <li><a href="#">delhi to jaipur train |</a></li>
                    <li><a href="#">patna to gaya train |</a></li>
                    <li><a href="#">delhi to chandigarh train |</a></li>
                    <li><a href="#">jaipur to delhi train |</a></li>
                    <li><a href="#">mysore to bangalore train |</a></li>
                    <li><a href="#">delhi to agra train |</a></li>
                    <li><a href="#">delhi to lucknow train |</a></li>
                    <li><a href="#">mumbai to pune train</a></li>
                </ul>
            </div>
            <hr>
            <div class="row px-3">
                <div class="footer-app">
                    <div class="d-flex flex-column font-14-bold">
                        <p class=" mb-1">Follow Us</p>
                        <div class="mt-2">
                            <a target="_blank" class="font-14-bold" href="#" title="facebook" aria-label="Facebook">
                                <span class="fa fa-facebook-square fa-2x"></span>
                            </a>
                            <a target="_blank" class="font-14-bold" href="#" title="Twitter" aria-label="Twitter">
                                <span class="fa fa-twitter square fa-2x"></span>
                            </a>
                            <a target="_blank" class="font-14-bold" href="#" title="youtube" aria-label="youtube">
                                <span class="fa fa-youtube-play fa-2x"></span>
                            </a>
                        </div>
                    </div>
                    <div class="d-flex flex-column font-14-bold">
                        <p class="mb-1">Book Tickets faster. Download our mobile Apps</p>
                        <div class="mt-1">
                            <div class="d-flex mt-2 justify-content-center">
                                <a target="_blank" href="#" title="Google Play" aria-label="google play">
                                    <img src="../assets/image/goibibogplay.png" alt="Google Play" class="img-fluid">
                                </a>
                                <a target="_blank" href="#" title="App Store" aria-label="app store">
                                    <img src="../assets/image/goibiboappstore.png" alt="App Store" class="img-fluid">
                                </a>
                            </div>
                        </div>

                    </div>
                    <div class="d-flex align-items-center font-14-bold">
                        <div class="mt-2">
                            <img src="../assets/image/goibibo/pay1.png" alt="verify sign" class="img-fluid" />
                            <img src="../assets/image/goibibo/pay2.png" alt="amrican icon" class="img-fluid" />
                            <img src="../assets/image/goibibo/pay3.png" alt="master card icon" class="img-fluid" />
                            <img src="../assets/image/goibibo/pay4.png" alt="visa icon" class="img-fluid" />
                            <img src="../assets/image/goibibo/pay6.png" alt="ruPay icon" class="img-fluid" />
                            <img src="../assets/image/goibibo/pay5.png" alt="iata icon" class="img-fluid" />
                        </div>
                    </div>
                </div>
                <div class="footer-last">
                    <div class="brand-logos">
                        <a href="#" title="Make My Trip" aria-label="Make My Trip">
                            <img src="../assets/image/goibibo/makemytrip.png" alt="Make My Trip" class="img-fluid filter-grayscale">
                        </a>
                        <a href="#" title="Red Bus" aria-label="Red Bus">
                            <img src="../assets/image/goibibo/redbus.png" alt="Red Bus" class="img-fluid filter-grayscale">
                        </a>
                    </div>
                    <span class="text-muted">© 2021 ibibogroup All rights reserved</span>
                </div>
            </div>
        </div>
    </div>


    <!-- Scripts -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script>
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl, {
                html: true
            })
        })
    </script>
</body>

</html>