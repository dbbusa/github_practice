<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/LoopLab/bootstrap-looplab.min.css">
    <link rel="stylesheet" href="../assets/css/style-bootstrap-mod3-asg.css">
    <title>LoopLAB</title>
</head>

<body id="home">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <div class="container">
            <a href="index-mod3-asg.php" class="navbar-brand">LoopLAB</a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon "></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="#home" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#explore-head-section" class="nav-link">Explore</a>
                    </li>
                    <li class="nav-item">
                        <a href="#create-head-section" class="nav-link">Create</a>
                    </li>
                    <li class="nav-item">
                        <a href="#share-head-section" class="nav-link">Share</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Home Section -->
    <header id="home-section">
        <div class="dark-overlay">
            <div class="home-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 d-none d-lg-block">
                            <h1 class="display-4">
                                Build <strong>social profiles </strong> and gain revenue revenue and
                                <strong>profits</strong>
                            </h1>
                            <div class="d-flex flex-row">
                                <div class="p-4 align-self-start">
                                    <em class="fa fa-check"></em>
                                </div>
                                <div class="p-4 align-self-end">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis
                                    eius. Nihil, in voluptatum!
                                </div>
                            </div>
                            <div class="d-flex flex-row">
                                <div class="p-4 align-self-start">
                                    <em class="fa fa-check"></em>
                                </div>
                                <div class="p-4 align-self-end">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis
                                    eius. Nihil, in voluptatum!
                                </div>
                            </div>
                            <div class="d-flex flex-row">
                                <div class="p-4 align-self-start">
                                    <em class="fa fa-check"></em>
                                </div>
                                <div class="p-4 align-self-end">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis
                                    eius. Nihil, in voluptatum!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card bg-primary text-center card-form">
                                <div class="card-body">
                                    <h3>Sign Up Today</h3>
                                    <p>Please fill out this form to register</p>
                                    <form action="">
                                        <div class="form-group">
                                            <input type="text" name="" id="" class="form-control form-control-lg"
                                                placeholder="Username">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="" id="" class="form-control form-control-lg"
                                                placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="" id="" class="form-control form-control-lg"
                                                placeholder="Password">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="" id="" class="form-control form-control-lg"
                                                placeholder="Confirm Password">
                                        </div>
                                        <input type="submit" class="btn btn-outline-light btn-block " value="Submit">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Explore Head -->
    <section id="explore-head-section">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <div class="py-5">
                        <h1 class="display-4">Explore</h1>
                        <p class="lead">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet impedit omnis
                            saepe nobis. Velit et illum iusto quibusdam delectus.</p>
                        <a href="" class="btn btn-outline-secondary">Find Out More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Explore Section -->
    <section id="explore-section" class="bg-light text-muted py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <img src="../assets/image/LoopLab/explore-section1.jpg" alt="" class="img-fluid mb-3 rounded-circle">
                </div>
                <div class="col-md-6">
                    <h3>Explore & Connect</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores sed saepe labore totam. Eius,
                        fugit quibusdam? Quidem reprehenderit ipsa cum nam neque, tempore nihil assumenda.</p>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Create Head -->
    <section id="create-head-section" class="bg-primary">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <div class="py-5">
                        <h1 class="display-4">Create</h1>
                        <p class="lead">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet impedit omnis
                            saepe nobis. Velit et illum iusto quibusdam delectus.</p>
                        <a href="" class="btn btn-outline-light">Find Out More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Create Section -->
    <section id="create-section" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Explore & Connect</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores sed saepe labore totam. Eius,
                        fugit quibusdam? Quidem reprehenderit ipsa cum nam neque, tempore nihil assumenda.</p>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="../assets/image/LoopLab/create-section1.jpg" alt="" class="img-fluid mb-3 rounded-circle">
                </div>
            </div>
        </div>
    </section>


     <!-- Share Head -->
     <section id="share-head-section" class="bg-primary">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <div class="py-5">
                        <h1 class="display-4">Share</h1>
                        <p class="lead">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet impedit omnis
                            saepe nobis. Velit et illum iusto quibusdam delectus.</p>
                        <a href="" class="btn btn-outline-light">Find Out More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Share Section -->
    <section id="share-section" class="py-5 bg-light text-muted">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <img src="../assets/image/LoopLab/share-section1.jpg" alt="" class="img-fluid mb-3 rounded-circle">
                </div>
                <div class="col-md-6">
                    <h3>Share what you create</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores sed saepe labore totam. Eius,
                        fugit quibusdam? Quidem reprehenderit ipsa cum nam neque, tempore nihil assumenda.</p>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                    <div class="d-flex flex-row">
                        <div class="p-4 align-self-start">
                            <em class="fa fa-check"></em>
                        </div>
                        <div class="p-4 align-self-end">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae voluptatibus quis eius.
                            Nihil, in voluptatum!
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Footer -->

    <footer class="bg-dark" id="main-footer">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <div class="py-4">
                        <h1 class="h3">LoopLAB</h1>
                        <p>Copyright &copy; 2017</p>
                        <button class="btn btn-primary" data-toggle="modal" data-target="#contactModal">Contact Us</button>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Contact Modal -->

    <div class="modal fade text-dark" id="contactModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="contactModalTitle">Contact Us</h5>
                    <button class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="" id="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="" id="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-block">Submit</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/LoopLab/bootstrap.min.js"></script>
</body>

</html>