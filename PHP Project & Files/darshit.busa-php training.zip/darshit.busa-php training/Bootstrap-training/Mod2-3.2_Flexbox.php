<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod2-prac">
            <div class="container bg-dark text-white p-3">
                <h2 class="h1 text-center text-warning">Flexbox Classes</h2>

                <h5 class="text-center text-info">Flexbox with direction Row for large device and Column for mobile device</h5>
                <div class="d-sm-flex flex-md-row flex-sm-column bg-secondary my-2">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                    <div class="p-2 bg-secondary">Item 4</div>
                </div>
                <div class="d-sm-flex flex-md-row-reverse flex-sm-column-reverse bg-secondary">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                    <div class="p-2 bg-secondary">Item 4</div>
                </div>

                <h5 class="text-center text-info">Flexbox Alignment</h5>
                <div class="d-flex my-2 justify-content-start border border-primary">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>
                <div class="d-flex my-2 justify-content-end border border-success">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>
                <div class="d-flex my-2 justify-content-center border border-danger">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>
                <div class="d-flex my-2 justify-content-between border border-info">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>
                <div class="d-flex my-2 justify-content-around border border-warning">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>
                <div class="d-flex my-2 justify-content-evenly border border-primary">
                    <div class="p-2 bg-secondary">Item 1</div>
                    <div class="p-2 bg-secondary">Item 2</div>
                    <div class="p-2 bg-secondary">Item 3</div>
                </div>


                <div class="row">
                    <h5 class="text-center text-info">Flexbox Align Item</h5>
                    <div class="d-flex my-2 align-items-start border border-primary" style="height: 100px;">
                        <div class="p-2 bg-secondary">Item 1</div>
                        <div class="p-2 bg-secondary">Item 2</div>
                        <div class="p-2 bg-secondary">Item 3</div>
                    </div>
                    <div class="d-flex my-2 align-items-end border border-success" style="height: 100px;">
                        <div class="p-2 bg-secondary">Item 1</div>
                        <div class="p-2 bg-secondary">Item 2</div>
                        <div class="p-2 bg-secondary">Item 3</div>
                    </div>
                    <div class="d-flex my-2 align-items-center border border-danger" style="height: 100px;">
                        <div class="p-2 bg-secondary">Item 1</div>
                        <div class="p-2 bg-secondary">Item 2</div>
                        <div class="p-2 bg-secondary">Item 3</div>
                    </div>
                    <div class="d-flex my-2 align-items-baseline border border-info" style="height: 100px;">
                        <div class="p-2 bg-secondary">Item 1</div>
                        <div class="p-2 bg-secondary">Item 2</div>
                        <div class="p-2 bg-secondary">Item 3</div>
                    </div>
                    <div class="d-flex my-2 align-items-stretch border border-warning" style="height: 100px;">
                        <div class="p-2 bg-secondary">Item 1</div>
                        <div class="p-2 bg-secondary">Item 2</div>
                        <div class="p-2 bg-secondary">Item 3</div>
                    </div>
                </div>

                <h5 class="text-center text-info">Flex Wrap</h5>
                <div class="d-flex flex-wrap justify-content-center">
                    <div class="p-2 m-2 bg-secondary">Item 1</div>
                    <div class="p-2 m-2 bg-secondary">Item 2</div>
                    <div class="p-2 m-2 bg-secondary">Item 3</div>
                    <div class="p-2 m-2 bg-secondary">Item 4</div>
                    <div class="p-2 m-2 bg-secondary">Item 5</div>
                    <div class="p-2 m-2 bg-secondary">Item 6</div>
                    <div class="p-2 m-2 bg-secondary">Item 7</div>
                    <div class="p-2 m-2 bg-secondary">Item 8</div>
                    <div class="p-2 m-2 bg-secondary">Item 9</div>
                    <div class="p-2 m-2 bg-secondary">Item 10</div>
                    <div class="p-2 m-2 bg-secondary">Item 11</div>
                    <div class="p-2 m-2 bg-secondary">Item 12</div>
                    <div class="p-2 m-2 bg-secondary">Item 13</div>
                    <div class="p-2 m-2 bg-secondary">Item 14</div>
                    <div class="p-2 m-2 bg-secondary">Item 15</div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>