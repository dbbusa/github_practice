<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bg-dark">
            <div class="container">
                <h2 class="h1 text-center text-warning">Popovers</h2>
                <button type="button" class="btn btn-lg btn-danger" data-bs-toggle="popover" title="Lorem, ipsum dolor" data-bs-content="Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident, autem.">Popover</button>

                <div class="d-block mt-3">
                    <button type="button" class="btn btn-secondary" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Top popover">
                        Popover on top
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="right" data-bs-content="Right popover">
                        Popover on right
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="bottom" data-bs-content="Bottom popover">
                        Popover on bottom
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="left" data-bs-content="Left popover">
                        Popover on left
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../footer.php' ?>