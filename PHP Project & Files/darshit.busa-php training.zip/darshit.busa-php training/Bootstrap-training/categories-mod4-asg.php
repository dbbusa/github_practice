<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/Blogen/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/Blogen/style.css">
    <title>Blogen</title>
</head>

<body>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0" aria-label="navigation for admin">
        <div class="container">
            <a href="index-mod4-asg.php" class="navbar-brand">Blogen</a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item px-2">
                        <a href="index-mod4-asg.php" class="nav-link">Dashboard</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="posts-mod4-asg.php" class="nav-link">Posts</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="categories-mod4-asg.php" class="nav-link active">Categories</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="users-mod4-asg.php" class="nav-link">Users</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown mr-3">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                            <em class="fa fa-user"></em> Welcome Brad
                        </a>
                        <div class="dropdown-menu">
                            <a href="profile-mod4-asg.php" class="dropdown-item">
                                <em class="fa fa-user-circle"></em> Profile
                            </a>
                            <a href="settings-mod4-asg.php" class="dropdown-item">
                                <em class="fa fa-gear"></em> Settings
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a href="login-mod4-asg.php" class="nav-link">
                            <em class="fa fa-user-times"></em>
                            Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <header id="main-header" class="py-2 bg-success text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1><em class="fa fa-folder"></em> Categories</h1>
                </div>
            </div>
        </div>
    </header>

    <section id="action" class="py-4 mb-4 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6 ml-auto">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-btn">
                            <button class="btn btn-success">Search</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Categories -->
    <section id="categories">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card table-responsive">
                        <div class="card-header">
                            <h4>Latest Categories</h4>
                        </div>
                        <table class="table table-striped">
                            <caption class="text-muted">Latest Categories Details</caption>
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Date Posted</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td> 1 </td>
                                    <td> Web Development </td>
                                    <td> July 12, 2017 </td>
                                </tr>
                                <tr>
                                    <td> 2 </td>
                                    <td> Tech Gadgets </td>
                                    <td> July 13, 2017 </td>
                                </tr>
                                <tr>
                                    <td> 3 </td>
                                    <td> Business </td>
                                    <td> July 14, 2017 </td>
                                </tr>
                                <tr>
                                    <td> 4 </td>
                                    <td> Health & Wellness </td>
                                    <td> July 16, 2017 </td>
                                </tr>
                            </tbody>
                        </table>
                        <nav class="ml-4" aria-label="Pagination for Table">
                            <ul class="pagination">
                                <li class="page-item disabled">
                                    <a href="#" class="page-link">Previous</a>
                                </li>
                                <li class="page-item active">
                                    <a href="#" class="page-link">1</a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link">2</a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link">3</a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer id="main-footer" class="bg-dark text-white mt-5 p-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="lead text-center">Copyright &copy; 2017 Blogen</p>
                </div>
            </div>
        </div>
    </footer>


    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/LoopLab/bootstrap.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.18.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor1');
    </script>

</body>

</html>