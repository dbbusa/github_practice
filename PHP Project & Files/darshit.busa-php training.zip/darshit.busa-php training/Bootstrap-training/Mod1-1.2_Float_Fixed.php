<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <h2 class="display-2 text-center text-primary">Float & Fixed Positions</h2>

                <h4 class="text-center fw-bold">Float Position</h4>
                <div class="border border-primary">
                    <div class="float-start">Float Start </div><br>
                    <div class="float-end">Float End </div><br>
                    <div class="float-none">Float None</div>

                    <p class="text-center">For Different Screen</p>

                    <div class="float-sm-start">Float Start</div><br>
                    <div class="float-md-end">Float End</div><br>
                    <div class="float-lg-end">Float End</div><br>
                    <div class="float-xl-start">Float Start</div><br>
                </div>

                <div class="fixed-bottom bg-warning"> Fixed Bottom Content :- Lorem ipsum dolor, sit amet
                    consectetur adipisicing elit. Modi soluta dicta eligendi repudiandae perferendis doloremque nam
                    veritatis consequatur iure saepe?</div>
                <div class="fixed-top bg-primary"> Fixed top Content :- Lorem ipsum dolor, sit amet consectetur
                    adipisicing elit. Modi soluta dicta eligendi repudiandae perferendis doloremque nam veritatis
                    consequatur iure saepe?</div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>