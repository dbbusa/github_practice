<?php include '../header.php' ?>

<section id="mainSection">
  <div class="row mt-0">
    <?php include 'sidebar.php' ?>
    <div class="main bootstrap-mod2-prac bg-dark p-2">
      <div class="container bg-dark p-3">
        <h2 class="h1 text-center text-warning">Collapse & Accordion</h2>

        <h3 class="text-center text-info">Collapse</h3>
        <div class="row">
          <div class="d-block">
            <a class="btn btn-primary" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
              Link with href
            </a>
            <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
              Button with data-bs-target
            </button>
          </div>
          <div class="collapse mt-2" id="collapseExample">
            <div class="card card-body">
              Some placeholder content for the collapse component. This panel is hidden by default but revealed
              when the user activates the relevant trigger.
            </div>
          </div>
        </div>

        <div class="mt-5 d-block">
          <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
            Toggle width collapse
          </button>
        </div>
        <div class="mt-3">
          <div class="collapse collapse-horizontal" id="collapseWidthExample">
            <div class="card card-body" style="width: 300px;">
              This is some placeholder content for a horizontal collapse. It's hidden by default and shown when
              triggered.
            </div>
          </div>
        </div>


        <div class="mt-1 d-block">
          <a class="btn btn-primary" data-bs-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Toggle first element</a>
          <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Toggle second element</button>
          <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=".multi-collapse" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">Toggle both
            elements</button>
        </div>
        <div class="row mt-3">
          <div class="col">
            <div class="collapse multi-collapse" id="multiCollapseExample1">
              <div class="card card-body">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ipsa quaerat temporibus aspernatur
                suscipit ab aperiam nisi ratione, necessitatibus odio quisquam?
              </div>
            </div>
          </div>
          <div class="col">
            <div class="collapse multi-collapse" id="multiCollapseExample2">
              <div class="card card-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore repellendus tempora enim
                similique dicta reprehenderit saepe facere ut eligendi provident?
              </div>
            </div>
          </div>
        </div>

        <h3 class="text-center text-info mt-3">Default Accordion</h3>

        <div class="accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                Accordion 1
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore non iusto ea repellendus consectetur saepe, harum ratione, natus ducimus commodi expedita omnis, in odio aperiam. Aut nam, debitis pariatur quibusdam quia officiis architecto explicabo omnis.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Accordion 2
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore non iusto ea repellendus consectetur saepe, harum ratione, natus ducimus commodi expedita omnis, in odio aperiam. Aut nam, debitis pariatur quibusdam quia officiis architecto explicabo omnis.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Accordion 3
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore non iusto ea repellendus consectetur saepe, harum ratione, natus ducimus commodi expedita omnis, in odio aperiam. Aut nam, debitis pariatur quibusdam quia officiis architecto explicabo omnis.
              </div>
            </div>
          </div>
        </div>

        <h3 class="text-center text-info mt-4">Flush Accordion</h3>

        <div class="accordion accordion-flush" id="accordionFlushExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="flush-headingOne">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                Accordion 1
              </button>
            </h2>
            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, nisi repellat provident exercitationem, reiciendis natus, nostrum quod ex sed consequatur at est alias sint quaerat sunt commodi nam placeat minima!
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="flush-headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                Accordion 2
              </button>
            </h2>
            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
              <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas quidem laudantium facere, magnam quod dolore quis officia ipsa reprehenderit atque vitae ipsam repudiandae, adipisci id. Similique, obcaecati sunt. Beatae, vitae!</div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="flush-headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                Accordion 3
              </button>
            </h2>
            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus accusantium ipsam exercitationem delectus animi maxime maiores qui, repellendus reprehenderit nulla suscipit veniam in at hic obcaecati error perspiciatis ducimus sit.
              </div>
            </div>
          </div>
        </div>

        <h3 class="text-center text-info mt-4">Always Open Accordion</h3>
        <div class="accordion" id="accordionPanelsStayOpenExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                Accordion 1
              </button>
            </h2>
            <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
              <div class="accordion-body">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Laudantium sit provident, eos itaque voluptate porro odit ullam blanditiis delectus? Quis sequi exercitationem nostrum quod beatae, vel alias dicta eum recusandae.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
                Accordion 2
              </button>
            </h2>
            <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quae fugit, nesciunt amet quaerat ipsum eaque accusamus eligendi dolor. Fugit labore quod excepturi! Ea at esse iste voluptate, eius quis.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
                Accordion 3
              </button>
            </h2>
            <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, esse rerum vero architecto corrupti libero! Fugit, voluptatibus enim. Similique cupiditate sunt ullam animi eaque, est dolorem quaerat maiores inventore! Laudantium?
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
<?php include '../footer.php' ?>