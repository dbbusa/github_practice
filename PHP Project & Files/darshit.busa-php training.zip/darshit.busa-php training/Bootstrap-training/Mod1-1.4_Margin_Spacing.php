<?php include '../header.php' ?>


<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <h2 class="display-2 text-center text-warning">Margin and Spacing</h2>

                <h4 class="text-center fw-bold mt-4">Margin</h4>

                <div class="row">
                    <div class="m-2 p-2 col-12 bg-light border">Margin class m-4 Applied here</div>
                    <div class="m-2 p-2 col-12 bg-light border">Margin class m-4 Applied here</div>
                    <div class="m-2 p-2 col-12 bg-light border">Margin class m-4 Applied here</div>
                </div>

                <h4 class="text-center fw-bold mt-4">Padding</h4>
                <div class="row">
                    <div class="p-4 mx-auto col-3 bg-light border">Padding class p-4 and mx-auto Applied here</div>
                    <div class="p-4 mx-auto col-3 bg-light border">Padding class p-4 and mx-auto Applied here</div>
                    <div class="p-4 mx-auto col-3 bg-light border">Padding class p-4 and mx-auto Applied here</div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>