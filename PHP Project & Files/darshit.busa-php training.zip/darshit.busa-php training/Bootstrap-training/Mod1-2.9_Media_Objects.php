<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container bg-dark text-white p-3">
                <h2 class="h1 text-center text-warning">Media Objects</h2>
                <div class="d-flex align-items-center">
                    <div class="">
                        <h4 class="">Right-aligned</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                            et dolore magna aliqua.</p>
                    </div>
                    <div class="ms-3">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                </div>
                <div class="d-flex align-items-end">
                    <div class="">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                    <div class="">
                        <h4 class="">Right-aligned</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                            et dolore magna aliqua.</p>
                    </div>
                </div>

                <div class="d-flex align-content-stretch flex-wrap">
                    <div class="order-3 p-2 bd-highlight">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                    <div class="order-2 p-2 bd-highlight">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                    <div class="order-1 p-2 bd-highlight">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                    <div class="order-1 p-2 bd-highlight">
                        <img src="https://www.w3schools.com/bootstrap/img_avatar1.png" alt="Media Object Avtar" class="img-fluid w-25">
                    </div>
                </div>


            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>