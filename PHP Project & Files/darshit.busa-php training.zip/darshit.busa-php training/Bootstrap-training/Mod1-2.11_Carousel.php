<?php include '../header.php' ?>

<section id="mainSection">
  <div class="row mt-0">
    <?php include 'sidebar.php' ?>
    <div class="main bootstrap-mod1 bg-dark">
      <div class="container">
        <h2 class="h1 text-center text-warning">Carousel</h2>

        <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="10000">
              <img src="https://cdn.pixabay.com/photo/2016/02/13/12/26/aurora-1197753_960_720.jpg" class="d-block w-100" alt="Image 1">
              <div class="carousel-caption d-none d-md-block">
                <h5>Lorem ipsum dolor sit amet.</h5>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem perspiciatis, esse illum eius quasi
                  hic.</p>
              </div>
            </div>
            <div class="carousel-item" data-bs-interval="2000">
              <img src="https://cdn.pixabay.com/photo/2015/10/30/20/13/sunrise-1014712_960_720.jpg" class="d-block w-100" alt="Image 3">
              <div class="carousel-caption d-none d-md-block">
                <h5>Lorem ipsum dolor sit amet.</h5>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem perspiciatis, esse illum eius quasi
                  hic.</p>
              </div>
            </div>
            <div class="carousel-item">
              <img src="https://cdn.pixabay.com/photo/2012/08/27/14/19/mountains-55067_960_720.png" class="d-block w-100" alt="Image 2">
              <div class="carousel-caption d-none d-md-block">
                <h5>Lorem ipsum dolor sit amet.</h5>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem perspiciatis, esse illum eius quasi
                  hic.</p>
              </div>
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include '../footer.php' ?>