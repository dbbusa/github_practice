<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-dark">
            <div class="container bg-dark text-white p-3">
                <h2 class="h1 text-center text-warning">Badges</h2>

                <h3 class="text-center text-warning">Badges With Headings</h3>
                <div class="row mt-4 mb-3">

                    <h1>Heading 1 <span class="badge bg-primary">h1</span></h1>
                    <h2>Heading 2 <span class="badge bg-primary">h2</span></h2>
                    <h3>Heading 3 <span class="badge bg-primary">h3</span></h3>
                    <h4>Heading 4 <span class="badge bg-primary">h4</span></h4>
                    <h5>Heading 5 <span class="badge bg-primary">h5</span></h5>
                    <h6>Heading 6 <span class="badge bg-primary">h6</span></h6>

                </div>
                <h3 class="text-center text-warning">Badge with Button</h3>
                <div class="row mt-4 mb-3">
                    <div class="col-3">
                        <button class="btn btn-primary">Updates<span class="badge bg-secondary">5</span></button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-danger">Calls<span class="badge bg-secondary">8</span></button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-warning">Notifications<span class="badge bg-secondary">10</span></button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-info">Total<span class="badge bg-secondary">23</span></button>
                    </div>
                </div>

                <h3 class="text-center text-warning">Badge with Position</h3>
                <div class="row mt-4 mb-3">
                    <div class="col-3">
                        <button class="btn btn-primary position-relative">Updates
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">3+</span>
                        </button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-danger position-relative">Calls
                            <span class="position-absolute top-100 start-100 translate-middle p-2 bg-success border border-light rounded-circle">
                                <span class="visually-hidden">*</span>
                            </span>
                        </button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-warning position-relative">Notifications
                            <span class="position-absolute top-0 start-100 translate-middle badge bg-success">5+</span>
                        </button>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-info position-relative">Total
                            <span class="position-absolute top-0 start-100 translate-middle badge bg-secondary">15+</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>