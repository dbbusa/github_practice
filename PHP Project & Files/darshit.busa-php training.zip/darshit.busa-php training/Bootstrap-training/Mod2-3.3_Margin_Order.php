<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod2-prac bg-dark p-2">
            <div class="container text-white">
                <h2 class="h1 text-center text-warning">Auto Margin wrap & Ordering</h2>

                <h5 class="text-center text-info">Flex Auto Margin</h5>

                <div class="d-flex border border-primary mb-3">
                    <div class="p-2 m-2 bg-secondary">Item 1</div>
                    <div class="p-2 m-2 bg-secondary">Item 2</div>
                    <div class="p-2 m-2 bg-secondary">Item 3</div>
                </div>

                <div class="d-flex border border-danger mb-3">
                    <div class="p-2 me-auto my-2 ms-2 bg-secondary">Item 1</div>
                    <div class="p-2 m-2 bg-secondary">Item 2</div>
                    <div class="p-2 m-2 bg-secondary">Item 3</div>
                </div>

                <div class="d-flex border border-success mb-3">
                    <div class="p-2 m-2 bg-secondary">Item 1</div>
                    <div class="p-2 m-2 bg-secondary">Item 2</div>
                    <div class="p-2 ms-auto me-2 my-2 bg-secondary">Item 3</div>
                </div>

                <h5 class="text-center text-info">Ordering</h5>

                <div class="d-flex flex-nowrap border border-primary">
                    <div class="order-3 p-2 m-2 bg-secondary">Order 3</div>
                    <div class="order-2 p-2 m-2 bg-secondary">Order 2</div>
                    <div class="order-1 p-2 m-2 bg-secondary">Order 1</div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>