<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1">
            <div class="container">
                <h2 class="h1 text-center text-warning">Navbars & Nav</h2>


                <h4 class="text-center text-info">Navbars</h4>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded" aria-label="Navbar Practice">
                    <div class="container-fluid px-3">
                        <a href="#" class="navbar-brand"> DB</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navigation">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a href="#" class="nav-link">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link active" aria-current="page">link</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" id="navDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Dropdown Menu
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="navDropdown">
                                        <li><a href="#" class="dropdown-item">Item 1</a></li>
                                        <li><a href="#" class="dropdown-item">Item 2</a></li>
                                        <li><a href="#" class="dropdown-item">Item 3</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link disabled">link</a>
                                </li>
                            </ul>
                            <form action="#" class="d-flex">
                                <div class="input-group">
                                    <input type="text" placeholder="Search" class="form-control">
                                    <button class="btn btn-outline-success" type="submit">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </nav>

                <hr class="bg-info mt-5">

                <h4 class="text-center text-warning">Nav</h4>

                <div class="row mt-2">
                    <h6 class="text-center text-info"> Nav using ul tag</h6>
                    <ul class="nav bg-dark">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Active</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                        </li>
                    </ul>
                </div>
                <div class="row mt-2">
                    <h6 class="text-center text-info"> Nav using nav tag</h6>
                    <nav class="nav bg-dark" aria-label="nav Practice">
                        <a class="nav-link active" aria-current="page" href="#">Active</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                    </nav>
                </div>
                <div class="row mt-2">
                    <h6 class="text-center text-info"> Nav Center</h6>
                    <nav class="nav justify-content-center bg-dark" aria-label="Nav Center Practice">
                        <a class="nav-link active" aria-current="page" href="#">Active</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                    </nav>
                </div>
                <div class="row mt-2">
                    <h6 class="text-center text-info"> Nav End</h6>
                    <nav class="nav justify-content-end bg-dark" aria-label="NAv at End Practice">
                        <a class="nav-link active" aria-current="page" href="#">Active</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link" href="#">Link</a>
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>