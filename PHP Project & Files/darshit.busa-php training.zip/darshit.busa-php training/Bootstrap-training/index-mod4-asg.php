<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/Blogen/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/Blogen/style.css">
    <title>Blogen</title>
</head>

<body>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0" aria-label="navigation for admin">
        <div class="container">
            <a href="index-mod4-asg.php" class="navbar-brand">Blogen</a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item px-2">
                        <a href="index-mod4-asg.php" class="nav-link active">Dashboard</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="posts-mod4-asg.php" class="nav-link">Posts</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="categories-mod4-asg.php" class="nav-link">Categories</a>
                    </li>
                    <li class="nav-item px-2">
                        <a href="users-mod4-asg.php" class="nav-link">Users</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown mr-3">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                            <em class="fa fa-user"></em> Welcome Brad
                        </a>
                        <div class="dropdown-menu">
                            <a href="profile-mod4-asg.php" class="dropdown-item">
                                <em class="fa fa-user-circle"></em> Profile
                            </a>
                            <a href="settings-mod4-asg.php" class="dropdown-item">
                                <em class="fa fa-gear"></em> Settings
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a href="login-mod4-asg.php" class="nav-link">
                            <em class="fa fa-user-times"></em>
                            Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <header id="main-header" class="py-2 bg-primary text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1><em class="fa fa-gear"></em> Dashboard</h1>
                </div>
            </div>
        </div>
    </header>

    <section id="action" class="py-4 mb-4 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="#" class="btn btn-primary btn-block" data-toggle="modal" data-target="#addPostModal">
                        <em class="fa fa-plus"></em> Add Post
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="btn btn-success btn-block" data-toggle="modal" data-target="#addCategoryModal">
                        <em class="fa fa-plus"></em> Add Category
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="btn btn-warning btn-block" data-toggle="modal" data-target="#addUserModal">
                        <em class="fa fa-plus"></em> Add User
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section id="posts">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="card table-responsive">
                        <div class="card-header">
                            <h4>Latest Posts</h4>
                        </div>
                        <table class="table table-striped">
                            <caption class="text-muted">Latest Posts Details</caption>
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Date Posted</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td> 1 </td>
                                    <td> Post One </td>
                                    <td> Web Development </td>
                                    <td> July 12, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                                <tr>
                                    <td> 2 </td>
                                    <td> Post Two </td>
                                    <td> Tech Gadgets </td>
                                    <td> July 13, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                                <tr>
                                    <td> 3 </td>
                                    <td> Post Three </td>
                                    <td> Web Development </td>
                                    <td> July 14, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                                <tr>
                                    <td> 4 </td>
                                    <td> Post Four </td>
                                    <td> Business </td>
                                    <td> July 14, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                                <tr>
                                    <td> 5 </td>
                                    <td> Post Five </td>
                                    <td> Web Development </td>
                                    <td> July 15, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                                <tr>
                                    <td> 6 </td>
                                    <td> Post Six </td>
                                    <td> Health & Wellness </td>
                                    <td> July 16, 2017 </td>
                                    <td> <a href="details-mod4-asg.php" class="btn btn-secondary btn-sm"> <em
                                                class="fa fa-angle-double-right"></em> Details </a> </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center bg-primary mb-3 text-white">
                        <div class="card-body">
                            <h3>Posts</h3>
                            <h1 class="display-4">
                                <em class="fa fa-pencil"></em> 6
                            </h1>
                            <a href="posts-mod4-asg.php" class="btn btn-outline-light btn-sm">
                                View
                            </a>
                        </div>
                    </div>
                    <div class="card text-center bg-success mb-3 text-white">
                        <div class="card-body">
                            <h3>Categories</h3>
                            <h1 class="display-4">
                                <em class="fa fa-folder-o"></em> 4
                            </h1>
                            <a href="categories-mod4-asg.php" class="btn btn-outline-light btn-sm">
                                View
                            </a>
                        </div>
                    </div>
                    <div class="card text-center bg-warning mb-3 text-white">
                        <div class="card-body">
                            <h3>Users</h3>
                            <h1 class="display-4">
                                <em class="fa fa-users"></em> 2
                            </h1>
                            <a href="users-mod4-asg.php" class="btn btn-outline-light btn-sm">
                                View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer id="main-footer" class="bg-dark text-white mt-5 p-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="lead text-center">Copyright &copy; 2017 Blogen</p>
                </div>
            </div>
        </div>
    </footer>


    <!-- Post Modal -->

    <div class="modal fade" id="addPostModal" aria-labelledby="Add Post" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add Post</h5>
                    <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="category">Category</label>
                            <select class="form-control">
                                <option value="">Web Development</option>
                                <option value="">Tech Gadgets</option>
                                <option value="">Business</option>
                                <option value="">Health & Wellness</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="file">Image Upload</label>
                            <input type="file" class="form-control-file">
                            <small class="form-text text-muted">Max Size 3mb</small>
                        </div>
                        <div class="form-group">
                            <label for="body">Body</label>
                            <textarea name="editor1" class="form-control"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Modal -->
    <div class="modal fade" id="addCategoryModal" aria-labelledby="Add Category" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Add Category</h5>
                    <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save changes</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Users Modal -->
    <div class="modal fade" id="addUserModal" aria-labelledby="Add User" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title">Add User</h5>
                    <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password " class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="confirm password">Confirm Password</label>
                            <input type="password" class="form-control">
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/LoopLab/bootstrap.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.18.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor1');
    </script>
</body>

</html>