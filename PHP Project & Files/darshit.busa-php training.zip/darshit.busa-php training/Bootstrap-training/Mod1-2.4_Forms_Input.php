<?php include '../header.php' ?>

<section id="mainSection">
    <div class="row mt-0">
        <?php include 'sidebar.php' ?>
        <div class="main bootstrap-mod1 bg-secondary">
            <div class="container p-3" id="content">
                <h2 class="h1 text-center text-warning">Forms & Input</h2>


                <h4 class="text-center text-info">Inputs</h4>

                <div class="row">
                    <div class="mx-auto col-sm-12 col-md-6 col-lg-6">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="email" placeholder="Email Address">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Example Description</label>
                            <textarea class="form-control" id="description" rows="3" placeholder="Enter Description"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="exampleDataList" class="form-label">Datalist example</label>
                            <input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="Type to search...">
                            <datalist id="datalistOptions">
                                <option value="San Francisco"></option>
                                <option value="New York"></option>
                                <option value="Seattle"></option>
                                <option value="Los Angeles"></option>
                                <option value="Chicago"> </option>
                            </datalist>
                        </div>
                    </div>
                </div>
                <hr class="bg-warning mt-5">

                <h4 class="text-center text-info">Forms</h4>
                <div class="row">
                    <div class="col-sm-12 col-md-8 col-lg-8 mx-auto">
                        <form>
                            <div class="row mb-3">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
                                    <div id="emailHint" class="form-text text-warning">
                                        Your Email Address should be Valid.
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="inputPassword3" placeholder="***">
                                    <div id="passwordHint" class="form-text text-warning">
                                        Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-10 offset-sm-2">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="gridCheck1">
                                        <label class="form-check-label" for="gridCheck1">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row justify-content-center">
                                <button type="submit" class="btn w-auto btn-primary">Sign in</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php' ?>