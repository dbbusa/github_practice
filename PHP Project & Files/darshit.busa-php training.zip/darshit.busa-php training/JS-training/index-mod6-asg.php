<?php include '../header.php' ?>
<section id="mainSection">
  <div class="row">
    <?php include 'sidebar.php' ?>
    <div class="main js-mod2-prac">
      <div class="mt-3 text-dark">
        <div class="container">
          <div class="row justify-content-center mt-3">
            <div class="col-12">
              <div class="alert alert-primary fade d-none" role="alert" id="resError">

              </div>

              <div class="alert alert-success fade d-none" role="alert" id="resSuccess">

              </div>
            </div>
            <div class="col-11  mt-2">
              <div class="card text-left">
                <div class="card-header fw-bold">
                  Practice
                </div>
                <div class="card-body">


                  <!-- Task 1 -->
                  <div class="row">
                    <div class="col-12">
                      <h6><strong>Task 1:</strong> Display Product information in Grid format with AddToCart option. once a
                        user click on AddtoCart button should be stored in local storage. Click on cart summary will display
                        that data into console.</h6>
                      <hr>
                    </div>
                    <div class="col-12 p-2">
                      <table class="table table-border table-default">
                        <caption class="d-none">Products Data</caption>

                        <thead class="text-center">
                          <tr>
                            <th>ProductID</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody id="tblBodyData">

                        </tbody>
                      </table>
                    </div>
                  </div>


                </div>

                <div class="card-footer">
                  <div class="col-12 p-2">
                    <h4 class="text-center w-auto fw-bold pe-3">Cart Summary

                      <span class="btn btn-default float-end" onclick="clearCart()"> <svg xmlns="http://www.w3.org/2000/svg" width="25" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.414 6.414a2 2 0 001.414.586H19a2 2 0 002-2V7a2 2 0 00-2-2h-8.172a2 2 0 00-1.414.586L3 12z" />
                        </svg></span>

                      <span class="btn btn-default float-end" onclick="cartSummary()"> <svg xmlns="http://www.w3.org/2000/svg" width="25" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg></span>
                    </h4>
                    <table class="table table-border table-default">
                      <caption class="d-none">cart summary</caption>
                      <thead class="text-center">
                        <tr>
                          <th>ProductID</th>
                          <th>Product Name</th>
                          <th>Price</th>
                        </tr>
                      </thead>
                      <tbody id="tblSumBodyData">

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script type="text/javascript" src="../assets/js/custom.js"></script>
<script type="text/javascript">
  loadData();
</script>
<?php
include '../footer.php';
?>