<?php include '../header.php'; ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php'; ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">


          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Write a JavaScript function to check whether a string is blank or not</h6>
              </div>
              <div class="col-12 text-center mt-2">
                <input type="text" name="strName" id="strName" placeholder="Enter Name" class="form-control">
                <small class="text-danger" id="errStrName"></small>
              </div>
              <div class="col-12 text-center mt-2">
                <button class="btn btn-primary" onclick="isEmptyStr()">Check String</button>
              </div>
            </div>
          </div>

          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Write a JavaScript function to split a string and convert it into an array
                  of
                  words</h6>
              </div>
              <div class="col-12 text-center mt-2">
                <input type="text" name="stringInp" id="stringInp" placeholder="Enter , seprated String "
                  class="form-control">
                <small class="text-danger" id="errMsgArr"></small>
              </div>
              <div class="col-12 text-center mt-2">
                <div class="" id="resArr"></div>
              </div>

              <div class="col-12 text-center mt-2">
                <button class="btn btn-primary" onclick="convertStrToArr()">Convert</button>
              </div>
            </div>
          </div>

          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Write a JavaScript function to extract a specified number of characters
                  from a
                  string.</h6>
              </div>
              <div class="col-6 text-center mt-2">
                <input type="text" name="stringInp1" id="stringInp1" placeholder="Enter String" class="form-control">
              </div>
              <div class="col-6 text-center mt-2">
                <input type="number" name="num" id="num" placeholder="Enter Number" min="1" class="form-control">
              </div>
              <div class="col-12 text-center mt-2">
                <small class="text-danger" id="errsub"></small>
              </div>

              <div class="col-12 text-center mt-2">
                <button class="btn btn-primary" onclick="getCharFromStr()">Get Chars</button>
              </div>
            </div>
          </div>

          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Write a JavaScript function to get the current date</h6>
              </div>

              <div class="col-12 text-center mt-2">
                <small class="text-success" id="currentDate"></small>
              </div>

              <div class="col-12 text-center mt-2">
                <button class="btn btn-primary" onclick="getTodayDate()">Get Current Date</button>
              </div>
            </div>
          </div>

          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Try some operation with list like push, pop, shifting, deleting element
                </h6>
              </div>

              <div class="col-sm-12 col-md-6 mt-2 p-3">
                <div class="list-group">
                  <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                    Data List
                  </a>
                  <div id="listHolder">
                  </div>
                </div>
              </div>
              <div class="col-sm-12 col-md-6 mt-2">
                <div class="row">
                  <div class="col-12 text-center mt-2">
                    <input type="text" class="form-control" id="inpWord" placeholder="Enter Element">
                    <small class="text-danger" id="errList"></small>
                  </div>
                  <div class="col-6 text-center mt-2">
                    <button class="btn btn-primary btn-sm" onclick="pushElement()">Push Element</button>
                  </div>
                  <div class="col-6 text-center mt-2">
                    <button class="btn btn-info btn-sm" onclick="popElement()">Pop Element</button>
                  </div>
                  <div class="col-6 text-center mt-2">
                    <button class="btn btn-success btn-sm" onclick="shiftElement()">Shift Element</button>
                  </div>
                  <div class="col-6 text-center mt-2">
                    <button class="btn btn-warning btn-sm" onclick="deleteElement()">Delete Element</button>
                  </div>
                </div>
              </div>


            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/script-mod2-prac.js"></script>
  <script>
    displayElement();
  </script>
<?php include '../footer.php' ?>