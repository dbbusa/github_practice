<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="container mt-3">

            <div class="row">
              <div class="col-12">
                <div class="form-group">
                  <label for="strData">Enter String</label>
                  <input type="text" name="strData" id="strData" class="form-control" placeholder="Enter String"
                    aria-describedby="errStrData">
                  <small id="errStrData" class="text-muted"></small>
                  <p id="resData"></p>
                </div>
              </div>
              <div class="col-12 align-item-center">
                <button class="btn btn-primary btn-sm" onclick="stringFunction()">Submit</button>
              </div>
            </div>
        
            <div class="row">
              <div class="col-12">
                <p id="chngeStr" class=" ">This Data Will Change After 10 Second </p>
              </div>
            </div>
        
            <div class="row">
              <div class="col-6">
                <div class="form-group">
                  <label for="number1">Number 1</label>
                  <input type="text" name="number1" id="number1" class="form-control" placeholder="Enter Number 1">
                  <small id="errNum1" class="text-muted"></small>
                </div>
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label for="number1">Number 2</label>
                  <input type="text" name="number2" id="number2" class="form-control" placeholder="Enter Number 2">
                  <small id="errNum2" class="text-muted"></small>
                </div>
              </div>
              <div class="col-12 mt-2">
                <p id="resAddition" class=" "></p>
                <button class="btn btn-primary btn-sm" onclick="sum2Number()">Addition</button>
              </div>
            </div>
            <h5 class="  text-center border-top border-bottom border-primary mt-2 py-2">ES6</h5>
        
            <div class="row mt-3">
              <div class="col-12">
                <p id="dispResult" class=" ">Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-info btn-sm" onclick="varLetExample()">Click Here</button>
              </div>
            </div>
        
            <div class="row mt-3">
              <div class="col-12">
                <div class="row">
                  <div class="col-6">
                    <div class="form-group">
                      <label for="num1Multi">Number 1</label>
                      <input type="text" name="num1Multi" id="num1Multi" class="form-control" placeholder="Enter Number 1">
                      <small id="errNumMulti1" class="text-muted"></small>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="form-group">
                      <label for="num2Multi">Number 2</label>
                      <input type="text" name="num2Multi" id="num2Multi" class="form-control" placeholder="Enter Number 1">
                      <small id="errNumMulti2" class="text-muted"></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 mt-2">
                <p class=" " id="disArrowData"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="multiExample()">Multiply</button>
              </div>
            </div>
        
        
            <div class="row mt-3">
              <div class="col-12 mt-2">
                <p class=" " id="disForData"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="forOfFunction()">Display Data</button>
              </div>
            </div>
        
            <div class="row mt-3">
              <div class="col-12 mt-2">
                <p class=" " id="disStringTemp"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="stringTemplate()">Display Data</button>
              </div>
            </div>
        
            <div class="row mt-3">
              <div class="col-12 mt-2">
                <p class=" " id="disTaggedStringTemp"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="taggedTemplate()">Display Data</button>
              </div>
            </div>
        
        
            <div class="row mt-3">
              <div class="col-12 mt-2">
                <p> Swap Value From fname = Doe, lname = John to fname = John, lname = Doe </p>
              </div>
              <div class="col-12 mt-2">
                <p class=" " id="disSwapTemp"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="swapValue()">Display Data</button>
              </div>
            </div>
        
        
            <div class="row mt-3">
              <div class="col-12 mt-2">
                <p class=" " id="dispEmp"> Result Display Here</p>
              </div>
              <div class="col-12">
                <button class="btn btn-primary btn-sm" onclick="objConverter()">Display Employee</button>
              </div>
            </div>
        
        
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
  <script>
    replaceText();
  </script>
<?php include '../footer.php' ?>