<?php include '../header.php' ?>


  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="container my-3">
            <div class="row justify-content-center">
              <div class="col-11  mt-2">
                <div class="card text-left">
                  <div class="card-header"> </div>
                  <div class="card-body">
        
                    <!-- Task 1 -->
                    <div class="row">
                      <h6><strong>Task 1 :</strong>  Define a function called callback which receives an argument and prints the square
                        of that number.</h6>
                      <hr>
                      <div class="col-sm-12 col-md-6 ">
                        <div class="form-group">
                          <label for="inpT1">Enter Number : </label>
                          <input type="number" name="inpT1" id="inpT1" class="form-control" min="0" placeholder="Enter Number">
                          <small class="text-muted" id="resultT1"></small>
                        </div>
                      </div>
                      <div class="col-12 mt-3">
                        <button class="btn btn-primary" onclick="taskOne()">Execute</button>
                      </div>
                    </div>
        
                    <!-- Task 2 -->
                    <div class="row mt-3">
                      <h6><strong>Task 2 :</strong> Explain difference between var and let keyword using example.</h6>
                      <hr>
                      <div class="col-sm-12 col-md-6 ">
                        <div class="form-group">
                          <label for="inpT2">Enter Text : </label>
                          <input type="text" name="inpT2" id="inpT2" class="form-control" placeholder="Enter Text">
                          <p> Global : <small class="text-muted" id="resultT2"></small></p>
                          <p> Inside Block : <small class="text-muted" id="resultT2block"></small></p>
                        </div>
                      </div>
                      <div class="col-12 mt-3">
                        <button class="btn btn-primary" onclick="checkGlobVar()">Check usign Var</button>
                        <button class="btn btn-primary" onclick="checkGlobLet()">Check usign Let</button>
                      </div>
                    </div>
        
                    <!-- Task 3 -->
                    <div class="row mt-3">
                      <h6><strong>Task 3 :</strong> Make a function that takes in a single parameter and returns a new promise. using setTimeout, after 500 milliseconds, the promise will either resolove or reject. if the input is a string, the promise resolves with that reverse string . if the input is anything but a string it rejects with that same input call the function wrong Input</h6>
                      <hr>
                      <div class="col-sm-12 col-md-6 ">
                        <div class="form-group">
                          <label for="inpT3">Enter Text : </label>
                          <input type="text" name="inpT3" id="inpT3" class="form-control" placeholder="Enter Text">
                          <small class="text-muted" id="resultT3"></small>
                        </div>
                      </div>
                      <div class="col-12 mt-3">
                        <button class="btn btn-primary" onclick="checkStr()">Check String</button>
                      </div>
                    </div>
        
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
<?php include '../footer.php' ?>