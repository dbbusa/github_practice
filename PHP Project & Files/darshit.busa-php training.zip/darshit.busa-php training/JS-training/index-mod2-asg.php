<?php include '../header.php' ?>


  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main">
        <div class="container mt-3 text-dark">
          <div class="row justify-content-center">
            <div class="col-10  mt-2">
              <div class="card text-left">
                <div class="card-header"> Validate Date</div>
                <div class="card-body">
                  <div class="col-sm-12 col-md-6">
                    <div class="form-group">
                      <label for="num1">Please Enter Date :</label>
                      <input type="text" name="dateVal" id="dateVal" class="form-control" placeholder="MM-DD-YYYY"
                        required>
                      <small class="text-muted">MM-DD-YYYY</small>
                    </div>
                  </div>
                  <div class="col-12 mt-3">
                    <button type="button" class="btn btn-success" onclick="validateDate()">Validate</button>
                  </div>
                </div>
                <div class="card-footer text-center">
                  <p id="result">Status </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
  <?php include '../footer.php' ?>