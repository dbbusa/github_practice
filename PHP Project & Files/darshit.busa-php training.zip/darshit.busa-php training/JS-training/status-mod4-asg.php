<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main">
        <div class="mt-3 text-dark">
          
          <div class="container my-3">
            <div class="row justify-content-center">
              <div class="col-12">
        
              </div>
              <div class="col-11  mt-2">
                <div class="card text-left">
                  <div class="card-header fw-bold">
                    Exam Status
                  </div>
                  <div class="card-body">
        
                    <div id="beforeTime" class="d-block">
                      <div class="row justify-content-center">
                        <p class="fw-bold text-left">
                          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora doloribus odio id accusantium blanditiis numquam temporibus optio quos odit impedit dignissimos sunt, minima molestias accusamus sapiente cumque harum. Obcaecati, illo?
                        </p>
                        <h5 class="text-center mt-2"> Result Will Be Declared Soon</h5>
                      </div>
                    </div>
        
                  </div>
                </div>
              </div>
            </div>
          </div>       

        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
 <?php include '../footer.php' ?>