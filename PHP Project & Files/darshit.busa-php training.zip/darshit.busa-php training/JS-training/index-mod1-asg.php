<?php include '../header.php' ?>

    <section id="mainSection">
        <div class="row">
            <?php include 'sidebar.php' ?>
            <div class="main">
                <div class="container mt-3 text-dark">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <h6 class="">Aim : Create an application for performing basic math operations like Addition,
                                Subtraction, Multiplication and Division.</h6>
                        </div>
                        <div class="col-10  mt-2">
                            <div class="card text-left">
                                <div class="card-header"> Calculate</div>
                                <div class="card-body">
                                    <form id="formCalc">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-6">
                                                <div class="form-group">
                                                    <label for="num1">Please enter first number :</label>
                                                    <input type="text" name="num1" id="num1" class="form-control"
                                                        placeholder="Enter Number 1" required>
                                                    <small class="text-muted">Should be Number</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-6">
                                                <div class="form-group">
                                                    <label for="num2">Please enter second number : </label>
                                                    <input type="text" name="num2" id="num2" class="form-control"
                                                        placeholder="Enter Number 2" required>
                                                    <small class="text-muted">Should be Number</small>
                                                </div>
                                            </div>
                                            <div class="col-12 mt-3">
                                                <div class="form-group">
                                                    <label for="operation">Please select operation you want to perform : </label>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                            <input type="radio" class="form-check-input" name="operation"
                                                                id="operator" value="add" required>
                                                            Addition
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                            <input type="radio" class="form-check-input" name="operation"
                                                                id="operator" value="sub" required>
                                                            Subtraction
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                            <input type="radio" class="form-check-input" name="operation"
                                                                id="operator" value="mul" required>
                                                            Multiplication
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                            <input type="radio" class="form-check-input" name="operation"
                                                                id="operator" value="div" required>
                                                            Division
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 mt-3">
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <button type="button" class="btn btn-primary" onclick="calculate()">Calculate</button>
                                                    <button type="button" class="btn btn-danger" onclick="resetForm()">Reset</button>
                                                  </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center">
                                    <p id="result">Result is : </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="../assets/js/custom.js"></script>
<?php include '../footer.php' ?>