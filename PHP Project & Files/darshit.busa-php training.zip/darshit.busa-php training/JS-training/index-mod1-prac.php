<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main">
        <div class="container mt-3 text-dark">
          <div class="row justify-content-center">
            <div class="col-12">
              <h6 class="">Aim : Accept three numbers from the user using prompt, find the greater of these
                the numbers and do the sum of that numbers which are greater than 40.</h6>
            </div>
            <div class="col-12 text-center mt-2">
              <button class="btn btn-primary" onclick="btnInpValue()">Click to Insert Value</button>
            </div>
          </div>
        </div>

        <div class="container my-3">
          <div class="row justify-content-center">
            <div class="col-12">
              <h6 class="">Aim : Declare array with 5 city names and iterate these values with the help of
                loop and display it with alert.</h6>
            </div>
            <div class="col-12 text-center mt-2">
              <button class="btn btn-primary" onclick="printCityName()">Get Cities</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/mod1-prac.js"></script>
<?php include '../footer.php' ?>