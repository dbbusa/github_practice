<div class="side">
                <h3 class="text-center">Learning</h3>

                <ul class="dropdown-ul">
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module1"
                            role="button" aria-expanded="false" aria-controls="module1">
                            Module 1
                        </a>
                        <ul class="collapse sub-dropdown" id="module1">
                            <li><a class="module-item" href="index-mod1-asg.php">Assignment</a></li>
                            <li><a class="module-item" href="index-mod1-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module2"
                            role="button" aria-expanded="false" aria-controls="module2">
                            Module 2
                        </a>
                        <ul class="collapse sub-dropdown" id="module2">
                            <li><a class="module-item" href="index-mod2-asg.php">Assignment</a></li>
                            <li><a class="module-item" href="index-mod2-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module3"
                            role="button" aria-expanded="false" aria-controls="module3">
                            Module 3
                        </a>
                        <ul class="collapse sub-dropdown" id="module3">
                            <li><a class="module-item" href="index-mod3-asg.php">Assignment</a></li>
                            <li><a class="module-item" href="index-mod3-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module4"
                            role="button" aria-expanded="false" aria-controls="module4">
                            Module 4
                        </a>
                        <ul class="collapse sub-dropdown" id="module4">
                            <li><a class="module-item" href="index-mod4-asg.php">Assignment</a></li>
                            <li><a class="module-item" href="index-mod4-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module5"
                            role="button" aria-expanded="false" aria-controls="module5">
                            Module 5
                        </a>
                        <ul class="collapse sub-dropdown" id="module5">
                            <li><a class="module-item" href="index-mod5-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module6"
                            role="button" aria-expanded="false" aria-controls="module6">
                            Module 6
                        </a>
                        <ul class="collapse sub-dropdown" id="module6">
                            <li><a class="module-item" href="index-mod6-prac.php">Practice</a></li>
                            <li><a class="module-item" href="index-mod6-asg.php">Assignment</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module7"
                            role="button" aria-expanded="false" aria-controls="module7">
                            Module 7
                        </a>
                        <ul class="collapse sub-dropdown" id="module7">
                            <li><a class="module-item" href="index-mod7-prac.php">Practice</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module8"
                            role="button" aria-expanded="false" aria-controls="module8">
                            Additional
                        </a>
                        <ul class="collapse sub-dropdown" id="module8">
                            <li><a class="module-item" href="index-additional-prac1.php">Practice - 1</a></li>
                            <li><a class="module-item" href="index-additional-prac2.php">Practice - 2</a></li>
                        </ul>
                    </li>
                </ul>
            </div>