<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="containers">
            <h3 class="text-center  ">Practice Exercise From W3School</h3>
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use the getElementById method to find the &lt;p&gt; element, and change its text to
                "Hello"</h5>
              <p style="color: #888;" id="demo"></p>
              <button class="btn btn-primary btn-sm" onclick="exercise1()">Exercise 1</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use the getElementsByTagName method to find the first &lt;p&gt; element, and change
                its text to "Hello".</h5>
              <button class="btn btn-primary btn-sm" onclick="exercise2()">Exercise 2</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use HTML DOM to change the value of the image's src attribute.</h5>
              <img id="image" src="https://www.w3schools.com/js/pic_bulboff.gif" alt="image">
              <button class="btn btn-primary btn-sm" onclick="exercise3()">Exercise 3</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use HTML DOM to change the value of the input field.</h5>
              <input type="text" id="myText" value="Hello">
              <button class="btn btn-primary btn-sm" onclick="exercise4()"> Exercise 4</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Change the text color of the &lt;p&gt; element to "red".</h5>
              <button class="btn btn-primary btn-sm" onclick="exercise5()">Exercise 5</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use the CSS display property to hide the p element.</h5>
              <button class="btn btn-primary btn-sm" onclick="exercise6()">Exercise 6</button>
            </div>
          </div>
        
          <div class="containers">
            <h3 class="text-center  ">Practice Exercise From Tutorial Site</h3>
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use Window.location object to navigate on another page</h5>
        
              
              <button class="btn btn-primary btn-sm" onclick="indexPage()">Index</button>
              <button class="btn btn-primary btn-sm" onclick="page1()">Page1</button>
              <button class="btn btn-primary btn-sm" onclick="page2()">Page2</button>
            </div>
        
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Use Window.history object to move to previous url in the history list</h5>
        
              <button class="btn btn-primary btn-sm" onclick="moveBack()">Previous URL</button>
            </div>
        
            <div class="col-12 mt-2">
              <h5 class="">Aim: Try to change windows height and width using Windows object</h5>
        
              <button class="btn btn-primary btn-sm" onclick="openWindow()">Open Window</button>
              <button class="btn btn-primary btn-sm" onclick="resizeWindow()">Resize Window</button>
            </div>
        
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
  <?php include '../footer.php' ?>