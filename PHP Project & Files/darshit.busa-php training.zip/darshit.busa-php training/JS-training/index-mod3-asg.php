<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="container my-2">
            <div class="row justify-content-center">
              <div class="col-12">
                <h6 class="">Aim : Design a form for storing employee details. (EmployeeID, Employee name, age, Gender, designation, salary, location, Email ID, Date of Joining and contact number)</h6>
              </div>
              <div class="col-12 mt-2">
                <div class="card text-left">
                  <div class="card-header"> Employee Details</div>
                  <div class="card-body">
                    <form id="formCalc" onsubmit="return validateData()">
                      <div class="row">
                        <div class="col-sm-12 col-md-6 px-2">
                          <div class="form-group">
                            <label for="empId">Employee ID</label>
                            <input type="text" name="empId" id="empId" class="form-control" placeholder="EmployeeID">
                            <small class="text-danger" id="errEmpId"></small>
                          </div>
                        </div>
        
                        <div class="col-sm-12 col-md-6 px-2">
                          <div class="form-group">
                            <label for="empName">Employee Name</label>
                            <input type="text" name="empName" id="empName" class="form-control" placeholder="Employee Name">
                            <small class="text-danger" id="errEmpName"></small>
                          </div>
                        </div>
        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empAge">Employee Age</label>
                            <input type="text" name="empAge" id="empAge" class="form-control" placeholder="Employee Age">
                            <small class="text-danger" id="errEmpAge"></small>
                          </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empGender">Employee Gender</label>
                            <div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="empGender" id="empGender1" value="male">
                                <label class="form-check-label" for="empGender">Male</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="empGender" id="empGender2" value="female">
                                <label class="form-check-label" for="empGender">Female</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="empGender" id="empGender3" value="other">
                                <label class="form-check-label" for="empGender">Other</label>
                              </div>
                            </div>
                            <small class="text-danger" id="errEmpGender"></small>
                          </div>
                        </div>
        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empDesignation">Employee Designation</label>
                            <input type="text" name="empDesignation" id="empDesignation" class="form-control" placeholder="Employee Designation">
                            <small class="text-danger" id="errEmpDesignation"></small>
                          </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empSalary">Employee Salary</label>
                            <input type="text" name="empSalary" id="empSalary" class="form-control" placeholder="Employee Salary">
                            <small class="text-danger" id="errEmpSalary"></small>
                          </div>
                        </div>
        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empLocation">Employee Location</label>
                            <select name="empLocation" id="empLocation" class="form-control">
                              <option value="" readonly disabled selected>Select Location...</option>
                              <option value="rajkot">Rajkot</option>
                              <option value="surat">Surat</option>
                              <option value="pune">Pune</option>
                              <option value="mumbai">Mumbai</option>
                            </select>
                            <small class="text-danger" id="errEmpLocation"></small>
                          </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empEmail">Employee Email</label>
                            <input type="text" name="empEmail" id="empEmail" class="form-control" placeholder="Employee Email">
                            <small class="text-danger" id="errEmpEmail"></small>
                          </div>
                        </div>
        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empDOJ">Employee Date of Joining</label>
                            <input type="text" name="empDOJ" id="empDOJ" class="form-control" placeholder="Employee Date of Joining">
                            <small class="text-danger" id="errEmpDOJ"></small>
                          </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 px-2 mt-3">
                          <div class="form-group">
                            <label for="empContact">Employee Contact</label>
                            <input type="text" name="empContact" id="empContact" class="form-control" placeholder="Employee Contact">
                            <small class="text-danger" id="errEmpContact"></small>
                          </div>
                        </div>
        
                        <div class="col-12 mx-2 mt-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
        
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
<?php include '../footer.php' ?>