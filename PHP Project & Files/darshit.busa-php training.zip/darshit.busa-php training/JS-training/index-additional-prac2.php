<?php include '../header.php' ?>
<section id="mainSection">
  <div class="row">
    <?php include 'sidebar.php' ?>
    <div class="main js-mod2-prac">
      <div class="mt-3 text-dark">

        <div class="container">
          <div class="col-12  mt-2">
            <h4 class="fw-bold text-center">Practice</h4>
            <div class="card text-left">
              <div class="card-body">

                <div class="row mt-2">
                  <div class="col-sm-12 col-md-4">
                    <h5 class="text-center">Product 1 Array</h5>
                    <h6 id="resultProd1Array"></h6>
                  </div>
                  <div class="col-sm-12 col-md-4">
                    <h5 class="text-center">Product 2 Array</h5>
                    <h6 id="resultProd2Array"></h6>
                  </div>
                  <div class="col-sm-12 col-md-4">
                    <h5 class="text-center">Output Array</h5>
                    <h6 id="resultOutArray"></h6>
                  </div>
                  <div class="col-12">
                    <div class="row">
                      <div class="col-sm-12 col-md-4 my-2 text-center">
                        <button class="btn btn-primary btn-sm" onclick="pushElementArray()">Push Element in
                          array</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 text-center">
                        <button class="btn btn-primary btn-sm" onclick="popElementArray()">Pop Element from
                          array</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 text-center">
                        <button class="btn btn-primary btn-sm" onclick="concatArrays()">Merge 2
                          Arrays</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 text-center">
                        <button class="btn btn-primary btn-sm" onclick="fillArray()">Fill Array with
                          Null</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="listBothArray()">List
                          Arrays</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="checkIfArray()">Check if
                          Array</button>
                      </div>
                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="joinArray()">Join Elements by _
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="lengthArray()">Length of each Array
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="reverseAllItem()">Reverse Items
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="applyPrototypeArray()">Apply Prototype
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="reduceArray()">Reduce Array
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="reduceRightArray()">Reduce from Right Array
                        </button>
                      </div>

                      <div class="col-sm-12 col-md-4 my-2 w-full text-center">
                        <button class="btn btn-primary btn-sm" onclick="spliceArray()">Splice Array
                        </button>
                      </div>

                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
<script src="../assets/js/script-additional-prac2.js"></script>
<?php include '../footer.php' ?>