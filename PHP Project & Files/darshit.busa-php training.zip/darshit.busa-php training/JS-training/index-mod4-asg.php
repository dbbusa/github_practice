<?php include '../header.php' ?>


  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="container my-3">
            <div class="row justify-content-center">
              <div class="col-12">

              </div>
              <div class="col-11 mt-2">
                <h6 class=""><strong>Aim :</strong> University of Mumbai needs to set an online exam for their
                  students. For that they need to set a timer for three hours. After 3 hours exams should be finished.
                </h6>
                <div class="card text-left">
                  <div class="card-header fw-bold">
                    Exam Form
                    <span class="float-end">
                      <svg xmlns="http://www.w3.org/2000/svg" style="width:25px;" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span class="fw-bold" id="timer"></span>
                      <span class="fw-bold text-danger d-none" id="showMsg">Exam Finished</span>
                    </span>
                  </div>
                  <div class="progress">
                    <div class="progress-bar bg-primary" id="progressBar" role="progressbar" aria-valuenow="0"
                      aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <div class="card-body">

                    <div id="beforeTime" class="d-block">
                      <div class="row justify-content-center">
                        <p class="fw-bold text-left">
                          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora doloribus odio id accusantium
                          blanditiis numquam temporibus optio quos odit impedit dignissimos sunt, minima molestias
                          accusamus sapiente cumque harum. Obcaecati, illo?
                        </p>
                        <ul class="ms-5">
                          <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum, quidem.</li>
                          <li>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laborum possimus doloribus
                            doloremque ex quas quaerat.</li>
                          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo quos beatae neque?</li>
                        </ul>

                        <div class="text-center">
                          <button class="btn btn-primary" onclick="displayTimerClock()">Start Exam</button>
                        </div>
                      </div>
                    </div>

                    <div id="mcqSection" class="row d-none">

                      <div class="col-12 mt-3">
                        <h6>Q1. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus, vitae? </h6>
                        <div class="row col-8 justify-content-center">

                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q1Option" id="q1OprionA" value="1">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q1Option" id="q1OprionB" value="2">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q1Option" id="q1OprionC" value="3">
                                Lorem.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q1Option" id="q1OprionD" value="4">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-12 mt-3">
                        <h6>Q2. Lorem ipsum dolor sit amet consectetur Lorem, ipsum dolor, adipisicing elit.
                          Voluptatibus,
                          vitae? </h6>
                        <div class="row col-8 justify-content-center">

                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q2Option" id="q2OprionA" value="1">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q2Option" id="q2OprionB" value="2">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q2Option" id="q2OprionC" value="3">
                                Lorem.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q2Option" id="q2OprionD" value="4">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-12 mt-3">
                        <h6>Q3. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus, Lorem ipsum dolor
                          sit
                          vitae? </h6>
                        <div class="row col-8 justify-content-center">

                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q3Option" id="q3OprionA" value="1">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q3Option" id="q3OprionB" value="2">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q3Option" id="q3OprionC" value="3">
                                Lorem.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q3Option" id="q3OprionD" value="4">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-12 mt-3">
                        <h6>Q4. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus, Lorem adipisicing
                          elit.
                          Voluptatibus, vitae? </h6>
                        <div class="row col-8 justify-content-center">

                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q4Option" id="q4OprionA" value="1">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q4Option" id="q4OprionB" value="2">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q4Option" id="q4OprionC" value="3">
                                Lorem.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q4Option" id="q4OprionD" value="4">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-12 mt-3">
                        <h6>Q5. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus, vitae?
                          Lorem.............
                        </h6>
                        <div class="row col-8 justify-content-center">

                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q5Option" id="q5OprionA" value="1">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q5Option" id="q5OprionB" value="2">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q5Option" id="q5OprionC" value="3">
                                Lorem.
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-6">
                            <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="q5Option" id="q5OprionD" value="4">
                                Lorem,
                                ipsum.
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="text-center mt-3">
                        <button class="btn btn-primary" onclick="finishExam()">Submit Exam</button>
                      </div>

                    </div>

                    <div id="afterTime" class="d-none">
                      <div class="row show justify-content-center">
                        <img src="../assets/image/clock.png" alt="Clock" class="img-fluid w-25">
                      </div>
                      <div class="w-100 fw-bold mt-3 text-center">
                        Time Up Your Exam is Automatically Submitted.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title fw-bold" id="exampleModalLabel">Tik Tik</h5>
                  <button class="btn btn-default fs-5" onclick="dismissModal()" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body fw-bold text-center">
                  <div class="row justify-content-center">
                    <img src="../assets/image/clock.png" alt="Clock" class="img-fluid w-25">
                  </div>
                  <div class="w-100 mt-3 text-center">
                    Hurry up you have only 5 minutes time left.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
<?php include '../footer.php' ?>