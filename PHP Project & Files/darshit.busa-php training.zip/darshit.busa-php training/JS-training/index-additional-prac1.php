<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?> 
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          <div class="container">
            <div class="col-12  mt-2">
              <h4 class="fw-bold text-center">Practice</h4>
              <div class="card text-left">
                <div class="card-body">
        
                  <div class="row">
                    <label for="decNum">Enter Decimal Number</label>
                    <input type="text" name="decNumber" id="decNum" class="form-control" placeholder="Enter Decimal Number" />
                    <small id="resultInv"></small>
                  </div>
                  <div class="row mt-3">
                    <button id="checkInverse" class="btn btn-primary btn-sm" onclick="checkInvRes()">Check</button>
                  </div>
        
                  <div class="row mt-3">
                    <div id="resApiData" class="row"></div>
                    <button id="apiData" class="btn btn-primary btn-sm mt-2" onclick="getApiData()">Get Data</button>
                  </div>
        
                  <div class="row mt-3">
                    <div class="col-6 px-1">
                      <label for="inpNumber1">Enter Number 1</label>
                      <input type="text" name="numbers1" class="form-control" id="inpNumber1" placeholder="Enter Number 1">
                    </div>
                    <div class="col-6 px-1">
                      <label for="inpNumber2">Enter Number 2</label>
                      <input type="text" name="numbers2" class="form-control" id="inpNumber2" placeholder="Enter Number 2">
                    </div>
                    <span class="text-muted" id="resDataFunExp"></span>
                    <button id="apiData" class="btn btn-primary btn-sm mt-2" onclick="sumWithExpression()">Sum</button>
                  </div>
        
                  <div class="row mt-3 justify-content-center">
                    <div id="resDataObj">
        
                    </div>
        
                    <button id="apiData" class="btn btn-primary btn-sm mt-2" onclick="objectHandle()">Get Object Data</button>
                  </div>
                  <div class="row mt-3">
                    <div class="col-6 px-1">
                      <label for="inpString1Box">Enter String 1</label>
                      <input type="text" name="textInput" id="inpString1Box" placeholder="Enter String 1"
                        class="form-control" />
                    </div>
        
                    <div class="col-6 px-1">
                      <label for="inpString2Box">Enter String 2</label>
                      <input type="text" name="textInput" id="inpString2Box" placeholder="Enter String 2"
                        class="form-control" />
                    </div>
                    <div class="col-12 mt-2">
                      <small id="statusMsg" class="text-muted"></small>
                    </div>
                    <div class="col-12 mt-2">
                      <button class="btn btn-primary btn-sm" id="btnCheckProm" onclick="matchWithProm()">Click To Match</button>
                    </div>
                  </div>
        
                  <div class="row mt-3 justify-content-center">
                    <div class="col-12">
                      <input type="number" id="inpStrNum" placeholder="Enter Number" class="form-control" />
                    </div>
                    <small id="resDataSum"></small>
                    <button class="btn btn-primary btn-sm mt-2" onclick="sumOfNNumer()">Get Sum of N Number</button>
                  </div>
        
        
                  <div class="row mt-3 justify-content-center">
                    <div class="col-12">
                      <label for="">Enter Mobile Number in ***-***-**** Formate</label>
                      <input type="text" id="inpMobNum" placeholder="Enter Number" class="form-control" />
                    </div>
                    <small id="resMobileNum"></small>
                    <button class="btn btn-primary btn-sm mt-2" onclick="checkForMob()">Validate Mobile Number</button>
                  </div>
        
                  <div class="row">
                    <button class="mt-3 btn btn-primary btn-sm" id="timeRep" onclick="btnGetDate()">Current Time</button>
                    <button class="mt-3 btn btn-primary btn-sm" id="currentYear" onclick="btnGetDateYear()">Current Year</button>
                  </div>
                  
                  <div class="row mt-3">

                    <div id="resultDataEmp1"></div>
                    <div id="msgDivider"></div>
                    <div id="resultDataEmp2"></div>

                    <button class="mt-3 btn btn-primary btn-sm" id="functionCall" onclick="FuncPractice()">Function Call</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script type="text/javascript" src="../assets/js/custom.js"></script>
  <?php include '../footer.php' ?>