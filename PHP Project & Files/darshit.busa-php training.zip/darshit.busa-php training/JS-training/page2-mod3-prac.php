<?php include '../header.php' ?>

    <section id="mainSection">
      <div class="row">
        <?php include 'sidebar.php' ?>
        <div class="main">
          <div class="mt-3 text-dark">
            
            <div class="container">
              <div class="containers">
                  <h3 class="text-center  ">Practice Exercise From Tutorial Site</h3>
                  <div class="col-12 mt-2">
                      <h5 class="">Aim: Use Window.location object to navigate on another page</h5>
      
      
                      <button class="btn btn-primary btn-sm" onclick="indexPage()">Index</button>
                      <button class="btn btn-primary btn-sm" onclick="page1()">Page1</button>
                      <button class="btn btn-primary btn-sm" onclick="page2()">Page2</button>
                  </div>
              </div>
          </div>

          </div>
        </div>
      </div>
    </section>
    <script src="../assets/js/custom.js"></script>
<?php
  include '../footer.php'
?>