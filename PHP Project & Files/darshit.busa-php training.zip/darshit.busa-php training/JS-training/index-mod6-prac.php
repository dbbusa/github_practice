<?php include '../header.php' ?>
  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main">
        <div class="mt-3 text-dark">
          <div class="container">
            <div class="row justify-content-center mt-3">
              <div class="col-12">
                <div class="alert alert-primary fade d-none" role="alert" id="resError">
                  
                </div>
              </div>
              <div class="col-11  mt-2">
                <div class="card text-left">
                  <div class="card-header fw-bold">
                    Practice
                  </div>
                  <div class="card-body">
        
                    <!-- Task 1 -->
                    <div class="row">
                      <div class="col-12">
                        <h6><strong>Task 1:</strong> Store following JSON data into localstorage,read that data and print it
                          into console.</h6>
                        <hr>
                      </div>
                      <div class="col-12">
                        <div class="m-2" id="result">
        
                        </div>
                        <button class="btn btn-dark btn-sm" onclick="getDataJson()">Get Data</button>
                      </div>
                    </div>
        
                    <!-- Task 2 -->
                    <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 2:</strong> Keep above JSON Data into a file, using Web Fetch API read that data.</h6>
                        <hr>
                      </div>
                      <div class="col-12">
                        <div class="m-2" id="resultT2">
        
                        </div>
                        <button class="btn btn-dark btn-sm" onclick="fetchDataFile()">Fetch Data</button>
                      </div>
                    </div>
        
        
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/custom.js"></script>
  <?php include '../footer.php' ?>