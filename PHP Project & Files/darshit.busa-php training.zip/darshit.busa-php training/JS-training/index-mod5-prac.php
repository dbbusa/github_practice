<?php include '../header.php' ?>
  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">
          
          <div class="container my-3">
            <div class="row justify-content-center">
              <div class="col-12">
        
              </div>
              <div class="col-11 mt-2">
                <div class="card text-left">
                  <div class="card-header fw-bold">
                    Practice
                  </div>
                  <div class="card-body">
        
                    <!-- Task 1 -->
                    <div class="row">
                      <div class="col-12">
                        <h6><strong>Task 1:</strong> Using Function Expression, find the area of circle</h6>
                        <hr>
                      </div>
                      <div class="col-12">
                        <input type="number" id="inpT1" class="form-control" placeholder="Enter Radius" />
                        <span class="text-muted my-2 d-block" id="resT1"></span>
                        <button class="btn btn-primary btn-sm mt-2" onclick="calculateCircle()">Calculate</button>
                      </div>
                    </div>
        
        
                    <!-- Task 2 -->
                    <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 2:</strong> Using Function Constructor, find the area of rectangle</h6>
                        <hr>
                      </div>
                      <div class="col-6 pe-2">
                        <input type="number" id="inpHeight" class="form-control" placeholder="Enter Height" />
                      </div>
                      <div class="col-6 pe-2">
                        <input type="number" id="inpWidth" class="form-control" placeholder="Enter Width" />
                      </div>
                      
                      <div class="col-12">
                        <span class="text-muted my-2 d-block" id="resT2"></span>
                        <button class="btn btn-primary btn-sm mt-2" onclick="calculateRactangle()">Calculate</button>
                      </div>
                    </div>
        
                    <!-- Task 3 -->
                    <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 3:</strong> Explain usage of Function Hosing using example</h6>
                        <hr>
                      </div>
                      <div class="col-6 pe-2">
                        <input type="number" id="inpVal1" class="form-control" placeholder="Enter Value 1" />
                      </div>
                      <div class="col-6 pe-2">
                        <input type="number" id="inpVal2" class="form-control" placeholder="Enter Value 2" />
                      </div>
                      
                      <div class="col-12">
                        <span class="text-muted my-2 d-block mt-2" id="resT3"></span>
                        <button class="btn btn-primary btn-sm mt-2" onclick="submitTask3()">Submit</button>
                      </div>
                    </div>
        
                     <!-- Task 4 -->
                     <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 4:</strong> Using Function call create employee object with field Name, Address and Designation and pass it to function.</h6>
                        <hr>
                      </div>
                      <div class="col-6 pe-2 mt-2">
                        <input type="text" id="inpName" class="form-control" placeholder="Enter Name" />
                      </div>
                      <div class="col-6 pe-2 mt-2">
                        <input type="text" id="inpAddress" class="form-control" placeholder="Enter Address" />
                      </div>
                      <div class="col-6 pe-2 mt-2">
                        <input type="text" id="inpDeg" class="form-control" placeholder="Enter Designation" />
                      </div>
                      <div class="col-6 mt-2" id="resultEmp">
        
                      </div>
                      
                      <div class="col-12">
                        <button class="btn btn-primary btn-sm mt-2" onclick="employeeDetails()">Submit</button>
                      </div>
                    </div>
        
                    <!-- Task 5 -->
                    <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 5:</strong> Using Function Apply pass employee object to a function defined in the function.</h6>
                        <hr>
                      </div>
                      <div class="col-6 mt-2 pe-2">
                        <input type="text" id="inpT5Name" class="form-control" placeholder="Enter Name" />
                      </div>
                      <div class="col-6 mt-2 pe-2">
                        <input type="text" id="inpT5Address" class="form-control" placeholder="Enter Address" />
                      </div>
                      <div class="col-6 mt-2 pe-2">
                        <input type="text" id="inpT5Deg" class="form-control" placeholder="Enter Designation" />
                      </div>
                      <div class="col-6 mt-2" id="resultT5Emp">
        
                      </div>
                      
                      <div class="col-12">
                        <button class="btn btn-primary btn-sm mt-2" onclick="empDetailsT5()">Submit</button>
                      </div>
                    </div>
        
                    <!-- Task 6 -->
                    <div class="row mt-3">
                      <div class="col-12">
                        <h6><strong>Task 6:</strong> Explain Function closure with practical</h6>
                        <hr>
                      </div>
                      <div class="col-6">
                        <p>Without using Function Closure</p>
                        <span id="resT6noClosure" class="text-muted d-block mt-2"></span>
                        <button id="btnNoClosure" class="btn btn-primary btn-sm mt-2" onclick="noClosure()">Click</button>
                      </div>
                      <div class="col-6">
                        <p>Using Function Closure</p>
                        <span id="resT6Closure" class="text-muted d-block mt-2"></span>
                        <button id="btnNoClosure" class="btn btn-primary btn-sm mt-2" onclick="withClosure()">Click</button>
                      </div>
        
                    </div>
        
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/script-mod5-prac.js"></script>
  <?php include '../footer.php' ?>