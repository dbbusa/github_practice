<?php
include '../header.php';
?>
<section id="mainSection">
    <div class="row">
       <?php include 'sidebar.php'; ?>
        <div class="main html_mod1_asg" id="content">
            <section id="registration">
                <div class="card">
                    <div class="card-header">
                        <h4> Register Yourself</h4>
                    </div>
                    <div class="card-body">
                        <form action="">
                            <div class="form-part">
                                <div class="row">
                                    <label for="employeeName">Employee Name</label>
                                    <input type="text" id="employeeName" class="input-control" placeholder="Employee Name" required />
                                </div>
                                <div class="row">
                                    <label for="emailid">EmailID</label>
                                    <input type="email" name="emailid" id="emailid" class="input-control" placeholder="EmailID" required />
                                </div>
                                <div class="row">
                                    <label for="designation">Designation</label>
                                    <input type="designation" id="designation" class="input-control" placeholder="Designation" required />
                                </div>
                            </div>
                            <div class="form-part">
                                <div class="row">
                                    <label for="age">Age</label>
                                    <input type="number" name="age" class="input-control" id="age" pattern="[0-9]" min="0" max="100" placeholder="Age" title="Numeric Value" required />
                                </div>
                                <div class="row">
                                    <label for="contactno">Contact Number</label>
                                    <input type="text" name="contactno" id="contactno" class="input-control" placeholder="Contact Number" required />
                                </div>
                                <div class="row">
                                    <label for="gender">Gender</label>
                                    <div class="">
                                        <input type="radio" name="gender" id="genderMale" value="male" required />
                                        Male
                                        <input type="radio" name="gender" id="genderFemale" value="female" required /> Female
                                        <input type="radio" name="gender" id="genderOther" value="other" required />
                                        Other
                                    </div>
                                </div>
                            </div>
                            <div class="form-part">
                                <div class="row">
                                    <label for="salary">Salary</label>
                                    <input type="text" name="salary" id="salary" class="input-control" placeholder="Salary" required />
                                </div>
                                <div class="row">
                                    <label for="dateofjoining">Date of Joining</label>
                                    <input type="date" name="dateofjoining" class="input-control" id="dateofjoining" required />
                                </div>
                                <div class="row">
                                    <label for="location">Location</label>
                                    <select name="location" id="location" class="input-control" required>
                                        <option value="" readonly disabled selected>Select Location...</option>
                                        <option value="rajkot">Rajkot</option>
                                        <option value="surat">Surat</option>
                                        <option value="mumbai">Mumbai</option>
                                        <option value="pune">Pune</option>
                                        <option value="ahmedabad">Ahmedabad</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <button class="btnSignup">Signup</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <span> Already Have Account?</span><a href="#">Login</a>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>
<?php 
    include '../footer.php';
?>