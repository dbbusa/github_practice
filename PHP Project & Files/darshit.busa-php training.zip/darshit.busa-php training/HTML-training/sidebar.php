<div class="side">
    <h3 class="text-center">Learning</h3>

    <ul class="dropdown-ul">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module1" role="button" aria-expanded="false" aria-controls="module1">
                Module 1
            </a>
            <ul class="collapse sub-dropdown" id="module1">
                <li><a class="module-item" href="index-mod1-assignment.php">Assignments</a></li>
                <li><a class="module-item" href="index-mod1_practice.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module2" role="button" aria-expanded="false" aria-controls="module2">
                Module 2
            </a>
            <ul class="collapse sub-dropdown" id="module2">
                <li><a class="module-item" href="index-mod2-assignment.php" target="_blank">Assignments</a></li>
            </ul>
        </li>
    </ul>
</div>
