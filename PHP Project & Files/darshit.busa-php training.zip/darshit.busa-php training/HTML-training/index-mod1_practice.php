<?php 
    include '../header.php'
?>
    <section id="mainSection">
        <div class="row">
            <?php 
                include 'sidebar.php';
            ?>
            <div class="main html_mod1_prc" id="content">

                <section id="NavigationBar">
                    <header>
                        <ul>
                            <li>
                                <nav aria-label="HomeLink"><a href="#">Home</a></nav>
                            </li>
                            <li>
                                <nav aria-label="AboutUsLink"><a href="#">AboutUs</a></nav>
                            </li>
                            <li>
                                <nav aria-label="ContactUsLink"><a href="#">ContactUs</a> </nav>
                            </li>
                            <li>
                                <nav aria-label="LoginLink"><a href="signin-mod1_practice.php">Login</a></nav>
                            </li>
                        </ul>
                    </header>
                </section>

                <section id="studentGrade">
                    <table>
                        <caption>Student Records</caption>
                        <thead>
                            <th>Name</th>
                            <th>Roll No</th>
                            <th>Year of Passing</th>
                            <th>Maths</th>
                            <th>Science</th>
                            <th>English</th>
                            <th>Grade</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td>101</td>
                                <td>John Doe</td>
                                <td>2019</td>
                                <td>78</td>
                                <td>82</td>
                                <td>70</td>
                                <td>A</td>
                            </tr>
                            <tr>
                                <td>102</td>
                                <td>Alexa Mark</td>
                                <td>2019</td>
                                <td>77</td>
                                <td>80</td>
                                <td>85</td>
                                <td>A+</td>
                            </tr>
                            <tr>
                                <td>103</td>
                                <td>Merry Parker</td>
                                <td>2019</td>
                                <td>89</td>
                                <td>90</td>
                                <td>88</td>
                                <td>A+</td>
                            </tr>
                            <tr>
                                <td>104</td>
                                <td>Alex Ray</td>
                                <td>2019</td>
                                <td>67</td>
                                <td>72</td>
                                <td>68</td>
                                <td>B+</td>
                            </tr>
                            <tr>
                                <td>105</td>
                                <td>Rose Jor-el</td>
                                <td>2019</td>
                                <td>65</td>
                                <td>60</td>
                                <td>68</td>
                                <td>B</td>
                            </tr>
                            <tr>
                                <td>106</td>
                                <td>Evens Gray</td>
                                <td>2019</td>
                                <td>80</td>
                                <td>75</td>
                                <td>79</td>
                                <td>B+</td>
                            </tr>
                        </tbody>
                    </table>
                </section>

                <section id="articles">
                    <article class="news">
                        <h1 id="title" title="News Update"> Latest News </h1>
                        <article class="news1">
                            <h2 title="Cryptocurrency">Cryptoverse: After Bitcoin 'Winter', Investors Hunt Risk in
                                Virtual Worlds</h2>
                            <p>As Bitcoin drifts towards mainstream maturity in 2022, daring crypto investors are eyeing
                                up new sources of explosive action: "altcoins" that power online games and worlds.

                                But, be warned, the foothills of the unformed metaverse are no place for the
                                faint-hearted.

                                Bitcoin, which like the rest of the market had been largely sinking since late 2021, has
                                risen about 16 percent over the past two weeks to push above $41,000 (roughly Rs. 30
                                lakh), prompting many market players to declare an end to the "cryptocurrency winter".
                            </p>
                        </article>

                        <article class="news1">
                            <h2 title="Internet">Pegasus Row: Israeli Police Used Spyware on Benjamin Netanyahu's Son,
                                Aides</h2>
                            <p>Israeli police illegally spied on the phones of former Prime Minister Benjamin
                                Netanyahu's son and members of his inner circle, a local newspaper reported Monday. The
                                report prompted a high-level investigation and threw the former leader's corruption
                                trial into disarray.

                                Netanyahu demanded a “strong and independent investigation” into the alleged police
                                misuse of sophisticated spyware against him, calling it a “black day for Israel” as
                                proceedings in his trial were put on hold.</p>
                        </article>
                    </article>
                </section>

                <section id="deptManage">
                    <h2 id="title" title="department hierarchy"> Department Hierarchy</h2>
                    <ul id="project">
                        <li><strong> Project 1 : </strong>
                            <ul>
                                <li>Manager :
                                    <ul class="child1">
                                        <li> Manager 1 :
                                            <ul class="child2">
                                                <li>Developers :
                                                    <ul class="child3">
                                                        <li>Developer 1</li>
                                                        <li>Developer 2</li>
                                                        <li>Developer 3</li>
                                                    </ul>
                                                </li>
                                                <li> Tester :
                                                    <ul class="child3">
                                                        <li> Tester 1</li>
                                                        <li> Tester 2</li>
                                                        <li> Tester 3</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li> <strong>Project 2 :</strong>
                            <ul>
                                <li>Manager :
                                    <ul class="child1">
                                        <li> Manager 2 :
                                            <ul class="child2">
                                                <li>Developers :
                                                    <ul class="child3">
                                                        <li>Developer 4</li>
                                                        <li>Developer 5</li>
                                                        <li>Developer 6</li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    Tester :
                                                    <ul class="child3">
                                                        <li> Tester 4</li>
                                                        <li> Tester 5</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </section>
            </div>
        </div>
    </section>
 <?php 
    include '../footer.php';
 ?>