<?php
include '../header.php';
?>
<section id="mainSection">
    <div class="row">
        <?php 
            include 'sidebar.php';
        ?>
        <div class="main html_mod1_prc" id="content">

            <section id="loginSection">
                <div class="card">
                    <div class="card-header">
                        <h4> Please Login</h4>
                    </div>
                    <div class="card-body">
                        <form action="">
                            <div class="row">
                                <label for="username">Username</label>
                                <input type="text" id="username" class="input-control" placeholder="Username" />
                            </div>
                            <div class="row">
                                <label for="password">Password</label>
                                <input type="password" id="password" class="input-control" placeholder="Password" />
                            </div>
                            <div class="row">
                                <button class="loginBtn"> Login </button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <a href="index-mod1_practice.php">Go Back To Home Page</a>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>
<?php
    include '../footer.php';
?>