<?php include '../header.php' ?>
<section id="mainSection">
    <div class="row">
        <?php include 'sidebar.php' ?>
        <div class="main jq-mod2-prac">
            <div class="mt-3 text-dark">

                <div class="container">
                    <div class="col-12  mt-2">
                        <h4 class="fw-bold text-center">Practice</h4>
                        <div class="card text-left">
                            <div class="card-body">

                                <div class="row mt-2">
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="showContent">Show
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="hideContent">Hide
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="toggleContent">Toggle
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="fadeInContent">Fade In
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="fadeOutContent">Fade Out
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="fadeToggleContent">Fade
                                            Toggle
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="fadeToContent">Fade to 40%
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="slideDownContent">Slide
                                            Down
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="slideUpContent">Slide Up
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="slideToggleContent">Slide
                                            Toggle
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="adnimateContent">Animate
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="effectStopContent">Stop
                                            Effect</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="chainingContent">ChainingContent
                                            Effect</button>
                                    </div>

                                </div>

                                <div class="row mt-2">
                                    <hr />
                                    <div class="col-12" id="LoremContent">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero
                                        dolorem aperiam
                                        doloremque exercitationem, recusandae dolores nisi minus saepe explicabo,
                                        consectetur unde
                                        commodi eligendi ipsam dolorum. Consectetur molestias minima nulla.
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur harum
                                        est sunt, nostrum
                                        recusandae aliquam repellat doloribus quos natus enim dolor necessitatibus
                                        incidunt
                                        laboriosam repudiandae soluta atque quisquam debitis numquam.
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt ab
                                        necessitatibus eos
                                        veniam dolorum eligendi quis temporibus, odio nihil sit, iure recusandae
                                        ipsum atque,
                                        assumenda libero laudantium voluptatem dolore tempore.
                                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Autem, consequatur
                                        ex aut est
                                        veniam eum iure harum nesciunt iste exercitationem facere doloremque
                                        quibusdam quasi quas
                                        voluptatem corporis. Quis, quibusdam in?
                                    </div>
                                </div>


                                <div class="row mt-2">
                                    <hr>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="appendContent">Append
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="prependContent">Prepend
                                            Content</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="beforeContent">Add Content
                                            Before</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="afterContent">Add Content
                                            After</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="removeContent">Remove
                                            Content</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="emptyContent">Empty Content
                                            Section</button>
                                    </div>

                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="addClassContent">Add
                                            text-primary</button>
                                    </div>
                                    <div class="col-6 col-md-2 my-1 ps-1">
                                        <button class="btn btn-primary btn-sm w-100" id="removeClassContent">Remove
                                            text-primary</button>
                                    </div>

                                </div>

                                <div class="row mt-2">
                                    <hr />
                                    <div class="col-12" id="LoremContent2">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero
                                        dolorem aperiam
                                        doloremque exercitationem, recusandae dolores nisi minus saepe explicabo,
                                        consectetur unde
                                        commodi eligendi ipsam dolorum. Consectetur molestias minima nulla.
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur harum
                                        est sunt, nostrum
                                        recusandae aliquam repellat doloribus quos natus enim dolor necessitatibus
                                        incidunt
                                        laboriosam repudiandae soluta atque quisquam debitis numquam.
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt ab
                                        necessitatibus eos
                                        veniam dolorum eligendi quis temporibus, odio nihil sit, iure recusandae
                                        ipsum atque,
                                        assumenda libero laudantium voluptatem dolore tempore.
                                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Autem, consequatur
                                        ex aut est
                                        veniam eum iure harum nesciunt iste exercitationem facere doloremque
                                        quibusdam quasi quas
                                        voluptatem corporis. Quis, quibusdam in?
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
</section>
<script src="../assets/js/script-jq-additional.js"></script>
<?php include '../footer.php' ?>