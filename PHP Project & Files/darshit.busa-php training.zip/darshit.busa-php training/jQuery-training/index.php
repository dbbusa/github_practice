<?php include '../header.php' ?>
    <section id="mainSection">
        <div class="row">
            <?php include "sidebar.php"; ?>
            <div class="main">
                <div class="row">
                    <h4><strong>Jquery</strong> </h4>
                    <hr />
                    <div class="image-container" id="addContent">
                        <img src="../assets/image/jquery.png" alt="JqueryLogos" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php include '../footer.php' ?>