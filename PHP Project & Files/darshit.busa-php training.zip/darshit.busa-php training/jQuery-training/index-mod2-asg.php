<?php include '../header.php' ?>

  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main js-mod2-prac">
        <div class="mt-3 text-dark">

          <div class="container">
            <div class="col-12  mt-2">
              <h6 class="">Task : Use getJSON method access this web api https://gorest.co.in/public-api/users
                and
                display the result in
                one table.</h6>
              <div class="card text-left">
                <div class="card-body">
                  <div class="row">
                    <table class="table table-bordered rounded table-striped table-responsive">
                      <caption class="d-none">Table Contains data Stored on API</caption>
                      <thead>
                        <tr>
                          <th>Id</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Gender</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody id="showDataHere"></tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/script-jquery-mod2-asg.js"></script>
  
<?php include '../footer.php' ?>