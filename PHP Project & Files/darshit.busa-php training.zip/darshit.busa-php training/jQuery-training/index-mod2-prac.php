<?php include '../header.php' ?>


  <section id="mainSection">
    <div class="row">
      <?php include 'sidebar.php' ?>
      <div class="main jq-mod2-prac">
        <div class="mt-3 text-dark">

          <div class="container">
            <div class="col-12  mt-2">
              <h6 class=""><strong>Aim :</strong> Do the hands on w3school.com</h6>
              <div class="card text-left">
                <div class="card-header fw-bold">
                  Practice
                </div>

                <div class="card-body">
                  <div class="row mt-2">
                    <!-- Task 1 -->
                    <div class="col-12">
                      <h5 class="text-center">jQuery Traversing & Ancestors & Descendants </h5>
                      <button class="btn btn-primary btn-sm" id="btnFindParent">Find Parent of Span </button>
                      <button class="btn btn-primary btn-sm" id="btnFindParents">Find Parents of Span </button>
                      <button class="btn btn-primary btn-sm" id="btnFindParentsUntil">Find Parents Until </button>

                      <button class="btn btn-primary btn-sm" id="btnFindChildren">Find Children</button>
                      <button class="btn btn-primary btn-sm" id="btnFindUsingFind">Find using Find</button>



                      <div class="task1 mt-3">
                        Main Div
                        <div class="findChildren">
                          <div>
                            1 div
                            <div>
                              <div>
                                1 div inside 1 main div
                                <span> Span Element</span>
                              </div>
                              <div>
                                2 div inside 1 main div
                                <span> Span Element</span>
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>

                    </div>

                    <!-- Task 2 -->
                    <div class="col-12">
                      <h5 class="text-center">Filtering </h5>

                      <button class="btn btn-primary btn-sm" id="btnFindFirst">Find First</button>
                      <button class="btn btn-primary btn-sm" id="btnFindLast">Find Last</button>
                      <button class="btn btn-primary btn-sm" id="btnFindDivAt1">Find div1 at index 1</button>
                      <button class="btn btn-primary btn-sm" id="btnFilterDiv2">Get All div with .div2</button>
                      <button class="btn btn-primary btn-sm" id="btnFilterNotDiv2">Get All div without .div2</button>

                      <div class="task2">

                        <div class="div1">
                          class div1 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                        <div class="div2">
                          class div2 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                        <div class="div1">
                          class div1 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                        <div class="div2">
                          class div2 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                        <div class="div1">
                          class div1 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                        <div class="div2">
                          class div2 <br />
                          Lorem ipsum dolor, sit amet consectetur adipisicing Loreelit. dolor Earum accusantium cumque
                          quibusdam
                          perspiciatis, sit amet consectetur adipisicing Loreelit. Earum accusantium cumque quibusdam
                          perspiciatis iusto voluptate?
                        </div>
                      </div>

                    </div>

                    <!-- Task 3 -->
                    <div class="col-12">
                      <h5 class="text-center">jQuery Ajax</h5>

                      <h6 class="text-center mt-3">Load Method</h6>
                      <div class="row" id="loadDataHere">
                        Replace this Content
                      </div>
                      <div class="row mt-2">
                        <button class="btn btn-primary btn-sm" id="btnLoadData">Load Content</button>
                      </div>

                      <h6 class="text-center mt-3">Get Method</h6>
                      <div class="row justify-content-center" id="getDataHere">
                        Replace this Content
                      </div>
                      <div class="row mt-2">
                        <button class="btn btn-primary btn-sm" id="btnGetData">Get Request Content</button>
                      </div>

                      <h6 class="text-center mt-3">Post Method</h6>
                      <div class="row">
                        <div class="col-6 p-1">
                          <div class="form-group">
                            <label for="">Fullname</label>
                            <input type="text" name="" id="fullname" class="form-control" placeholder="Enter Name">
                          </div>
                        </div>
                        <div class="col-6 p-1">
                          <div class="form-group">
                            <label for="">Job</label>
                            <input type="text" name="" id="job" class="form-control" placeholder="Enter Job Title">
                          </div>
                        </div>
                      </div>
                      <small id="postDataHere"> </small>
                      <div class="row mt-2">
                        <button class="btn btn-primary btn-sm" id="btnPostData">Post Request Content</button>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  <script src="../assets/js/script-jquery-mod2-prac.js"></script>
  <?php include '../footer.php' ?>