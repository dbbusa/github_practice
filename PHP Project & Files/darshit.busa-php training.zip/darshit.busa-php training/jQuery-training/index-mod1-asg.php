<?php include '../header.php' ?>

<section id="mainSection">
  <div class="row">
    <?php include 'sidebar.php' ?>
    <div class="main">
      <div class="mt-3 text-dark">
        <div class="container">
          <div class="row mt-3">
            <div class="card">
              <div class="card-header"></div>
              <div class="card-body">
                <div class="form-group">
                  <label>Select Country</label>
                  <select name="drpCountry" id="drpCountry" class="form-control my-1">
                    <option value="def">Please Select Country </option>
                  </select>
                </div>

                <div id="result" class="mt-2">

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="../assets/js/script-jquery-mod1-asg.js"></script>

<?php include '../footer.php' ?>