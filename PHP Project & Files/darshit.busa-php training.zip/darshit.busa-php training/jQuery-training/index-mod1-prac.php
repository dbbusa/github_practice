<?php include '../header.php' ?>

<section id="mainSection">
  <div class="row">
    <?php include 'sidebar.php' ?>
    <div class="main js-mod2-prac">

      <div class="card">
        <div class="card-header"></div>
        <div class="card-body">
          <div class="text-dark">
            <div class="container">
              <div class="row mt-3">
                <div class="col-12">
                  <h6>Aim : Practice of Selector CLASS and ID </h6>
                </div>
                <div class="col-12   ">
                  <button class="btn btn-primary btn-sm click-me">Click Here</button>
                  <button class="btn btn-primary btn-sm" id="clickMeId">Click Here</button>
                </div>
              </div>

              <div class="row mt-3">
                <div class="col-12">
                  <h6>Aim : Practice of Events </h6>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary btn-sm" id="dblClkbtnID">Double Click Here</button>
                  <button class="btn btn-primary btn-sm" id="musOver">Hover me</button>
                  <p>This Button Demonstrator the Use of on Method </p>
                  <button class="btn btn-primary btn-sm" id="mouseOnEvent">Button</button>
                </div>
              </div>

              <div class="row mt-3">
                <div class="col-12">
                  <h6>Aim : Hide, Show, Toggle, FadeIn and FadeOut </h6>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary btn-sm" id="clickToHide">Hide</button>
                  <button class="btn btn-primary btn-sm" id="clickToShow">Show</button>
                  <button class="btn btn-primary btn-sm" id="clickToToggle">Toggle</button>
                  <button class="btn btn-primary btn-sm" id="clickToFadeIn">FadeIn</button>
                  <button class="btn btn-primary btn-sm" id="clickToFadeOut">FadeOut</button>

                  <p class="dummy-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae maiores aut veritatis ab
                    beatae ipsam.</p>
                  <p class="dummy-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae maiores aut veritatis ab
                    beatae ipsam.</p>
                  <p class="dummy-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae maiores aut veritatis ab
                    beatae ipsam.</p>
                </div>
              </div>


              <!-- Practice From Tutorial Site  -->
              <div class="row mt-3">
                <div class="col-12">
                  <h5 class="text-center border-top border-bottom border-success py-2">Practice From Tutorial Site</h5>
                </div>
              </div>

              <!-- Task 1 -->
              <div class="row mt-3">
                <div class="col-12">
                  <h6>Task 1</h6>
                  <p id="dummyTxtTask1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati cupiditate itaque
                    quaerat neque. Maiores pariatur repudiandae numquam, obcaecati ex incidunt doloremque natus error voluptates
                    aspernatur excepturi molestias amet quos vero!</p>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary btn-sm" id="btnTask1">Check Task 1</button>
                </div>
              </div>


              <!-- Task 2 -->
              <div class="row mt-3">
                <div class="col-12" id="leaveID" style="height: 100px;">
                  <h6>Task 2: Hover the Mouse over the below text</h6>
                  <span id="helpText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati cupiditate itaque
                    quaerat neque. Maiores pariatur repudiandae numquam, obcaecati ex incidunt doloremque natus error voluptates
                    aspernatur excepturi molestias amet quos vero!</span>
                </div>
              </div>


              <!-- Task 3 -->
              <div class="row mt-3">
                <div class="col-12">
                  <h6>Task 3</h6>
                  <div class="form-group">
                    <label class="d-block">Please select your technology :</label>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioPHP" value="PHP">
                      <label class="form-check-label" for="radioPHP">PHP</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioDotNet" value="ASP.NET">
                      <label class="form-check-label" for="radioDotNet">ASP.NET</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioASP" value="ASP">
                      <label class="form-check-label" for="radioASP">ASP</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioJSP" value="JSP">
                      <label class="form-check-label" for="radioJSP">JSP</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioPERL" value="PERL">
                      <label class="form-check-label" for="radioPERL">PERL</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioCF" value="Cold Fusion">
                      <label class="form-check-label" for="radioCF">Cold Fusion</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="redioTech" id="radioOther" value="Other">
                      <label class="form-check-label" for="radioOther">Other</label>
                    </div>
                  </div>
                  <hr>
                  <div class="mb-3" id="resultTask3">

                  </div>

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="../assets/js/script-jquery-mod1-prac.js"></script>

<?php include '../footer.php' ?>