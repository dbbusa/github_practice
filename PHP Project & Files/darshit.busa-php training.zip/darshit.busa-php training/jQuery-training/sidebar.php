<div class="side">
    <h3 class="text-center">Learning</h3>

    <ul class="dropdown-ul">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module1" role="button" aria-expanded="false" aria-controls="module1">
                Module 1
            </a>
            <ul class="collapse sub-dropdown" id="module1">
                <li><a class="module-item" href="index-mod1-asg.php">Assignment</a></li>
                <li><a class="module-item" href="index-mod1-prac.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module2" role="button" aria-expanded="false" aria-controls="module2">
                Module 2
            </a>
            <ul class="collapse sub-dropdown" id="module2">
                <li><a class="module-item" href="index-mod2-asg.php">Assignment</a></li>
                <li><a class="module-item" href="index-mod2-prac.php">Practice</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="nav-link dropdown-toggle text-white" data-bs-toggle="collapse" href="#module3" role="button" aria-expanded="false" aria-controls="module3">
                Additional
            </a>
            <ul class="collapse sub-dropdown" id="module3">
                <li><a class="module-item" href="index-additional-prac.php">Practice</a></li>
            </ul>
        </li>
    </ul>
</div>