<?php include 'header.php' ?>

<div class="container">
    <div class="row my-3">
        <div class="col-12">
            <h3 class="text-center fw-bold">Technologies</h3>
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner ">
                    <div class="carousel-item active" data-bs-interval="10000">
                        <div class="row justify-content-center">
                            <img src="assets/image/html.png" class="d-block w-25" alt="HTML Logo">
                            <img src="assets/image/css.png" class="d-block w-25" alt="CSS Logo">
                        </div>
                    </div>
                    <div class="carousel-item" data-bs-interval="1000">
                        <div class="row justify-content-center">
                            <img src="assets/image/js.png" class="d-block w-50" alt="JS Logo">
                            <img src="assets/image/jquery.png" class="d-block w-25" alt="JQuery Logo">
                        </div>
                    </div>
                    <div class="carousel-item" data-bs-interval="1000">
                        <div class="row justify-content-center">
                            <img src="assets/image/bootstrap.png" class="d-block w-25" alt="Bootstrap Logo">
                            <img src="assets/image/php.png" class="d-block w-25" alt="PHP Logo">
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php' ?>