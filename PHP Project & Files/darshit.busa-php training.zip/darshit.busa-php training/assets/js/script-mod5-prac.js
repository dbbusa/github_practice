const areaCircle = (radius) => {
    const pi = 3.14159;
    let res = pi * (radius * radius);
    return res;
};
const areaRactangle = new Function('height','width','return height * width');

function calculateCircle() {
    let radius = document.getElementById('inpT1').value;
    if(radius == "")
        document.getElementById('resT1').innerHTML = "Radius field is Required";
    else{
        document.getElementById('resT1').innerHTML = areaCircle(radius);
    }
}
function calculateRactangle() {
    let height = document.getElementById('inpHeight').value;
    let width = document.getElementById('inpWidth').value;
    if(height == "" || width == "")
        document.getElementById('resT2').innerHTML = "Please Enter Height or Width";
    else{
        document.getElementById('resT2').innerHTML = areaRactangle(height,width);
    }
}
function submitTask3(){
    let val1 = parseInt(document.getElementById('inpVal1').value);
    let val2 = parseInt(document.getElementById('inpVal2').value);
    document.getElementById('resT3').innerHTML = addFunction(val1,val2);

}

const Employee ={
    details:function(){
        return "Full Name : " + this.fullname + "<br>" + "Address : " + this.address + "<br>" + "Designation : " + this.designation  + "<br>";
    }
}

const EmployeeDetail ={
    details:function(name,address,designation){
        return "Full Name : " + name + "<br>" + "Address : " + address + "<br>" + "Designation : " + designation  + "<br>";
    }
}


function employeeDetails(){
    let name = document.getElementById('inpName').value;
    let location = document.getElementById('inpAddress').value;
    let deg = document.getElementById('inpDeg').value;

    const person = {
        fullname : name,
        address  : location,
        designation : deg
    }

    document.getElementById('resultEmp').innerHTML = Employee.details.call(person);
}

function empDetailsT5(){
    let name = document.getElementById('inpT5Name').value;
    let location = document.getElementById('inpT5Address').value;
    let deg = document.getElementById('inpT5Deg').value;

    document.getElementById('resultT5Emp').innerHTML = EmployeeDetail.details.apply(null,[name,location,deg]);
}

function noClosure() {
    let count  = 0;
    function checkClosure(){
        count++;
        document.getElementById('resT6noClosure').innerHTML = count;
    }
    checkClosure();
    checkClosure();
    checkClosure();
    checkClosure();
}
const counter = (function(){
    let count = 0;
    return ()=>{ count++; return count; }
})();
function withClosure() {
    document.getElementById('resT6Closure').innerHTML = counter();
}


function addFunction(num1,num2){
    return num1+num2;
}