$(document).ready(function () {
    $(".click-me").on('click', () => {
        alert("Clicked Using Class Selector");
    });

    $("#clickMeId").on('click', () => {
        alert('Clicked Using ID Selector')
    });

    $("#dblClkbtnID").on('dblclick', () => {
        alert('Hello World!')
    });

    $("#musOver").mouseenter(function () {
        $(this).css('background-color', "#12ac7d");
        $(this).text("Mouse Enter");
    });

    $("#musOver").mouseleave(function () {
        $(this).css('background-color', "#127dac");
        $(this).text("Mouse Leave");
    });

    $('#mouseOnEvent').on({
        mouseenter: function () {
            $(this).css("background-color", "#27ds3a").text("Mouse Enter");
        },
        mouseleave: function () {
            $(this).css("background-color", "#0f27ab").text("Mouse Out");
        },
        click: function () {
            $(this).css("background-color", "#dd7b8c").text("Mouse Clicked");
        },

    });


    $("#clickToHide").on("click", () => {
        $(".dummy-text").hide();
    });
    $("#clickToShow").on("click", () => {
        $(".dummy-text").show();
    });
    $("#clickToToggle").on("click", () => {
        $(".dummy-text").toggle();
    });
    $("#clickToFadeIn").on("click", () => {
        $(".dummy-text").fadeIn(1000);
    });
    $("#clickToFadeOut").on("click", () => {
        $(".dummy-text").fadeOut(1000);
    });

    $("#btnTask1").on('click', function () {
        $("#dummyTxtTask1").css("background-color", "#0000ff");
    });

    $('#helpText').mouseenter(function () {
        $('#helpText').hide();
    });
    $('#leaveID').mouseleave(function () {
        $('#helpText ').show();
    }); 


    $("input[name=redioTech]").on('change',function(){
        $("#resultTask3").append($("<span class='d-block'></span>").text("You have selected :" + $(this).val()));
    });
});