// Custom Script Goes Here
function isEmptyStr() {
    const nameInp = document.getElementById('strName');
    const errMsg = document.getElementById('errStrName');

    if (nameInp.value.trim() == "") {
        errMsg.innerHTML = "Given String is Empty";
        errMsg.classList.remove('text-success');
        errMsg.classList.add('text-danger');
    } else {
        errMsg.innerHTML = "Given String is not Empty";
        errMsg.classList.remove('text-danger');
        errMsg.classList.add('text-success');
    }
}
function convertStrToArr() {
    const nameInp = document.getElementById('stringInp');
    const errMsgArr = document.getElementById('errMsgArr');
    const output = document.getElementById('resArr');
    let resArr;
    let tempArrStr = "";
    output.innerHTML = " ";
    if (nameInp.value.trim() == "") {
        errMsgArr.innerHTML = "Please Provide ',' Separated String";
        errMsgArr.classList.remove('text-success');
        errMsgArr.classList.add('text-danger');
    } else {
        errMsgArr.innerHTML = ""
        resArr = nameInp.value.trim().split(",");
        for (var i = 0; i < resArr.length; i++) {
            tempArrStr += resArr[i] + "<br> ";
        }

        output.innerHTML = tempArrStr;
    }
}
function getCharFromStr() {

    const nameInp = document.getElementById('stringInp1');
    const num = document.getElementById('num');

    const errMsgInp = document.getElementById('errsub');


    if (num.value.trim() == "" || nameInp.value.trim() == "") {
        errMsgInp.innerHTML = "Please Fill Both Field";
        errMsgInp.classList.remove('text-success');
        errMsgInp.classList.add('text-danger');
    } else if (nameInp.value.length < num.value || num.value <= 0) {
        errMsgInp.innerHTML = "Please Enter Number lesser than String length And Greater than 0";
        errMsgInp.classList.remove('text-success');
        errMsgInp.classList.add('text-danger');
    } else {
        var temp = nameInp.value.trim();

        errMsgInp.innerHTML = temp.substr(0, num.value);
        errMsgInp.classList.add('text-success');
        errMsgInp.classList.remove('text-danger');
    }
}

function getTodayDate() {
    const getTodayDate = new Date();
    const result = getTodayDate.toDateString();
    document.getElementById('currentDate').innerHTML = result;
}

const dataList = [];

function pushElement() {
    let inpWord = document.getElementById('inpWord');
    const errMsg = document.getElementById('errList');

    if (inpWord.value.trim() == "") {
        errMsg.innerHTML = "Enter Input Element";
        errMsg.classList.remove('text-success');
        errMsg.classList.add('text-danger');
    } else {
        errMsg.innerHTML = "";
        errMsg.classList.add('text-success');
        errMsg.classList.remove('text-danger');
        dataList.push(inpWord.value.trim());
        displayElement();
        inpWord.value = "";
    }

}
function displayElement() {
    document.getElementById('listHolder').innerHTML = "";
    var temp = "";
    for (var i = 0; i < dataList.length; i++) {
        temp += '<a href="#" class="list-group-item list-group-item-action">' + dataList[i] + '</a>';
    }
    document.getElementById('listHolder').innerHTML = temp;
}
function popElement() {

    const errMsg = document.getElementById('errList');

    if (dataList.length <= 0) {
        errMsg.innerHTML = "Please Fill The List First";
        errMsg.classList.remove('text-success');
        errMsg.classList.add('text-danger');
    } else {
        errMsg.innerHTML = "";
        errMsg.classList.add('text-success');
        errMsg.classList.remove('text-danger');
        dataList.pop();
        displayElement();
        inpWord.value = "";
    }
}
function shiftElement() {
    const errMsg = document.getElementById('errList');

    if (dataList.length <= 0) {
        errMsg.innerHTML = "Please Fill The List First";
        errMsg.classList.remove('text-success');
        errMsg.classList.add('text-danger');
    } else {
        errMsg.innerHTML = "";
        errMsg.classList.add('text-success');
        errMsg.classList.remove('text-danger');
        dataList.shift();
        displayElement();
        inpWord.value = "";
    }
}
function deleteElement() {
    const errMsg = document.getElementById('errList');
    var indexList = prompt("Enter Index to Delete");

    if (dataList.length < indexList) {
        errMsg.innerHTML = "Please Enter Valid Index";
        errMsg.classList.remove('text-success');
        errMsg.classList.add('text-danger');
    } else {
        errMsg.innerHTML = "";
        errMsg.classList.add('text-success');
        errMsg.classList.remove('text-danger');
        delete dataList[indexList - 1];
        displayElement();
        inpWord.value = "";
    }
}