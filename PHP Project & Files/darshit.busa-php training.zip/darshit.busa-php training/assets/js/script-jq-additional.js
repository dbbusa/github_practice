$(document).ready(function(){

    $('#showContent').on('click',()=>{
        $('#LoremContent').show(1000);
    });

    $('#hideContent').on('click',()=>{
        $('#LoremContent').hide(1000);
    });

    $('#toggleContent').on('click',()=>{
        $('#LoremContent').toggle(1000);
    });

    $('#fadeInContent').on('click',()=>{
        $('#LoremContent').fadeIn(1000);
    });
    
    $('#fadeOutContent').on('click',()=>{
        $('#LoremContent').fadeOut(1000);
    });

    $('#fadeToggleContent').on('click',()=>{
        $('#LoremContent').fadeToggle(2000);
    });
    
    $('#fadeToContent').on('click',()=>{
        $('#LoremContent').fadeTo(2000,0.4);
    });
    
    $('#slideDownContent').on('click',()=>{
        $('#LoremContent').slideDown(2000);
    });
    $('#slideUpContent').on('click',()=>{
        $('#LoremContent').slideUp(2000);
    });
    $('#slideToggleContent').on('click',()=>{
        $('#LoremContent').slideToggle(2000);
    });
    
        
    $('#adnimateContent').on('click',()=>{
        $('#LoremContent').animate({
            height:'toggle',
            width:'toggle',
            opacity:'toggle'
        },2000);
    });

    $('#effectStopContent').on('click',()=>{
        $('#LoremContent').stop(1000);
    });

    $('#chainingContent').on('click',()=>{
        $('#LoremContent').addClass('text-success').slideUp(2000).slideDown(3000).slideUp(3000).slideDown(2000);
    });

    $('#appendContent').on('click',()=>{
        $('#LoremContent2').append("<br/>---------------------- <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero dolorem aperiam doloremque exercitationem, recusandae dolores nisi minus saepe explicabo, consectetur unde commodi eligendi ipsam dolorum. Consectetur molestias minima nulla. <br>----------------------")
    });


    $('#prependContent').on('click',()=>{
        $('#LoremContent2').prepend("---------------------- <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero dolorem aperiam doloremque exercitationem, recusandae dolores nisi minus saepe explicabo, consectetur unde commodi eligendi ipsam dolorum. Consectetur molestias minima nulla. <br/>----------------------<br/>")
    });
    
    $('#beforeContent').on('click',()=>{
        $('#LoremContent2').before("---------------------- <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero dolorem aperiam doloremque exercitationem, recusandae dolores nisi minus saepe explicabo, consectetur unde commodi eligendi ipsam dolorum. Consectetur molestias minima nulla. <br/>----------------------<br/>")
    });

    $('#afterContent').on('click',()=>{
        $('#LoremContent2').after("---------------------- <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae libero dolorem aperiam doloremque exercitationem, recusandae dolores nisi minus saepe explicabo, consectetur unde commodi eligendi ipsam dolorum. Consectetur molestias minima nulla. <br/>----------------------<br/>")
    });

    $('#removeContent').on('click',()=>{
        $('#LoremContent2').remove();
    });

    $('#emptyContent').on('click',function(){
        $("#LoremContent2").empty();
    });

    $('#removeClassContent').on('click',()=>{
        $('#LoremContent2').removeClass('text-primary');
    });
    $('#addClassContent').on('click',()=>{
        $('#LoremContent2').addClass('text-primary');
    });

});