let product1 = ['item1','item2', 'item3'];
let product2 = ['item4','item5', 'item6'];

function innerHTMLData(id,message){
    document.getElementById(id).innerHTML = message;
}

function pushElementArray(){
    product1.push('New-Item');
    innerHTMLData('resultProd1Array', product1);
    innerHTMLData('resultProd2Array',product2);
    innerHTMLData('resultOutArray',"");
}
function popElementArray(){
    product1.pop();
    innerHTMLData('resultProd1Array', product1);
    innerHTMLData('resultProd2Array',product2);
    innerHTMLData('resultOutArray',"");
}

function concatArrays(){
    let newArray = product1.concat(product2);
    innerHTMLData('resultProd1Array', product1);
    innerHTMLData('resultProd2Array',product2);
    innerHTMLData('resultOutArray',newArray);
}
function fillArray(){
    innerHTMLData('resultProd1Array', product1.fill("null"));
    innerHTMLData('resultProd2Array',product2.fill('null'));
    innerHTMLData('resultOutArray','');
}
function listBothArray(){
    let res = '';
    let newArray = product1.concat(product2);

    newArray.forEach((value,index)=>{
        res+= value + "<br/>";
    });

    innerHTMLData('resultProd1Array', product1);
    innerHTMLData('resultProd2Array',product2);
    innerHTMLData('resultOutArray',res);
}

function checkIfArray() {
    let strData = "Hello Everyone";
    
    let resArray1 = Array.isArray(product1);
    let resArray2 = Array.isArray(product2);
    let resStr = Array.isArray(strData);

    innerHTMLData('resultProd1Array',"Is Array Product 1 - " + resArray1);
    innerHTMLData('resultProd2Array',"Is Array Product 2 - " + resArray2);
    innerHTMLData('resultOutArray',"Is Array String Data - " + resStr);
}
function joinArray(){
    let newArr = product1.concat(product2);
    innerHTMLData('resultProd1Array', product1.join(' _ '));
    innerHTMLData('resultProd2Array', product2.join(' _ '));
    innerHTMLData('resultOutArray', newArr.join(' _ '));
}

function lengthArray(){
    let lenProduct1 = product1.length;
    let lenProduct2 = product2.length;

    innerHTMLData('resultProd1Array',"Length Array Product 1 - " + lenProduct1);
    innerHTMLData('resultProd2Array',"Length Array Product 2 - " + lenProduct2);
    innerHTMLData('resultOutArray',"");
}

function reverseAllItem() {
    let reverseElement1 = product1.map((ele)=>{
        return ele.split("").reverse().join(""); 
    });
    let reverseElement2 = product2.map((ele)=>{
        return ele.split("").reverse().join(""); 
    });
    innerHTMLData('resultProd1Array', reverseElement1);
    innerHTMLData('resultProd2Array', reverseElement2);
    innerHTMLData('resultOutArray',"");
}

Array.prototype.newCustomPrototype = function() {
    for(let i = 0; i < this.length; i++)
        this[i] = this[i].toUpperCase();
}

function applyPrototypeArray(){

    let resArrProd1 = "Before Applying Prototype <br />  => " + product1.join(" _ ") + "<br />";
    product1.newCustomPrototype();
    resArrProd1 += "After Applying Prototype <br/>  => " + product1.join(" _ ");
    
    let resArrProd2 = "Before Applying Prototype <br />  => " + product2.join(" _ ") + "<br />";
    product2.newCustomPrototype();
    resArrProd2 += "After Applying Prototype <br/>  => " + product2.join(" _ ");

    innerHTMLData('resultProd1Array', resArrProd1);
    innerHTMLData('resultProd2Array', resArrProd2);
    innerHTMLData('resultOutArray',"");
}


function reduceArray(){
    innerHTMLData('resultProd1Array',product1.reduce((currentVal,iniVal)=>{
        return currentVal + " -> " + iniVal;
    }));

    innerHTMLData('resultProd2Array',product2.reduce((currentVal,iniVal)=>{
        return currentVal + " -> " + iniVal;
    }));

    innerHTMLData('resultOutArray',"");
}

function reduceRightArray(){
    innerHTMLData('resultProd1Array',product1.reduceRight((currentVal,iniVal)=>{
        return currentVal + " -> " + iniVal;
    }));

    innerHTMLData('resultProd2Array',product2.reduceRight((currentVal,iniVal)=>{
        return currentVal + " -> " + iniVal;
    }));

    innerHTMLData('resultOutArray',"");
}

function spliceArray(){
    product1.splice(2,0, 'item 7', 'item 8');
    product2.splice(2,0, 'item 9', 'item 10');

    innerHTMLData('resultProd1Array',product1);
    innerHTMLData('resultProd2Array',product2);
    innerHTMLData('resultOutArray',"");
}