$(document).ready(function () {

    let dataRes = '';
    $.getJSON("https://gorest.co.in/public-api/users", function (response) {
        dataRes += response.data.map(ele => {
            return `<tr>
                <td>${ele.id}</td>
                <td>${ele.name}</td>
                <td>${ele.email}</td>
                <td>${ele.gender}</td>
                <td>${ele.status}</td>
            </tr>`
        });

        $('#showDataHere').html(dataRes);
    });
});
