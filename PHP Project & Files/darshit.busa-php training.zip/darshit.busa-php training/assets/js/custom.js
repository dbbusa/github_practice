function calculate() {
    const tempNum1 = document.getElementById('num1');
    const tempNum2 = document.getElementById('num2');
    const tempOpr = document.querySelectorAll('#operator');
    const resultTemp = document.getElementById('result');
    let opr;
    let result;
    

    if (tempNum1.value == "" || tempNum2.value == "") {
        alert("All the Input Fields are Required");
    } else {
        num1 = parseInt(tempNum1.value);
        num2 = parseInt(tempNum2.value);

        if (isNaN(num1) || isNaN(num2)) {
            alert("Invalid Input Given");
        } else {
            for (let i = 0; i < tempOpr.length; i++) {
                if (tempOpr[i].checked) {
                    opr = tempOpr[i].value;
                }
            }

            switch (opr) {
                case "add": result = num1 + num2;
                    break;
                case "sub": result = num1 - num2;
                    break;
                case "mul": result = num1 * num2;
                    break;
                case "div": result = parseFloat(num1 / num2);
                    break;
                default:
                    result = "Please Select Operation";
                    break;
            }

            resultTemp.innerHTML = "Result is : " + " " + result;
        }
    }
}

function resetForm() {
    document.getElementById("formCalc").reset(); 
    document.getElementById("result").innerHTML = "Result is : "; 
}

function validateDate() {
    let inpDateObj = document.getElementById('dateVal');
    let inpDate = inpDateObj.value.trim();
    const month31 = [1, 3, 5, 7, 8, 10, 12];
    const month30 = [4, 6, 9, 11];
    let results = "";
    let isLeapYear = false;
    var dateReg = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;

    if (inpDate == "") {
        results += "Please Enter Date";
    } else if (!inpDate.match(dateReg)) {
        results += "Invalid Date, Please Enter Valid date";
    }
    else {
        results = "";
        var datePart = inpDate.split('-');

        var mm = parseInt(datePart[0]);
        var dd = parseInt(datePart[1]);
        var yyyy = datePart[2];

        var tempYear = parseInt(yyyy);

        if (tempYear % 4 == 0 && tempYear % 100 == 0 || tempYear % 400 == 0)
            isLeapYear = true;

        if (mm > 12)
            results += "Invalid Month Please Enter Valid Month";
        else if (month31.includes(mm) && dd > 31)
            results += "Invalid Date, Date Should be in 31";
        else if (month30.includes(mm) && dd >= 31)
            results += "Invalid Date, Date Should be in 30";
        else if (isLeapYear && dd > 29 && mm == 2 )
        results += "Invalid Date, Date Should be in 29";
        else if (!isLeapYear && dd > 28 && mm == 2 )
        results += "Invalid Date, Date Should be in 28";
        else
            results = "Valid Date";
        }
    document.getElementById('result').innerHTML = results;
}
function validateData() {
    const city = ['rajkot', 'surat', 'pune', 'mumbai'];

    const empId = document.getElementById('empId').value.trim();
    const empName = document.getElementById('empName').value.trim();
    const empAge = document.getElementById('empAge').value.trim();
    const empGender = document.getElementsByName('empGender');
    const empDesignation = document.getElementById('empDesignation').value.trim();
    const empSalary = document.getElementById('empSalary').value.trim();
    const empLocation = document.getElementById('empLocation').value.trim();
    const empEmail = document.getElementById('empEmail').value.trim();
    const empDOJ = document.getElementById('empDOJ').value.trim();
    const empContact = document.getElementById('empContact').value.trim();

    const regexDate = new RegExp("([0-9]{2})-([0-9]{2})-([0-9]{4})");
    const regexContact = new RegExp("([0-9]{10})");
    const regexEmail = new RegExp("([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+");
    const regexEmpId = new RegExp("(?=\d*[a-zA-Z]*\d*).{5,}");
    const regexEmpName = new RegExp("[a-zA-Z]+");
    const regexEmpAge = new RegExp("[0-9]{2}");

    let flagId = 0;
    let flagName = 0;
    let flagAge = 0;
    let flagGender = 0;
    let flagDes = 0;
    let flagSal = 0;
    let flagLoc = 0;
    let flagEmail = 0;
    let flagDoj = 0;
    let flagContact = 0;

    if (empId == "") {
        document.getElementById('errEmpId').innerHTML = "Employee ID is Required";
        flagId = 0;
    } else if (!regexEmpId.test(empId)) {
        document.getElementById('errEmpId').innerHTML = "Employee ID must be at least 5 character long Should Contain Numbers and Alphabet only";
        flagId = 0;
    }
    else {
        document.getElementById('errEmpId').innerHTML = "";
        flagId = 1;
    }

    if (empName == "") {
        document.getElementById('errEmpName').innerHTML = "Employee Name is Required";
        flagName = 0;
    } else if (!regexEmpName.test(empName)) {
        document.getElementById('errEmpName').innerHTML = "Employee Name Should contain Alphabets only";
        flagName = 0;
    } else {
        document.getElementById('errEmpName').innerHTML = "";
        flagName = 1;
    }

    if (empAge == "") {
        document.getElementById('errEmpAge').innerHTML = "Employee Age is Required";
        flagAge = 0;
    } else if (!regexEmpAge.test(empAge) || empAge > 60) {
        document.getElementById('errEmpAge').innerHTML = "Employee Age Should be Number and Shoul be lesser than 60 year";
        flagAge = 0;
    }
    else {
        document.getElementById('errEmpAge').innerHTML = "";
        flagAge = 1;
    }


    if (!(empGender[0].checked || empGender[1].checked || empGender[2].checked)) {
        document.getElementById('errEmpGender').innerHTML = "Employee Gender is Required";
        flagGender = 0;
    }else{
        document.getElementById('errEmpGender').innerHTML = "";
        flagGender = 1;
    }


    if (empDesignation == "") {
        document.getElementById('errEmpDesignation').innerHTML = "Employee Designation is Required";
        flagDes = 0;
    } else if (!regexEmpName.test(empDesignation)) {
        document.getElementById('errEmpDesignation').innerHTML = "Designation Should be Alphabet";
        flagDes = 0;
    }
    else {
        document.getElementById('errEmpDesignation').innerHTML = "";
        flagDes = 1;
    }


    if (empSalary == "") {
        document.getElementById('errEmpSalary').innerHTML = "Employee Salary is Required";
        flagSal = 0;
    } else if (!regexEmpAge.test(empSalary)) {
        document.getElementById('errEmpSalary').innerHTML = "Employee Salary Should be Numbers";
        flagSal = 0;
    } else {
        document.getElementById('errEmpSalary').innerHTML = "";
        flagSal = 1;
    }

    if (empLocation == "") {
        document.getElementById('errEmpLocation').innerHTML = "Employee Location is Required";
        flagLoc = 0;
    } else {
        document.getElementById('errEmpLocation').innerHTML = "";
        flagLoc = 1;
    }

    if (empEmail == "") {
        document.getElementById('errEmpEmail').innerHTML = "Employee Email is Required";
        flagEmail = 0;
    } else if (!regexEmail.test(empEmail)) {
        document.getElementById('errEmpEmail').innerHTML = "Employee Email Should be Valid";
        flagEmail = 0;
    } else {
        document.getElementById('errEmpEmail').innerHTML = "";
        flagEmail = 1;
    }

    if (empDOJ == "") {
        document.getElementById('errEmpDOJ').innerHTML = "Employee Date of Joining is Required";
        flagDoj = 0;
    } else if (!regexDate.test(empDOJ)) {
        document.getElementById('errEmpDOJ').innerHTML = "Employee Date of Joining must be in the form of DD-MM-YYYY";
        flagDoj = 0;
    } else {
        document.getElementById('errEmpDOJ').innerHTML = "";
        flagDoj = 1;
    }

    if (empContact == "") {
        document.getElementById('errEmpContact').innerHTML = "Employee Contact is Required";
        flagContact = 0;
    }else if(!regexContact.test(empContact)){
        document.getElementById('errEmpContact').innerHTML = "Employee Contact should be of 10 digit";
        flagContact = 0;
    }else{
        document.getElementById('errEmpContact').innerHTML = "";
        flagContact = 1;
    }

    if (flagId == 0 || flagName == 0 || flagAge == 0 || flagGender == 0 || flagDes == 0 || flagSal == 0 || flagLoc == 0 || flagEmail == 0 || flagDoj == 0 || flagContact == 0)
        return false;
    else
        return true;

}

function exercise1(){
    document.getElementById('demo').innerHTML = "exercise1";
 }
 function exercise2(){
     document.getElementsByTagName('p')[0].innerHTML = "exercise2";
 }
 function exercise3(){
     document.getElementById("image").src = "https://www.w3schools.com/js/pic_bulbon.gif";
 }
 function exercise4(){
     document.getElementById("myText").value = "Have a nice day!";
 }
 function exercise5(){
     document.getElementById("demo").style.color = "#ff0000";
 }
 function exercise6(){
     document.getElementById("demo").style.display = "none";
 }
 
 function indexPage(){
     window.location.href = 'index-mod3-prac.php'
 }
 function page1(){
     window.location.href = 'page1-mod3-prac.php'
 }
 function page2(){
     window.location.href = 'page2-mod3-prac.php'
 }
 function moveBack(){
     window.history.back();
 }
 let windowObj;
 function openWindow() {
     windowObj = window.open("","","width=300, height=300");
 }
 function resizeWindow() {
     windowObj.resizeTo(200,200);   
 }
 function displayTimerClock() {
    document.getElementById('beforeTime').classList.add('d-none');
    document.getElementById('beforeTime').classList.remove('d-block');
    document.getElementById('mcqSection').classList.add('d-block');
    document.getElementById('mcqSection').classList.remove('d-none');
    document.getElementById('afterTime').classList.add('d-none');
    document.getElementById('afterTime').classList.remove('d-block');
    let secound = 59, minute = 59, hour = 2;
    let x = setInterval(function () {
        document.getElementById('timer').innerHTML = hour + ":" + minute + ":" + secound;
        secound--;
        if (hour == 0 && secound == 0 && minute == 0) {

            document.getElementById('beforeTime').classList.add('d-block');
            document.getElementById('beforeTime').classList.remove('d-block');
            document.getElementById('mcqSection').classList.add('d-none');
            document.getElementById('mcqSection').classList.remove('d-block');
            document.getElementById('afterTime').classList.add('d-block');
            document.getElementById('afterTime').classList.remove('d-none');

            document.getElementById('timer').classList.add('d-none');

            document.getElementById('showMsg').classList.remove('d-none');
            document.getElementById('exampleModal').style.display = 'none';
            document.getElementById('exampleModal').classList.add('hide');
            document.getElementById('exampleModal').classList.remove('show');
        }
        if (minute == 5 && hour == 0) {
            document.getElementById('exampleModal').style.display = 'block';
            document.getElementById('exampleModal').classList.add('show');
            document.getElementById('exampleModal').classList.remove('hide');
        } if (minute == 0 && hour != 0) {
            hour--;
            minute = 59;
        } else if (secound == 0) {
            minute--;
            secound = 59;
        }
    }, 1000);
}

function dismissModal() {
    document.getElementById('exampleModal').style.display = 'none';
    document.getElementById('exampleModal').classList.add('hide');
    document.getElementById('exampleModal').classList.remove('show');
}
function finishExam() {
    window.location.href = "status-mod4-asg.php";
}

function findSquare(num,displayResult){
    let res = num**2;
    displayResult(res);
}

function displayData(data){
    document.getElementById('resultT3').innerHTML = data;
}

function taskOne(){
    const inpEle = document.getElementById('inpT1');
    var inputNum = parseInt(inpEle.value.trim());
    if(!(isNaN(inputNum) || inpEle.value.trim() == "")){
        findSquare(inputNum,(result)=>{
            document.getElementById('resultT1').innerHTML = "Square is = " + result;
        });
    }else{
        document.getElementById('resultT1').innerHTML = "Please Enter Number";
    }
}
function checkGlobVar(){
    var numGlob = "Default Value";
    if(true){
        var numGlob = document.getElementById('inpT2').value;
        document.getElementById('resultT2block').innerHTML = numGlob;
    }
    document.getElementById('resultT2').innerHTML = numGlob;
}
function checkGlobLet(){
    var numGlob = "Default Value";
    if(true){
        let numGlob = document.getElementById('inpT2').value;
        document.getElementById('resultT2block').innerHTML = numGlob;
    }
    document.getElementById('resultT2').innerHTML = numGlob;
}

function checkStr(){
    var inpStr = document.getElementById('inpT3').value.trim();
    let resultStr = new Promise(function(success,failure){
        let defStr = "Hello World";
        setTimeout(function(){
            if(defStr == inpStr){
                res = inpStr.split("").reverse().join("");
                success(res);
            }else{
                failure(inpStr + " - " + "Wrong Input");
            }
        },500);
        
    }).then(
        function (value){
            displayData(value);
        },
        function (error){
            displayData(error);
        }
    );
}

// Task 1
async function loadData() {
    let count = 0;
    const filePath = "../assets/ref/products.json";
    await fetch(filePath).then(
        (success) => {
            success.text().then(
                (dataRes) => {
                    console.log(JSON.parse(dataRes));
                    let productsData = JSON.parse(dataRes);
                    for (var i = 0; i < productsData.products.length; i++) {

                        const trElement = document.createElement('tr');
                        const tdElementProID = document.createElement('td');
                        const tdElementProName = document.createElement('td');
                        const tdElementProPrice = document.createElement('td');
                        const tdElementProCart = document.createElement('td');
                        const btnCart = document.createElement('button');

                        let productID = ++count;
                        let productName = productsData.products[i].Name;
                        let productPrice = productsData.products[i].Price;

                        // Product ID
                        proIdText = document.createTextNode(productID);
                        tdElementProID.appendChild(proIdText);
                        trElement.appendChild(tdElementProID);

                        // Product Name
                        proNameText = document.createTextNode(productName);
                        tdElementProName.appendChild(proNameText);
                        trElement.appendChild(tdElementProName);

                        // Product Price
                        proPriceText = document.createTextNode(productPrice);
                        tdElementProPrice.appendChild(proPriceText);
                        trElement.appendChild(tdElementProPrice);

                        // Add to Cart Button 
                        btnCart.innerHTML = "Add to Cart";
                        btnCart.className = "btn btn-warning btn-sm";
                        btnCart.addEventListener('click', function () {
                            addToCart(productID, productName, productPrice);
                        });
                        tdElementProCart.appendChild(btnCart);
                        trElement.appendChild(tdElementProCart);

                        document.getElementById('tblBodyData').appendChild(trElement);
                    }

                })
        }, (error) => {
            document.getElementById('resError').classList.remove('hide');
            document.getElementById('resError').innerHTML = error;
            document.getElementById('resError').classList.add('show');
        }
    );
}

function addToCart(productID, productName, productPrice) {
    let cartObject = [];
    // Check For the Cart is there in local storage
    if (localStorage.getItem('cartSummary') == null) {
        cartObject.push({ "id": productID, "Name": productName, "Price": productPrice });
        localStorage.setItem('cartSummary', JSON.stringify(cartObject));
    } else {
        var tempData = JSON.parse(localStorage.getItem('cartSummary'));
        tempData.push({ "id": productID, "Name": productName, "Price": productPrice });
        localStorage.setItem('cartSummary', JSON.stringify(tempData));
    }
    document.getElementById('resSuccess').innerHTML = "Item Added To Cart";
    document.getElementById('resSuccess').classList.remove('d-none');
    document.getElementById('resSuccess').classList.add('show');

}
function clearCart() {
    localStorage.clear();
    window.location.reload();
}

function cartSummary() {
    var dataRes = localStorage.getItem('cartSummary');
    let productsData = JSON.parse(dataRes);
    console.log(productsData);
    const list = document.getElementById('tblSumBodyData');
    while (list.hasChildNodes()) {
        list.removeChild(list.firstChild);
    }
    for (let i = 0; i < productsData.length; i++) {

        const trElement = document.createElement('tr');
        const tdElementProID = document.createElement('td');
        const tdElementProName = document.createElement('td');
        const tdElementProPrice = document.createElement('td');


        let productID = productsData[i].id;
        let productName = productsData[i].Name;
        let productPrice = productsData[i].Price;

        // Product ID
        let proIdText = document.createTextNode(productID);
        tdElementProID.appendChild(proIdText);
        trElement.appendChild(tdElementProID);

        // Product Name
        let proNameText = document.createTextNode(productName);
        tdElementProName.appendChild(proNameText);
        trElement.appendChild(tdElementProName);

        // Product Price
        let proPriceText = document.createTextNode(productPrice);
        tdElementProPrice.appendChild(proPriceText);
        trElement.appendChild(tdElementProPrice);

        document.getElementById('tblSumBodyData').appendChild(trElement);
    }
}
// Task 1
function getDataJson() {
    const productData = {
        "products":
            [
                { "Name": "Cheese", "Price": 2.50, "Location": "Refrigerated foods" },
                { "Name": "Crisps", "Price": 3, "Location": "the Snack isle" },
                { "Name": "Pizza", "Price": 4, "Location": "Refrigerated foods" },
                { "Name": "Chocolate", "Price": 1.50, "Location": "the Snack isle" },
                { "Name": "Self-raising flour", "Price": 1.50, "Location": "Home baking" },
                { "Name": "Ground almonds", "Price": 3, "Location": "Home baking" }
            ]
    }
    localStorage.setItem('products', JSON.stringify(productData));

    var result = localStorage.getItem("products");
    console.log(JSON.parse(result));
    document.getElementById('result').innerHTML = result;
}

// Task 2
async function fetchDataFile() {
    const filePath = "../assets/ref/products.json";
    await fetch(filePath).then(
        (success) => {
            success.text().then(
                (dataRes) => {
                    console.log(JSON.parse(dataRes));
                    document.getElementById('resultT2').innerHTML = dataRes;
                })
        }, (error) => {
            document.getElementById('resError').classList.remove('d-none');
            document.getElementById('resError').innerHTML = error;
            document.getElementById('resError').classList.add('show');
        }
    );
}

// Module 7 practice 
function stringFunction() {
    let result = "";
    var strData = document.getElementById('strData').value;

    if (strData == "") {
        document.getElementById('errStrData').innerHTML = "Please Enter String Data";
        document.getElementById('errStrData').classList.add('text-danger');
        document.getElementById('errStrData').classList.remove('text-muted');
    } else {

        result += "Index of a -- " + strData.indexOf('a') + "<br>";
        result += "Secound Index of a -- " + strData.indexOf('a', strData.indexOf('a') + 1) + "<br>";
        result += "Length of the String  -- " + strData.length + "<br>";
        result += "Lower Case  -- " + strData.toLowerCase() + "<br>";
        result += "Upper Case  -- " + strData.toUpperCase() + "<br>";
        result += "Split -- " + strData.split("") + "<br>";

        document.getElementById('resData').innerHTML = result;
    }
}

function sum2Number() {
    let num1 = parseInt(document.getElementById('number1').value);
    let num2 = parseInt(document.getElementById('number2').value);


    if (isNaN(num1)) {
        document.getElementById('errNum1').innerHTML = "Number 1 is Required and Should be Number only";
        document.getElementById('errNum1').classList.add('text-muted');
        document.getElementById('errNum1').classList.remove('text-danger');
    } else if (isNaN(num2)) {
        document.getElementById('errNum2').innerHTML = "Number 2 is Required and Should be Number only";
        document.getElementById('errNum2').classList.add('text-muted');
        document.getElementById('errNum2').classList.remove('text-danger');
    } else {
        let result = num1 + num2;
        document.getElementById('errNum2').innerHTML = "";
        document.getElementById('errNum1').innerHTML = "";
        document.getElementById('resAddition').innerHTML = result;
    }
}

function replaceText() {
    setInterval(() => {
        document.getElementById('chngeStr').innerHTML = "Data After 10 Second";
    }, 10000)
}

function varLetExample() {
    var num = 100; // Function level
    let numVal = 100; // Function level
    const fixNum = 10; // Function level

    // Block of Var Variable
    {
        var num = 200 // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br> Value of num variable with Var inside block - " + num;
    }
    document.getElementById('dispResult').innerHTML += "<br>Value of num variable with Var inside function - " + num;

    // Block of Let Variable
    {
        let numVal = 2000 // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>Value of numVal variable with let inside block - " + numVal;
    }
    document.getElementById('dispResult').innerHTML += "<br>Value of numVal variable with let inside function - " + numVal;

    // Block of const Variable
    {
        const fixNum = 200; // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>Value of fixNum variable with const inside function - " + fixNum;
    }

    document.getElementById('dispResult').innerHTML += "<br>Value of fixNum variable with const inside function - " + fixNum;
}

function multiExample() {
    let num1 = parseInt(document.getElementById('num1Multi').value);
    let num2 = parseInt(document.getElementById('num2Multi').value);

    const multiply = (arg1, arg2) => { return arg1 * arg2 };

    if (isNaN(num1)) {
        document.getElementById('errNumMulti1').innerHTML = "Number 1 is Required and Should be Number only";
        document.getElementById('errNumMulti1').classList.add('text-muted');
        document.getElementById('errNumMulti1').classList.remove('text-danger');
    } else if (isNaN(num2)) {
        document.getElementById('errNumMulti2').innerHTML = "Number 2 is Required and Should be Number only";
        document.getElementById('errNumMulti2').classList.add('text-muted');
        document.getElementById('errNumMulti2').classList.remove('text-danger');
    } else {
        let result = multiply(num1, num2);
        document.getElementById('errNumMulti2').innerHTML = "";
        document.getElementById('errNumMulti1').innerHTML = "";
        document.getElementById('disArrowData').innerHTML = "Multiplication - " + result;
    }
}


function forOfFunction() {
    const arryaObj = ['item 1', 'item 2', 'item 3', 'item 4', 'item 5'];
    let disForData = "";
    for (let val of arryaObj) {
        disForData += val + "<br>";
    }

    document.getElementById('disForData').innerHTML = disForData;
}

function stringTemplate() {
    const employee = {
        name: "John Doe",
        city: "Mumbai",
        skills: ["Backend", "Frontend", "Cloud"],
    };
    let details = `
    <h5> ${employee.name} </h5>
    <h6> ${employee.city} </h6>
    <p> Skills </p>
    <ul>
        ${employee.skills.map(skill => {
        return `<li> ${skill} </li>`;
    }).join("")
        }
    </ul>`;
    document.getElementById('disStringTemp').innerHTML = details;
}


function taggedTemplate() {
    const author = "John Doe";
    const statement = "Lorem ipsum dolor sit amet consectetur adipisicing";
    const resTemp = highlight`Here is the ${statement} by ${author}`;

    console.log(resTemp);
    document.getElementById('disTaggedStringTemp').innerHTML = resTemp;

    function highlight(text, ...extras) {
        let res = text.map((item, index) => {
            return `${item} <strong style='color:#0d6efd'>${extras[index]}</strong>`
        });
        return res.join("")
    }
}

function swapValue() {
    let fname = "Doe", lname = "John";
    data = "Before Swap fname = " + fname + " lname = " + lname;

    [lname, fname] = [fname, lname];

    data += "<br> After Swap fname = " + fname + " lname = " + lname;

    document.getElementById('disSwapTemp').innerHTML = data;
}

function objConverter() {
    const employee = {
        id: "E1212",
        first: "John",
        last: "Doe",
        city: "Pune",
        state: "Maharashtra",
        country: "India",
    }

    const { first: fname, last: lname, city, state, country } = employee;

    document.getElementById('dispEmp').innerHTML = "Fullname  : " + fname + " " + lname + "<br>City : " + city + "<br>State : " + state + "<br>Country : " + country;

}

// Additional Practice

function checkInvRes() {
    let inpEle = document.getElementById('decNum').value;
    document.getElementById("resultInv").innerHTML = `1's Complement of ${inpEle} is ${bin2dec(inpEle)}`;
}
function bin2dec(data) {
    let tempStr = parseInt(data, 10).toString(2);
    let bin = parseInt(data, 10).toString(2);
    var invRes = '';
    while (bin) {
        let temp = bin % 10;
        invRes += (temp === 0) ? 1 : 0;
        bin = parseInt(bin / 10);
    }
    let invStr = invRes.split("").reverse().join("");
    let invValue = parseInt(invStr, 2).toString();
    return invValue + "<br/> Input Binary String - " + tempStr + " <br/> Output Binary String- " + invStr;
}

async function getApiData() {
    const url = "https://gorest.co.in/public/v2/users";
    await fetch(url).then((success) => {
        success.text().then(
            (response) => {
                let data = JSON.parse(response);
                let resData = '';
                data.map(ele => {
                    resData += `<div class="col-sm-12 col-md-3 p-2"> <div class="card">
                    <div class="card-body position-relative">
                      <h6 class="card-title">${ele.name}</h6>
                      <small class="card-title text-muted">${ele.email}</small>
                      <span class="position-absolute top-0 start-100 translate-middle badge border border-light rounded-circle ${(ele.status == 'active') ? 'bg-success' : 'bg-danger'} p-2"><span class="visually-hidden">messages</span></span>
                    </div>
                    </div>
                  </div>`;
                });

                document.getElementById('resApiData').innerHTML = resData;
            },
            (reject) => { },
        );
    }, (error => {
        console.log(error);
    }));
}


function sumWithExpression() {
    const sumFunction = (num1, num2) => num1 + num2;
    let number1 = parseInt(document.getElementById('inpNumber1').value);
    let number2 = parseInt(document.getElementById('inpNumber2').value);

    document.getElementById('resDataFunExp').innerHTML = "Sum is = " + sumFunction(number1, number2);
}

function objectHandle() {
    const employee = {
        name: "John Doe",
        email: "john.doe@gmail.com",
        job: "Developer",
        skills: ['PHP', '.NET', 'MySql'],
        hobbies: ['Dancing', 'Travaling', 'Swimming']
    };

    let details = detailsObjEmp`${employee.name}${employee.email}${employee.job}${employee.skills}${employee.hobbies}`;

    document.getElementById('resDataObj').innerHTML = details;

    function detailsObjEmp(text, ...data) {
        let detailsRes = '';
        detailsRes = `<div class="col-sm-12 col-md-5 p-2"> <div class="card">
            <div class="card-body position-relative">
              <h6 class="card-title">${data[0]}</h6>
              <p class="card-title text-muted">${data[1]}</p>
              <p class="card-title text-muted">${data[2]}</p>
                <div class="d-block">
                ${data[3].map(ele => {
            return `<small class="card-title text-muted">${ele}</small>, `;
        }).join("")}
                </div>

                <div class="d-block">
              ${data[4].map(ele => {
            return `<small class="card-title text-muted">${ele}</small>, `;
        }).join("")}
        </div>
            </div>
            </div>
          </div>`;
        return detailsRes;
    }
}


function checkData(inpArgStr1, inpArgStr2) {
    return new Promise((success, failure) => {
        setTimeout(() => {
            if (inpArgStr1 == "") {
                failure("String 1 is Required");
            }
            if (inpArgStr2 == "") {
                failure("String 2 is Required");
            }
            if (inpArgStr1 == inpArgStr2)
                success("Same Strings Given");
            else
                failure("Different Strings Given");
        }, 1000);
    });
}

function matchWithProm() {
    let inpStr1 = document.getElementById('inpString1Box').value;
    let inpStr2 = document.getElementById('inpString2Box').value;

    checkData(inpStr1, inpStr2).then(
        (success) => {
            displayMsg('statusMsg', success);
        },
        (failure) => {
            displayMsg('statusMsg', failure);
        },
    );
}

function displayMsg(eleId, msg) {
    document.getElementById(eleId).innerHTML = msg;
    document.getElementById(eleId).innerHTML = msg;
}

function additionAll(num, ...argsVal) {
    let sum = 0;
    sum += parseInt(num);
    for (let item of argsVal)
        sum += item;

    displayMsg('resDataSum', `Sum is ${sum}`);
}
function sumOfNNumer() {
    let inpNum = document.getElementById('inpStrNum').value;

    additionAll(inpNum, 10, 20, 30, 40, 50);
}


function checkForMob() {
    const mobNumReg = /^\d{3}-\d{3}-\d{4}$/;
    let inpVal = document.getElementById('inpMobNum').value;

    if (mobNumReg.test(inpVal)) {
        displayMsg('resMobileNum', "Valid Mobile Number");
    } else {
        displayMsg('resMobileNum', "Mobile Number Should be in ***-***-**** formate");
    }
}

function btnGetDate() {
    let res = Date();
    displayMsg('timeRep', res);
}
function btnGetDateYear() {
    let res = new Date();
    displayMsg('currentYear', res.getFullYear());
}

function FuncPractice() {
    const employeeData = {
        fullname: function () {
            return `Fullname : ${this.firstName} ${this.lastName} <br/> Designation : ${this.designation} <br/> Country : ${this.country}`;
        },
    }

    const emp1 = {
        firstName : "Alexa",
        lastName : "Peter",
        country : "US",
        designation : "Developer",
    }

    const emp2 = {
        firstName : "Dan",
        lastName : "Saw",
        country : "US",
        designation : "Developer",
    }

    displayMsg('resultDataEmp1',employeeData.fullname.call(emp1));
    displayMsg('msgDivider',"-----------------------------------");
    displayMsg('resultDataEmp2',employeeData.fullname.call(emp2));
}