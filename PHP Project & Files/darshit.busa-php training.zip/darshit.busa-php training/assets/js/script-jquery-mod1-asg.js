$(document).ready(function () {
    const countryList = ["India", "United Kingdom", "United States", "Russia", "Germany"];

    for (let countryName of countryList) {
        $('#drpCountry').append(`<option value='${countryName}'>${countryName}</option>`);
    }

    let res = "";
    if ($('#drpCountry').val() == 'def') {
        for (let countryName of countryList) {
            res += `<span class='d-block'>Your Selected Country : ${countryName}</span>`;
        }
        $("#result").html(res);
    }

    $('#drpCountry').on('change', function () {
        let res = "";
        if ($(this).val() == 'def') {
            for (let countryName of countryList) {
                res += `<span class='d-block'>Your Selected Country : ${countryName}</span>`;
            }
            $("#result").html(res);
        } else {
            $("#result").html(`<span class='d-block'>Your Selected Country : ${$(this).val()}</span>`);
        }
    });
});