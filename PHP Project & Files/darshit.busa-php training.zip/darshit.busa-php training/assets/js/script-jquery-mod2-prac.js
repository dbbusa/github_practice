$(document).ready(function () {


    // Task 1
    $("#btnFindParent").on('click', function () {
        $('span').parent().css({ 'color': '#dc3545', 'border': '2px solid #dc3545' });
    });

    // Task 2
    $("#btnFindParents").on('click', function () {
        $('span').parents('').css({ 'color': '#6610f2', 'border': '2px solid #6610f2' });
    });

    // Task 3
    $("#btnFindParentsUntil").on('click', function () {
        $('span').parentsUntil('.task1').css({ 'color': '#6610f2', 'border': '2px solid #6610f2' });
    });

    //Task 4 
    $('#btnFindChildren').on('click', function () {
        $('.findChildren').children().css('background-color', '#6610f28c');
    });

    // Task 5
    $('#btnFindUsingFind').on('click', function () {
        $('.findChildren').find('*').css({ 'background-color': '#6610f28c', 'color': '#fff', 'border': '2px solid #6610f28c' });
    });

    // Task 6
    $('#btnFindFirst').on('click', function () {
        $(".div1").first().css({ "border": "2px solid #6610f2", 'color': '#6610f2' });
    });

    // Task 7
    $('#btnFindLast').on('click', function () {
        $(".div1").last().css({ "border": "2px solid #6610f2", 'color': '#6610f2' });
    });

    // Task 8
    $('#btnFilterDiv2').on('click', function () {
        $("div").filter('.div2').css({ "border": "2px solid #50aa55", 'color': '#50aa55' });
    });

    // Task 9
    $('#btnFindDivAt1').on('click', function () {
        $(".div1").eq('1').css({ "border": "2px solid #6610f2", 'color': '#6610f2' });
    });

    // Task 10
    $('#btnFilterNotDiv2').on('click', function () {
        $(".task2 > *").not('.div2').css({ "border": "2px solid #6610f2", 'color': '#6610f2' });
    });

    // Task 11
    $('#btnLoadData').on('click', function () {
        $("#loadDataHere").load('../assets/ref/info.txt');
    });

    // Task 12
    $('#btnGetData').on('click', function () {
        let dataRes = '';
        $.get('https://reqres.in/api/users', function (data, status) {
            dataRes = data.data.map(ele => {
                return `<div class="card col-sm-12 col-md-4 mt-2">
                <div class="card-body">
                  <h5 class="card-title">${ele.first_name} ${ele.last_name}</h5>
                  <h6 class="card-subtitle mb-2 text-muted">${ele.email}</h6>
                </div>
              </div>`;
            });

            $('#getDataHere').html(dataRes);

        });
    });

    // Task 13
    $('#btnPostData').on('click', function () {
        let fullname = $('#fullname').val();
        let job = $('#job').val();
        if (fullname == "" || job == "") {
            $('#postDataHere').text("Fullname and Job Title is Required");
        } else {
            $.post('https://reqres.in/api/users', {
                name: fullname,
                job: job
            }, function (data, status) {
                console.log(data);
                if (status == 'success')
                    $('#postDataHere').text("Data Inserted Successfully and id is " + data.id);
                else
                    $('#postDataHere').text("Data not Inserted Successfully");

            });
        }
    });
});
