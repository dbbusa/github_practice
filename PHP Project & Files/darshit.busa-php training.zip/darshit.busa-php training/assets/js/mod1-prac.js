let val1, val2, val3;
var sum = 0;
const limit = 40;
const cityArray = ['Rajkot', 'Surat', 'Mumbai', 'Pune', 'Bhavnagar']
function btnInpValue() {
    tempVal1 = prompt("Enter Value 1");
    tempVal2 = prompt("Enter Value 2");
    tempVal3 = prompt("Enter Value 3");

    if (tempVal1 == "" || tempVal2 == "" || tempVal3 == "") {
        alert("All the Input Fields are Required");
    } else {
        val1 = parseInt(tempVal1);
        val2 = parseInt(tempVal2);
        val3 = parseInt(tempVal3);

        if (isNaN(val1) || isNaN(val2) || isNaN(val3)) {
            alert("Invalid Input Given");
        } else {
            if (val1 > val2) {
                if (val1 > val3)
                    alert(val1 + " is Greater Among All");
                else
                    alert(val3 + " is Greater Among All");
            } else {
                if (val2 > val3)
                    alert(val2 + " is Greater Among All");
                else
                    alert(val3 + " is Greater Among All");
            }

            sum += val1 > 40 ? val1 : 0;
            sum += val2 > 40 ? val2 : 0;
            sum += val3 > 40 ? val3 : 0;

            alert(sum + " is the Sum of Number greater than 40");
            sum = 0;
        }
    }
}

function printCityName(){
    for(var i = 0; i < cityArray.length; i++){
        alert("City Name - " +cityArray[i]);
    }
}