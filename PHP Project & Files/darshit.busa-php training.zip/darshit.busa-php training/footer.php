<footer class="footer">
    <ul>
        <li>Darshit Busa</li>
    </ul>
</footer>

<script src="http://localhost/darshit.busa-php training/assets/js/bootstrap.bundle.min.js"></script>
<script src="http://localhost/darshit.busa-php training/assets/js/popper.min.js"></script>
<script src="http://localhost/darshit.busa-php training/assets/js/custom-pop.js"></script>
</body>

</html>