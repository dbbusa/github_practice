<?php $path = "http://localhost/darshit.busa-php training/"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo $path.'/assets/css/bootstrap.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo $path.'/assets/css/style-css-custom.css'; ?>">
    <link rel="stylesheet" href="<?php echo $path.'/assets/css/custom.css'; ?>">
    <script src="http://localhost/darshit.busa-php training/assets/js/jquery.min.js"></script>
    <title>Dashboard</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" title="Darshit Busa">DB</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link text-bold" aria-current="page" href="<?php echo $path.'html-training/index.php' ?>" title="HTML">HTML</a>
                    </li>
                    <li class="nav-item" id="link-css">
                        <a class="nav-link text-bold" aria-current="page" href="<?php echo $path.'css-training/index.php' ?>" title="CSS">CSS</a>
                    </li>
                    <li class="nav-item" id="link-css">
                        <a class="nav-link text-bold" aria-current="page" href="<?php echo $path.'Bootstrap-training/index.php' ?>" title="Bootstrap">Bootstrap</a>
                    </li>
                    <li class="nav-item" id="link-javascript">
                        <a class="nav-link text-bold" aria-current="page" href="<?php echo $path.'js-training/index.php' ?>" title="JavaScript">JavaScript</a>
                    </li>
                    <li class="nav-item" id="link-jquery">
                        <a class="nav-link text-bold" aria-current="page" href="<?php echo $path.'jQuery-training/index.php' ?>" title="JQuery">JQuery</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>