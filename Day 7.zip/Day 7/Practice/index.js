function stringFunction(){
    let result = "";
    var strData = document.getElementById('strData').value;
    
    if(strData == ""){
        document.getElementById('errStrData').innerHTML = "Please Enter String Data";
        document.getElementById('errStrData').classList.add('text-danger');
        document.getElementById('errStrData').classList.remove('text-muted');
    }else{

        result += "Index of a -- " + strData.indexOf('a') + "<br>";
        result += "Secound Index of a -- " + strData.indexOf('a',strData.indexOf('a')+1)  + "<br>";
        result += "Length of the String  -- " + strData.length  + "<br>";
        result += "Lower Case  -- " + strData.toLowerCase()  + "<br>";
        result += "Upper Case  -- " + strData.toUpperCase()  + "<br>";
        result += "Split -- " + strData.split("")  + "<br>";
        
        document.getElementById('resData').innerHTML = result;
    }
}

function sum2Number(){
    let num1 = parseInt(document.getElementById('number1').value);
    let num2 = parseInt(document.getElementById('number2').value);

    
    if(isNaN(num1)){
        document.getElementById('errNum1').innerHTML = "Number 1 is Required and Should be Number only";
        document.getElementById('errNum1').classList.add('text-muted');
        document.getElementById('errNum1').classList.remove('text-danger');
    }else if(isNaN(num2)){
        document.getElementById('errNum2').innerHTML = "Number 2 is Required and Should be Number only";
        document.getElementById('errNum2').classList.add('text-muted');
        document.getElementById('errNum2').classList.remove('text-danger');
    }else{   
        let result = num1+num2;
        document.getElementById('errNum2').innerHTML = "";
        document.getElementById('errNum1').innerHTML = "";
        document.getElementById('resAddition').innerHTML = result;
    }
}

function replaceText(){
    setInterval(()=>{
        document.getElementById('chngeStr').innerHTML = "Data After 10 Second";
    },10000)
}

function varLetExample(){
    var numf =  100; // Function level
    let numVal = 100; // Function level
    const fixNum = 10; // Function level

    // Block of Var Variable
    {
        var numf = 200 // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br> Value of num variable with Var inside block - " + numf;
    }
    document.getElementById('dispResult').innerHTML += "<br>Value of num variable with Var inside function - " + numf;
    
    // Block of Let Variable
    {
        let numVal = 2000 // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>Value of numVal variable with let inside block - " + numVal;
    }
    document.getElementById('dispResult').innerHTML += "<br>Value of numVal variable with let inside function - " + numVal;
    
    // Block of const Variable
    {
        const fixNum=200; // Block level declaration
        document.getElementById('dispResult').innerHTML += "<br><br>Value of fixNum variable with const inside function - " + fixNum;
    }

    document.getElementById('dispResult').innerHTML += "<br>Value of fixNum variable with const inside function - " + fixNum;
}

function multiExample(){
    let num1 = parseInt(document.getElementById('num1Multi').value);
    let num2 = parseInt(document.getElementById('num2Multi').value);

    const multiply = (arg1, arg2) => { return arg1 * arg2 };

    if(isNaN(num1)){
        document.getElementById('errNumMulti1').innerHTML = "Number 1 is Required and Should be Number only";
        document.getElementById('errNumMulti1').classList.add('text-muted');
        document.getElementById('errNumMulti1').classList.remove('text-danger');
    }else if(isNaN(num2)){
        document.getElementById('errNumMulti2').innerHTML = "Number 2 is Required and Should be Number only";
        document.getElementById('errNumMulti2').classList.add('text-muted');
        document.getElementById('errNumMulti2').classList.remove('text-danger');
    }else{   
        let result = multiply(num1,num2);
        document.getElementById('errNumMulti2').innerHTML = "";
        document.getElementById('errNumMulti1').innerHTML = "";
        document.getElementById('disArrowData').innerHTML = "Multiplication - " + result;
    }
}


function forOfFunction(){
    const arryaObj = ['item 1', 'item 2', 'item 3', 'item 4', 'item 5'];
    let disForData = "";
    for(let val of arryaObj){
        disForData += val + "<br>";
    }

    document.getElementById('disForData').innerHTML = disForData; 
}

function stringTemplate(){
   const employee = {
        name : "John Doe",
        city : "Mumbai",
        skills : ["Backend","Frontend","Cloud"],
   };
   let details = `
    <h5> ${employee.name} </h5>
    <h6> ${employee.city} </h6>
    <p> Skills </p>
    <ul>
        ${ employee.skills.map(skill => {
            return  `<li> ${skill} </li>`;
        }).join("")
        }
    </ul>`;
   document.getElementById('disStringTemp').innerHTML = details;
}


function taggedTemplate(){
    const author = "John Doe";
    const statement = "Lorem ipsum dolor sit amet consectetur adipisicing";
    const resTemp = highlight`Here is the ${statement} by ${author}`;

    console.log(resTemp);
    document.getElementById('disTaggedStringTemp').innerHTML = resTemp;

    function highlight(text,...extras){
        let res = text.map((item ,index) => {
            return `${item} <strong style='color:#0d6efd'>${extras[index]}</strong>`
        });
        return res.join("")
    }
}

function swapValue(){
    let fname = "Doe", lname = "John";
    data1 = "Before Swap fname = " + fname + " lname = " + lname;

    [lname,fname] = [fname, lname];

    data1 += "<br> After Swap fname = " + fname + " lname = " + lname;

    document.getElementById('disSwapTemp').innerHTML = data;
}

