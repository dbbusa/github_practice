getJson("assets/index.json");

async function getJson(file) {
    let data = await fetch(file);
    let myJson = await data.json();
    //console.log(myJson);
    localStorage.setItem('myJson', JSON.stringify(myJson));
}


getText();

async function getText() {
    var getjson = localStorage.getItem('myJson');
    var myJson = JSON.parse(getjson);
    console.log(myJson);

    var count = 1;

    let str = "<table class=''><tr style='background-color: #FF8800 !important;'><th>Product Id</th><th>Name</th><th>Price</th><th>Location</th></tr>";

    for (let id in myJson.products) {
        var loc = myJson.products[id];
        str += "<tr><td class='id'>" + count + "</td><td class='name'>" + loc.Name + "</td><td class='price'>" + loc.Price + "</td><td class='location'>" + loc.Location + "</td></tr>";
        count += 1;
    }
    str += "</tabel>";
    document.getElementById("showData").innerHTML = str;
}