module.exports = {
  content: [
    "./index.html",
    "./day2.html",
    "./src/**/*.{html,js}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
