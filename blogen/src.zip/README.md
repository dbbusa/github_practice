# Bootstrap 4 Starter Pack (version 4.5.2)

Latest version of Bootstrap 4! Automation with Gulp and support for sass!

### Version

2.0.0

## Install Dependencies

```bash
npm install 
```

## Compile Sass & Run Dev Server

```bash
npm start
```

Files are compiled into /src
