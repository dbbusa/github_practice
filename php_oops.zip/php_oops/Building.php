<?php

require "FireExtinguisher.php";
require "AssemblyPoint.php";


class Building implements FireExtinguisher, AssemblyPoint {
    public $buildingName;
    public $fireExtinguisher;
    public $assemblyPoint;

    function setFireExtinguisher($fireExtinguisherCount){
        $this->fireExtinguisher = $fireExtinguisherCount;
    }

    function setAssemblyPoint($assemblyPointCount){
        $this->assemblyPoint = $assemblyPointCount;
    }

    static function  fireExtinguisherError(){
        return "Hey Please have at least one Fire Extinguisher";
    }

    public function displayStatastics(){
        $res = array("Building Name" => $this->buildingName,"No. of fire extinguisher: " => $this->fireExtinguisher,"No. of Assembly points"=>$this->assemblyPoint);
        return $res;

    }
}
?>