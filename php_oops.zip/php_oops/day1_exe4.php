<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'class.php'; ?>



<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOPS / Employee Form</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="4">
            <li>On submission of form all details must be shown using appropriate class methods.
            </li>
        </ol>
        <form class="w-75 mx-auto border border-4 p-4 m-4" action="day1_exe4.php" method="post" name="myForm" style="border-radius: 13px;">
            <h2 class="text-center my-4" style="font-weight: bold;">Employee Form</h2>

            <div class="mb-3">
                <label for="role" class="form-label">I am a</label>
                <select class="form-select" id="role" name="role">
                    <option value="" <?php if (isset($_POST['role']) && $_POST['role'] == "") {
                                            echo "selected";
                                        } ?>>Selct account type... </option>
                    <option value="child" <?php if (isset($_POST['role']) && $_POST['role'] == "child") {
                                                echo "selected";
                                            } ?>>Child</option>
                    <option value="softwareDeveloper" <?php if (isset($_POST['role']) && $_POST['role'] == "softwareDeveloper") {
                                                            echo "selected";
                                                        } ?>>Software Developer</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" name="name" autocomplete="off" placeholder="Please enter name" value="<?php if (isset($_POST['name'])) {
                                                                                                                                    echo $_POST['name'];
                                                                                                                                } ?>">
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Age</label>
                <input type="number" class="form-control" name="age" autocomplete="off" placeholder="Please enter age" value="<?php if (isset($_POST['age'])) {
                                                                                                                                    echo $_POST['age'];
                                                                                                                                } ?>">
                <small class="text-danger"></small>
            </div>

            <div class="mb-3">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-select" name="gender">
                    <option value="" <?php if (isset($_POST['gender']) && $_POST['gender'] == "") {
                                            echo "selected";
                                        } ?>>Selct gender... </option>
                    <option value="male" <?php if (isset($_POST['gender']) && $_POST['gender'] == "male") {
                                                echo "selected";
                                            } ?>>Male</option>
                    <option value="female" <?php if (isset($_POST['gender']) && $_POST['gender'] == "female") {
                                                echo "selected";
                                            } ?>>Female</option>
                </select>
            </div>

            <div class="mb-3" id="dreams" style="display: none;">
                <label for="exampleFormControlInput1" class="form-label">Dreams</label>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="doctor" name="dreams[]" value="doctor" <?php if (isset($_POST['dreams']) && in_array("doctor", $_POST['dreams'])) {
                                                                                                                        echo "checked";
                                                                                                                    } ?>>
                        <label class="form-check-label" for="doctor">Doctor</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="engineer" name="dreams[]" value="engineer" <?php if (isset($_POST['dreams']) && in_array("engineer", $_POST['dreams'])) {
                                                                                                                            echo "checked";
                                                                                                                        } ?>>
                        <label class="form-check-label" for="engineer">Engineer</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="lawyer" name="dreams[]" value="lawyer" <?php if (isset($_POST['dreams']) && in_array("lawyer", $_POST['dreams'])) {
                                                                                                                        echo "checked";
                                                                                                                    } ?>>
                        <label class="form-check-label" for="lawyer">Lawyer</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="policeOfficer" name="dreams[]" value="policeOfficer" <?php if (isset($_POST['dreams']) && in_array("policeOfficer", $_POST['dreams'])) {
                                                                                                                                        echo "checked";
                                                                                                                                    } ?>>
                        <label class="form-check-label" for="policeOfficer">Police Officer</label>
                    </div>
                </div>

            </div>

            <div class="" id="position" style="display: none;">
                <label for="gender" class="form-label">Position</label>
                <select class="form-select" name="position">
                    <option value="" <?php if (isset($_POST['position']) && $_POST['position'] == "") {
                                            echo "selected";
                                        } ?>>Selct position... </option>
                    <option value="backEndDeveloper" <?php if (isset($_POST['position']) && $_POST['position'] == "backEndDeveloper") {
                                                            echo "selected";
                                                        } ?>>Backend Developer</option>

                    <option value="frontEndDeveloper" <?php if (isset($_POST['position']) && $_POST['position'] == "frontEndDeveloper") {
                                                            echo "selected";
                                                        } ?>>Front End Developer</option>
                    <option value="fullStackDeveloper" <?php if (isset($_POST['position']) && $_POST['position'] == "fullStackDeveloper") {
                                                            echo "selected";
                                                        } ?>>Full Stack Developer</option>
                </select>
            </div>

            <div class="d-flex justify-content-center mt-5">
                <input type="submit" value="Submit" name="submit" class="btn btn-primary px-5 me-5">
            </div>
            <div class="mt-4">
                <strong class="text-danger mt-3">
                    <?php

                    $res = "Result : ";
                    if (isset($_POST['submit'])) {

                        $role = $_POST['role'];
                        $name = $_POST['name'];
                        $age = $_POST['age'];
                        $gender = $_POST['gender'];
                        if ($role == "child") {
                            $dreams = ($_POST['dreams'])??"";
                        }
                        if ($role == "softwareDeveloper") {
                            $position = $_POST['position'];
                        }

                        if ($role == "" || $name == "" || $age == "" || $gender == "" || (empty($dreams) && empty($position))  ) {
                            $res = "Please fill all the fields";
                            echo $res;
                        }
                        else {
                            if ($role == "child") {
                                $obj = new Child($name,$age,$gender,$dreams);
                                $res .= $obj->introduce()." ";
                                $res .= $obj->greet("ankit")." ";
                                $res .= $obj->say_dreams()." ";
                            } else {
                                $obj = new SoftwareDeveloper($name,$age,$gender,$position);
                                $res .= $obj->introduce()." ";
                                $res .= $obj->greet("ankit")." ";
                                $res .= $obj->describe_job()." ";
                            }
                            echo $res;
                        }
                    }
                    ?>
                </strong>
            </div>
        </form>

    </div>

    <script>
        $(document).ready(function() {
            $role = $("#role").val();
            if ($role == "child") {
                $("#dreams").show();
                $("#position").hide();
            } else if ($role == "softwareDeveloper") {
                $("#dreams").hide();
                $("#position").show();
            }
            else{
                $("#dreams").hide();
                $("#position").hide();
            }            
        });

        $("#role").change(function() {
                $role = $(this).val();
                if ($role == "child") {
                    $("#dreams").show();
                    $("#position").hide();
                } else if ($role == "softwareDeveloper") {
                    $("#dreams").hide();
                    $("#position").show();
                } else {
                    $("#dreams").hide();
                    $("#position").hide();
                }
            });
    </script>

    <?php include '../../footer.php'; ?>