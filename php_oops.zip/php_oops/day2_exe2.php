<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php spl_autoload_register(function ($class_name) {
    include $class_name . '.php';
}); ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOPS / Building Management</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="6">
            <li>
            Building Management.
            </li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="day2_exe2.php" method="post">
                <h3 class="text-center mb-3">Building Management</h3>
                <div class="mb-3">
                    <label for="buildingName" class="form-label">Building Name</label>
                    <input type="text" step='0.001' name="buildingName" placeholder="First number" class="form-control" value="<?php if (isset($_POST['buildingName'])) {
                                                                                                                            echo $_POST['buildingName'];
                                                                                                                        } ?>" autocomplete="off" id="num1">
                </div>
                <div class="mb-3">
                    <label for="extinguisher" class="form-label">Number of fire extinguisher</label>
                    <input type="number" step='0.001' name="extinguisher" placeholder="First number" class="form-control" value="<?php if (isset($_POST['extinguisher'])) {
                                                                                                                            echo $_POST['extinguisher'];
                                                                                                                        } ?>" autocomplete="off" id="num1">
                </div>
                <div class="mb-3">
                    <label for="assemblyPoint" class="form-label">Number of assembly point</label>
                    <input type="number" step='0.001' name="assemblyPoint" placeholder="First number" class="form-control" value="<?php if (isset($_POST['assemblyPoint'])) {
                                                                                                                            echo $_POST['assemblyPoint'];
                                                                                                                        } ?>" autocomplete="off" id="num1">
                </div>

                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div> 
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {

                            $buildingName = $_POST['buildingName'];
                            $extinguisher = $_POST['extinguisher'];
                            $assemblyPoint = $_POST['assemblyPoint'];


                            $obj = new Building();

                            $res = "Result : <br/><br/>";
                            if ($extinguisher < 1) {

                                $res .= Building::fireExtinguisherError();
                            } else {
                                $obj->buildingName = $buildingName;
                                $obj->setFireExtinguisher($extinguisher);
                                $obj->setAssemblyPoint($assemblyPoint);

                                $tmp = $obj->displayStatastics();

                                foreach($tmp as $key=>$val){
                                    $res .= "$key : $val<br/>"; 
                                }
                            }

                            echo $res;
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>