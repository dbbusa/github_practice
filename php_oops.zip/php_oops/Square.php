<?php
    require "Shape.php";

    class Square implements Shape{

        function calculateArea($num){
            $res =  $num * $num;
            return $res;
        }
    }
?>