<?php
interface Shape{
    function calculateArea($num);
}
?>