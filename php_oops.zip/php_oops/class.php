<?php

    class EmployeeDteails{
        private $fname;
        private $lname;
        private $email;
        private $phone;
        private $dob;
        private $gender;

        public function setFName($fname){
            $this->fname = $fname;
        }

        public function setLName($lname){
            $this->lname = $lname;
        }

        public function setEmail($email){
            $this->email = $email;
        }

        public function setPhone($phone){
            $this->phone = $phone;
        }

        public function setDOB($dob){
            $this->dob = $dob;
        }

        public function setGender($gender){
            $this->gender = $gender;
        }

        public function getemployeedetails(){
            $arr = array();
            $arr['First name'] = $this->fname;
            $arr['Last name'] = $this->lname;
            $arr['Email'] = $this->email;
            $arr['Phone'] = $this->phone;
            $arr['DOB'] = $this->dob;
            $arr['Gender'] = $this->gender;

            return $arr;
        }

    }

    class Mobile{
        private $screenSize;
        private $ram;
        private $company;
        private $processor;
        private $price;
        private $estimateCost;

        public function __construct($screenSize,$ram,$company,$processor){
            $this->screenSize = $screenSize;
            $this->ram = $ram;
            $this->company = $company;
            $this->processor = $processor;
        }

        public function setprice(){
            
            switch($this->company){
                case 'samsung':
                    $this->price = 7000;
                    break;
                case 'moto':
                    $this->price = 5999;
                    break;
                case 'lenovo':
                    $this->price = 4000;
                    break;
                case 'nokia':
                    $this->price = 6100;
                    break;
            }
            $this->estimateCost = $this->price*($this->screenSize/4.0)+$this->price*($this->ram/1.0)+$this->price*($this->processor/1.0)+0.05*$this->price;
        }

        public function getprice(){
            return $this->estimateCost;
        }

    }

    class Bank{
        protected $accNumber;
        protected $accBalance;
        protected $accType;
        protected $accInterest;

        public function setAccNumber($accNumber){
            $this->accNumber = $accNumber;
        }

        public function setAccAmount($accAmount){
            $this->accBalance = $accAmount;
        }

        public function setAccType($accType){
            $this->accType = $accType;
        }

        public function setAccInterest($accInterest){
            $this->accInterest = $accInterest;
        }

        public function getAccNumber(){
            return $this-> accNumber;
        }

        public function getAccAmount(){
            return $this-> accAmount;
        }

        public function getAccType(){
            return $this-> accType;
        }
        public function getAccInterest(){
            return $this-> accInterest;
        }
        

        public function getAccSummary(){
            $accDetails = array();
            $accDetails['Account Number'] = $this->accNumber;
            $accDetails['Account Balance'] = $this->accBalance;
            $accDetails['Account Type'] = $this->accType;
            $accDetails['Account Interest'] = $this->accInterest."%";
            return $accDetails;
        }
    }

    class SavAccount extends Bank{

        private $total_blance;

        public function addInterest(){
            $this->total_blance = $this->accBalance + $this->accBalance * ($this->accInterest/100);
        }

        public function getTotalBlance(){
            return  $this->total_blance;
        }

    }

    class CurAccount extends Bank{
        private $total_blance;

        public function addInterest(){
            $this->total_blance = $this->accBalance + $this->accBalance * ($this->accInterest/100);
        }

        public function getTotalBlance(){
            return  $this->total_blance;
        }
    }

    abstract class Person{
        public $name;
        public $age;
        public $gender;

        function __construct($name,$age,$gender)
        {
            $this->name = $name;
            $this->age = $age;
            $this->gender = $gender;

        }

        abstract function introduce();

        function greet($name){
            $this->name = $name;
        }
    }

    class Child extends Person {
        public $aspirations = array();

        function __construct($name,$age,$gender,$aspirations)
        {
            parent::__construct($name,$age,$gender);
            $this->aspirations = $aspirations;
        }

        function introduce()
        {
            $res = "Hi, I'm $this->name and I am $this->age years old.";
            return $res;
        }

        function greet($name){
            $res = "Hi $name, let's play!.";
            return $res;
        }

        function say_dreams(){
            $res = "I would like to be ";
            $len = count($this->aspirations);
            foreach($this->aspirations as $key => $val){
                $res .= "$val".(($key != $len-1) ? ', ' : ' ');
            }
            $res .= "when I grow up.";
            return $res;
        }
    }

    class SoftwareDeveloper extends Person{
        public $position;

        function __construct($name,$age,$gender,$position)
        {
            parent::__construct($name,$age,$gender);
            $this->position = $position;
        }

        function introduce()
        {
            $res = "Hello, my name is $this->name, I am $this->age years old and I am  $this->position.";
            return $res;
        }

        function greet($name){
            $this->name = $name;
            $res = "Hello , I'm $name, nice to meet you.";
            return $res;
        }

        function describe_job(){
            $res = "I am currently working as  $this->position.";
            return $res;
        }
    }
?>