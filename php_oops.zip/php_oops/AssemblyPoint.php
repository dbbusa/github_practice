<?php
    interface AssemblyPoint{
        function setAssemblyPoint($count);
    }
?>