<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'class.php'; ?>



<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOPS / Bank Interest</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="3">
            <li>On submit Account number, Account balance entered, Account type and updated account balance should display.
            </li>
        </ol>
        <form class="w-75 mx-auto border border-4 p-4 m-4" action="day1_exe3.php" method="post" name="myForm" style="border-radius: 13px;">
            <h2 class="text-center my-4" style="font-weight: bold;">Bank Interest</h2>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Account number </label>
                <input type="number" class="form-control" name="accNumber" autocomplete="off" placeholder="Please enter account number" value="<?php if (isset($_POST['accNumber'])) {
                                                                                                                                                    echo $_POST['accNumber'];
                                                                                                                                                } ?>">
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Account balance</label>
                <input type="number" class="form-control" name="accBalance" autocomplete="off" placeholder="Please enter blance" value="<?php if (isset($_POST['accBalance'])) {
                                                                                                                                            echo $_POST['accBalance'];
                                                                                                                                        } ?>">
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Account type</label>
                <select class="form-select" name="accType">
                    <option value="" <?php if (isset($_POST['accType']) && $_POST['accType'] == "") {
                                            echo "selected";
                                        } ?>>Selct account type... </option>
                    <option value="saving" <?php if (isset($_POST['accType']) && $_POST['accType'] == "saving") {
                                                echo "selected";
                                            } ?>>Saving Account</option>
                    <option value="current" <?php if (isset($_POST['accType']) && $_POST['accType'] == "current") {
                                                echo "selected";
                                            } ?>>Current Account</option>
                </select>
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Interest</label>
                <input type="number" class="form-control" name="accInterest" autocomplete="off" placeholder="Please enter interest" value="<?php if (isset($_POST['accInterest'])) {
                                                                                                                                                echo $_POST['accInterest'];
                                                                                                                                            } ?>">
                <small class="text-danger"></small>
            </div>
            <div class="d-flex justify-content-center">
                <input type="submit" value="Submit" name="submit" class="btn btn-primary px-5 me-5">
            </div>
            <div class="mt-4">
                <strong class="text-danger mt-3">
                    <?php

                    $res = "";
                    if (isset($_POST['submit'])) {

                        $accNumber = $_POST['accNumber'];
                        $accBalance = $_POST['accBalance'];
                        $accType = $_POST['accType'];
                        $accInterest = $_POST['accInterest'];

                        if ($accNumber == "" || $accBalance == "" || $accType == "" || $accInterest == "") {
                            $res = "Please fill all the fields";
                            echo $res;
                        } else {
                            if ($accType == "saving") {
                                $obj = new SavAccount();
                            } else {
                                $obj = new CurAccount();
                            }
                            $obj->setAccNumber($accNumber);
                            $obj->setAccAmount($accBalance);
                            $obj->setAccType($accType);
                            $obj->setAccInterest($accInterest);

                            $accDetails = $obj->getAccSummary();

                            echo "Result <br/><br/>";

                            foreach ($accDetails as $key => $value) {
                                echo "$key : $value <br/>";
                            }

                            $obj->addInterest();
                            $result = $obj->getTotalBlance();

                            echo "Updated account balance : $result";
                        }
                    }
                    ?>

                </strong>
            </div>
        </form>


    </div>
    <?php include '../../footer.php'; ?>