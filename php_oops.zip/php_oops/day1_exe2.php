<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'class.php'; ?>



<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOPS / Estimate cost of Phone</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="2">
            <li>Build a class and store the data of the mobile phones with screen size, ram, company and processor along with Constructor and function to estimate cost of phone based on conditions
            </li>
        </ol>
        <form class="w-75 mx-auto border border-4 p-4 m-4" action="day1_exe2.php" method="post" name="myForm" style="border-radius: 13px;">
            <h2 class="text-center my-4" style="font-weight: bold;">Estimate cost of Phone </h2>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Screen size </label>
                <input type="number" class="form-control" name="screenSize"  autocomplete="off" placeholder="Please enter screen size" value="<?php if(isset($_POST['screenSize'])){ echo $_POST['screenSize'];}?>">
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Ram</label>
                <input type="number" class="form-control" name="ram"  autocomplete="off" placeholder="Please enter ram" value="<?php if(isset($_POST['ram'])){  echo $_POST['ram'];}?>">
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Company</label>
                <select class="form-select" name="company" >
                    <option value="" <?php if(isset($_POST['company']) && $_POST['company'] == ""){ echo "selected";}?>>Selct Company... </option>
                    <option value="samsung" <?php if(isset($_POST['company']) && $_POST['company'] == "samsung"){ echo "selected";}?>>Samsung</option>
                    <option value="moto" <?php if(isset($_POST['company']) && $_POST['company'] == "moto"){ echo "selected";}?>>Moto</option>
                    <option value="lenovo" <?php if(isset($_POST['company']) && $_POST['company'] == "lenovo"){ echo "selected";}?>>Lenovo</option>
                    <option value="nokia" <?php if(isset($_POST['company']) && $_POST['company'] == "nokia"){ echo "selected";}?>>Nokia</option>
                </select>
                <small class="text-danger"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Processor</label>
                <input type="number" class="form-control" name="processor" autocomplete="off" placeholder="Please enter ram" value="<?php if(isset($_POST['processor'])){  echo $_POST['processor'];}?>">
                <small class="text-danger"></small>
            </div>
            <div class="d-flex justify-content-center">
                <input type="submit" value="Submit" name="submit" class="btn btn-primary px-5 me-5">
            </div>
            <div class="mt-4">
                <strong class="text-danger mt-3">
                <?php

                $res = "";
                if (isset($_POST['submit'])) {

                    $screenSize = $_POST['screenSize'];
                    $ram = $_POST['ram'];
                    $company = $_POST['company'];
                    $processor = $_POST['processor'];
                    
                    if($screenSize == "" || $ram == "" || $company == "" || $processor ==""){
                        $res = "Please fill all the fields";
                        echo $res;
                    }
                    else{
                        $obj = new Mobile($screenSize,$ram,$company,$processor);

                        $obj->setprice();
                        $price = round($obj->getprice());
                        $res =  " Result :  $price";
                        echo $res;
                    }
                    
                }
                ?>
                     
                </strong>
            </div>
        </form>


    </div>
    <?php include '../../footer.php'; ?>