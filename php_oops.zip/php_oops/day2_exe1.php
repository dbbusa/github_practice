<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php spl_autoload_register(function ($class_name) {
    include $class_name . '.php';
}); ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOPS / Area Calculate</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="5">
            <li>
                Display calculated area of a shape
            </li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="day2_exe1.php" method="post">
                <h3 class="text-center mb-3">Area Calculate</h3>
                <div class="mb-4">
                    <label for="shape" class="form-label">Shape</label>
                    <select name="shape" id="shape" class="form-control">
                        <option value="" <?php if (isset($_POST['shape']) && $_POST['shape'] == "") {
                                                echo "selected";
                                            } ?>>Select shape...</option>
                        <option value="circle" <?php if (isset($_POST['shape']) && $_POST['shape'] == "circle") {
                                                    echo "selected";
                                                } ?>>Circle</option>
                        <option value="square" <?php if (isset($_POST['shape']) && $_POST['shape'] == "square") {
                                                    echo "selected";
                                                } ?>>Square</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="num" class="form-label">Please enter Parameter</label>
                    <input type="number" step='0.001' name="num" placeholder="First number" class="form-control" value="<?php if (isset($_POST['num'])) {
                                                                                                                            echo $_POST['num'];
                                                                                                                        } ?>" autocomplete="off" id="num">
                </div>

                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $shape = $_POST['shape'];
                            $num = $_POST['num'];


                            if ($shape == "" || $num == "") {
                                $res = "Please fill all the fields";
                                echo $res;
                            } else {
                                if ($shape == "circle") {
                                    $obj = new Circle();
                                } else if ($shape == "square") {
                                    $obj = new Square();
                                }
                                $res = $obj->calculateArea($num);
                                echo "Result : $res";
                            }


                            
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>