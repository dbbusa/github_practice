<?php
    require "Shape.php";

    class Circle implements Shape{

        const PI = 3.14;

        function calculateArea($num){
            $res = self::PI * $num * $num;
            return $res;
        }
    }
?>