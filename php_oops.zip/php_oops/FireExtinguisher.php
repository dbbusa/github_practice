<?php
    interface FireExtinguisher{
        function setFireExtinguisher($count);
    }
?>