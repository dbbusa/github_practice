<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'class.php'; ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / OOP / Registration</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="1">
            <li>Create a form which get above properties input from user and when user submit it, display employee information.
            </li>
        </ol>
        <form class="w-75 mx-auto border border-4 p-4 m-4" action="day1_exe1.php" method="post" name="myForm" style="border-radius: 13px;">
            <h2 class="text-center my-4" style="font-weight: bold;">Registration</h2>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">First name</label>
                <input type="text" class="form-control" name="fName" id="fName" autocomplete="off" placeholder="Please enter first name" value="<?php if(isset($_POST['fName'])){ echo $_POST['fName'];}?>" onkeyup="PHP_Overview_fName()">
                <small class="text-danger" id="err_fName"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Last name</label>
                <input type="text" class="form-control" name="lName" id="lName" autocomplete="off" placeholder="Please enter last name" value="<?php if(isset($_POST['fName'])){  echo $_POST['lName'];}?>" onkeyup="PHP_Overview_lName()">
                <small class="text-danger" id="err_lName"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Email Address</label>
                <input type="email" class="form-control" name="email" id="email" autocomplete="off" placeholder="Please enter email address" value="<?php if(isset($_POST['fName'])){ echo $_POST['email'];}?>" onkeyup="PHP_Overview_email()">
                <small class="text-danger" id="err_email"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Phone Number</label>
                <input type="number" class="form-control" name="phone" id="phone" autocomplete="off" placeholder="Please enter phone number" value="<?php if(isset($_POST['fName'])){  echo $_POST['phone'];}?>" onkeyup="PHP_Overview_phone()">
                <small class="text-danger" id="err_phone"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" name="dob" id="dob" value="<?php if(isset($_POST['fName'])){  echo $_POST['dob'];}?>" autocomplete="off" onchange="PHP_Overview_dob()">
                <small class="text-danger" id="err_dob"></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Gender</label>
                <div class="d-flex flex-row mt-2">
                    <div class="form-check d-flex align-items-center">
                        <input class="form-check-input" type="radio" name="gender" <?php if( isset($_POST['gender']) && $_POST['gender'] == "male"){ echo "checked";}?> id="male" value="male">
                        <label class="form-check-label ms-2 mt-1" for="male">
                            Male
                        </label>
                    </div>
                    <div class="form-check d-flex align-items-center ms-4">
                        <input class="form-check-input" type="radio" name="gender" <?php if(isset($_POST['gender']) && $_POST['gender'] == "female"){ echo "checked";}?> id="female" value="female">
                        <label class="form-check-labe ms-2 mt-1" for="female">
                            Female
                        </label>
                    </div>
                    <div class="form-check d-flex align-items-center ms-4">
                        <input class="form-check-input" type="radio" name="gender" <?php if(isset($_POST['gender']) && $_POST['gender'] == "other"){ echo "checked";}?> id="other" value="other">
                        <label class="form-check-label ms-2 mt-1" for="other">
                            Other
                        </label>
                    </div>
                </div>
                <small class="text-danger" id="err_gender"></small>
            </div>
            <div class="d-flex justify-content-center">
                <input type="submit" value="Submit" name="submit" class="btn btn-primary px-5 me-5" onclick="return PHP_OOPS_reg_sub()">
            </div>
            <div class="mt-4">
                <strong class="text-danger mt-3">
                    <?php

                    if (isset($_POST['submit'])) {

                        $fname = $_POST['fName'];
                        $lname = $_POST['lName'];
                        $email = $_POST['email'];
                        $phone = $_POST['phone'];
                        $dob = $_POST['dob'];
                        $gender = $_POST['gender'];

                        $obj = new EmployeeDteails();

                        $obj->setFName($fname);
                        $obj->setLName($lname);
                        $obj->setEmail($email);
                        $obj->setPhone($phone);
                        $obj->setDOB($dob);
                        $obj->setGender($gender);

                        $empDetails = $obj->getemployeedetails();

                        echo "Result <br/><br/>";
                        foreach ($empDetails as $key => $value) {
                            echo "$key : $value <br/>";
                        }
                    }
                    ?>
                </strong>
            </div>
        </form>


    </div>
    <?php include '../../footer.php'; ?>