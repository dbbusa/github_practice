import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  value = {
    num1 : "Rutu",
    num2 : "Bhavnagar",
    num3 : "CEBPG1516F"
  }
  constructor() { }

  ngOnInit(): void {
  }

}
