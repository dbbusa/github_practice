import {useState} from "react";
import './App.css';

 
function Signup() {
    const [num1,setNumber] = useState('');
    const [num2,setNumber1] = useState('');
    const [num3,setNumber2] = useState('');
    const handleChange = (e)=>{
       setNumber(e.target.value);
    }
    const handleChange1 = (e)=>{
        setNumber1(e.target.value);
    }
    const handleChange2 = (e)=>{
        setNumber2(e.target.value);
    }
  return (
    <div className="App">
      <header className="App-header">
      <div className="container mt-5">
    <h1 className="text-center">LogIn</h1>
<form className="mx-5">
    <div className="form-group mt-3">
      <label for="Input1">Name</label>
      <input className="form-control" type="text" id="num1" onChange={handleChange} value={num1}></input>
    </div>
    <div className="form-group">
      <label for="Input2">Address</label>
      <input  type="text" className="form-control" id="num2" onChange={handleChange1} value={num2}></input>
    </div>
    <div className="form-group">
      <label for="Input2">PanNumber</label>
      <input  type="text" className="form-control" id="num2" onChange={handleChange2} value={num3}></input>
    </div>
    <h3>Name : {num1}  | Address : {num2} | PanNumber : {num3}</h3>
  </form>
</div>
      </header>
    </div>
  );
}

export default Signup;