import {useState} from "react";
import './App.css';

 
function Login() {
    const [num1,setNumber] = useState('Admin');
    const [num2,setNumber1] = useState('Admin');
    const handleChange = (e)=>{
       setNumber(e.target.value);
    }
    const handleChange1 = (e)=>{
        setNumber1(e.target.value);
    }
  return (
    <div className="App">
      <header className="App-header">
      <div className="container mt-5">
    <h1 className="text-center">LogIn</h1>
<form className="mx-5">
    <div className="form-group mt-3">
      <label for="Input1">UserName</label>
      <input className="form-control" type="text" id="num1" onChange={handleChange} value={num1}></input>
    </div>
    <div className="form-group">
      <label for="Input2">Password</label>
      <input  type="password" className="form-control" id="num2" onChange={handleChange1} value={num2}></input>
    </div>
    <button className="btn btn-primary mt-3">LogIn</button>
  </form>
</div>
      </header>
    </div>
  );
}

export default Login;