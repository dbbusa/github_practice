import {useState} from "react";
import './App.css';

function Calc() {
    const [num1,setNumber] = useState('');
    const [num2,setNumber1] = useState('');
    const handleChange = (e)=>{
       setNumber(e.target.value);
    }
    const handleChange1 = (e)=>{
        setNumber1(e.target.value);
    }
return (
  <div className="App">
    <header className="App-header">
    <div className="container mt-5">
    <h1 className="text-center">Calculator</h1>
    <form className="mx-5">
    <div className="form-group mt-3">
      <label for="Input1">First Number</label>
      <input className="form-control" type="number" onChange={handleChange} value={num1}></input>
    </div>
    <div className="form-group">
      <label for="Input2">Second Number</label>
      <input  type="number" class="form-control" onChange={handleChange1} value={num2}></input>
    </div>
    <h5>Addition</h5>
    {Number(num1) + Number(num2)}
    <h5>Substraction</h5>
    {num1 - num2}
    <h5>Multiplication</h5>
    {num1 * num2}
    <h5>Division</h5>
    {num1 / num2}
  </form>
</div>
    </header>
  </div>
);
}

export default Calc;