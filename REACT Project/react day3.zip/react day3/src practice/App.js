
import './App.css';

  let  alpha = Array.from(Array(26)).map((e, i) => i + 65);
  let  alphabets = alpha.map((x) => String.fromCharCode(x));
function App() {
  
  return (
    <div className="App">
      <header className="App-header">
        <h1>{alphabets}</h1>
      </header>
    </div>
  );
}

export default App;
