<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
   <div class="container mt-5">
    <h1 class="text-center">Greter of two Numbers</h1>
<form class="mx-5">
    <div class="mt-3 form-group">
      <label for="Input1">First Number</label>
      <input class="form-control" type="number" id="num1" v-model.number="num1" name="num1">
    </div>
    <div class="form-group">
      <label for="Input2">Second Number</label>
      <input  type="number" class="form-control" id="num2"  v-model.number="num2" name="num2">
    </div>
  </form>
</div>
  </div>
  <div class="mt-3">
    <h1 v-if="num1 > num2" class="fw-bold">First Number is Greter</h1>
    <h1 v-if="num2 > num1" class="fw-bold">Second Number is Greter</h1>
</div>

</template>

<script>
export default {
   data: function(){
        return {
            num1: 0,
            num2: 0
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
