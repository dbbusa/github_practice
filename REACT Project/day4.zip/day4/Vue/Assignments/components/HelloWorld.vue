<template>
  <div class="hello">
    <div class="container">
    <h4 class="text-center text-uppercase text-secondary">Employee Details</h4> <hr/>
    <div class="row">
          <div class="col-md-6">
                <table class="table table-responsive table-striped" aria-label="Employee">
                    <thead>
                        <tr>
                            <th>Employee Id</th>
                            <th>Employee Name</th>
                            <th>Employee Address</th>
                            <th>Employee Gender</th>
                            <th>Employee Hobbies</th>
                            <th>Employee Joining Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="value in employee" v-bind:key="value">
                            <td>{{value.Id}}</td>
                            <td>{{value.Name}}</td>
                            <td>{{value.Address}}</td>
                            <td>{{value.Gender}}</td>
                            <td>{{value.Hobbies}}</td>
                            <td>{{value.Date}}</td>
                        </tr>
                    </tbody>
                </table>
        </div>
        <div class="col-md-6">
           
                <div class="form-row">
                    <div class="mb-3 form-group">
                        <label for="employeeId">Employee Id</label>
                        <input type="text" class="form-control" id="employeeId" placeholder="Employee Id" v-model="eId" autocomplete="off">
                    </div>
                    <div class="mb-3 form-group">  
                        <label for="name">Employee Name</label>
                        <input type="text" class="form-control" id="name" placeholder="Employee Name" v-model="eName" autocomplete="off">
                    </div>                
                </div>
                
                <div class="mb-3 form-group">
                  <label for="inputAddress">Employee Address</label>
                  <input type="text" class="form-control" id="inputAddress" placeholder="Employee Address" v-model="eAddress" autocomplete="off">
                </div>
  
                <div class="mb-3">
                   Employee Gender : 
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="male" value="male" v-model="gender" checked>
                        <label class="form-check-label" for="male">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="female" v-model="gender" >
                        <label class="form-check-label" for="female">Female</label>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="mb-3 form-group">
                        <label for="inputHobbies">Employee Hobbies</label>
                        <input type="text" class="form-control" id="inputHobbies" placeholder="Employee Hobbies" v-model="eHobbies" autocomplete="off">
                      </div>
                 </div>
               
                 <div class="mb-3 form-group">
                    <label for="date">Employee Joining Date</label>
                    <input type="date" class="form-control" v-model="date">
                </div>
               
            
                 <br/>
                <button type="submit" class="btn btn-primary" v-on:click="submit()">Sign in</button>             
        </div>
    </div>
  </div>

  </div>
</template>

<script>
export default {
 data(){
   return{
      eId  : '',
      eName : '',
      eAddress : '',
      Male : '',
      Female : '',
      gender : {
        value : 'Male',
      },
      eHobbies : '',
      date : '',
      employee : [],
      data : {}
   }
 },
 methods:{
   submit : function(){
      this.data  = {
    Id : this.eId,
    Name : this.eName,
    Address : this.eAddress,
    Gender : this.gender,
    Hobbies : this.eHobbies,
    Date : this.date
    };
    this.employee.push(this.data)
     console.log(this.employee)
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
