import logo from './logo.svg';
import {useState} from "react";
import './App.css';

function App() {
  const [num1,setNumber] = useState('');
    const [num2,setNumber1] = useState('');
    const handleChange = (e)=>{
       setNumber(e.target.value);
    }
    const handleChange1 = (e)=>{
        setNumber1(e.target.value);
    }
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <div class="container mt-5">
    <h1 class="text-center">Greter of two Numbers</h1>
    <form class="mx-5">
      <div class="form-group mt-3">
        <label for="Input1">First Number</label>
        <input class="form-control" type="number" id="num1" onChange={handleChange} value={num1} name="num1"></input>
      </div>
      <div class="form-group">
        <label for="Input2">Second Number</label>
        <input  type="number" class="form-control" id="num2"  onChange={handleChange1} value={num2} name="num2"></input>
      </div>
    </form>
    {num1 > num2 ? 'First Number is greater' : 'Second Number is greater'}
</div>
      </header>
    </div>
  );
}

export default App;
